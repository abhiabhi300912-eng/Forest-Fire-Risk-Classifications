import {
  ALGERIAN_FIRES_DATASET,
  FireRecord,
  FEATURE_NAMES,
  FeatureKey
} from '../data/algerianFiresData';

export type RiskCategory = 'Low' | 'Moderate' | 'High' | 'Extreme';
export const RISK_CLASSES: RiskCategory[] = ['Low', 'Moderate', 'High', 'Extreme'];

export const RISK_COLORS: Record<RiskCategory, {
  hex: string;
  bgClass: string;
  textClass: string;
  borderClass: string;
  badgeClass: string;
}> = {
  Low: {
    hex: '#10B981',
    bgClass: 'bg-emerald-500/10',
    textClass: 'text-emerald-500 dark:text-emerald-400',
    borderClass: 'border-emerald-500/30',
    badgeClass: 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-300 border-emerald-500/30',
  },
  Moderate: {
    hex: '#F59E0B',
    bgClass: 'bg-amber-500/10',
    textClass: 'text-amber-500 dark:text-amber-400',
    borderClass: 'border-amber-500/30',
    badgeClass: 'bg-amber-500/20 text-amber-600 dark:text-amber-300 border-amber-500/30',
  },
  High: {
    hex: '#EF4444',
    bgClass: 'bg-red-500/10',
    textClass: 'text-red-500 dark:text-red-400',
    borderClass: 'border-red-500/30',
    badgeClass: 'bg-red-500/20 text-red-600 dark:text-red-300 border-red-500/30',
  },
  Extreme: {
    hex: '#7C2D12',
    bgClass: 'bg-rose-950/30',
    textClass: 'text-rose-600 dark:text-rose-400',
    borderClass: 'border-rose-700/50',
    badgeClass: 'bg-rose-900/40 text-rose-300 border-rose-600/40',
  },
};

export interface ScalerModel {
  mean: number[];
  std: number[];
  transform: (inputs: number[]) => number[];
  inverse_transform: (scaled: number[]) => number[];
}

export class StandardScaler implements ScalerModel {
  mean: number[] = [];
  std: number[] = [];

  fit(data: number[][]): void {
    const numFeatures = data[0].length;
    const n = data.length;
    this.mean = new Array(numFeatures).fill(0);
    this.std = new Array(numFeatures).fill(0);

    for (let j = 0; j < numFeatures; j++) {
      let sum = 0;
      for (let i = 0; i < n; i++) {
        sum += data[i][j];
      }
      this.mean[j] = sum / n;
    }

    for (let j = 0; j < numFeatures; j++) {
      let varSum = 0;
      for (let i = 0; i < n; i++) {
        varSum += Math.pow(data[i][j] - this.mean[j], 2);
      }
      this.std[j] = Math.sqrt(varSum / n) || 1e-7;
    }
  }

  fitTransform(data: number[][]): number[][] {
    this.fit(data);
    return data.map(row => this.transform(row));
  }

  transform(inputs: number[]): number[] {
    return inputs.map((val, idx) => (val - this.mean[idx]) / (this.std[idx] || 1e-7));
  }

  inverse_transform(scaled: number[]): number[] {
    return scaled.map((val, idx) => val * this.std[idx] + this.mean[idx]);
  }
}

// Tree Node for Decision Tree
interface TreeNode {
  isLeaf: boolean;
  prediction?: RiskCategory;
  probabilities?: Record<RiskCategory, number>;
  featureIndex?: number;
  threshold?: number;
  left?: TreeNode;
  right?: TreeNode;
  impurity?: number;
  sampleCount?: number;
}

export class DecisionTreeClassifier {
  maxDepth: number;
  minSamplesSplit: number;
  root: TreeNode | null = null;
  featureImportances: number[] = [];

  constructor(maxDepth = 6, minSamplesSplit = 2) {
    this.maxDepth = maxDepth;
    this.minSamplesSplit = minSamplesSplit;
  }

  fit(X: number[][], y: RiskCategory[], randomFeatureCount?: number, rng = Math.random): void {
    const numFeatures = X[0].length;
    this.featureImportances = new Array(numFeatures).fill(0);
    this.root = this.buildTree(X, y, 0, randomFeatureCount, rng);
  }

  private giniImpurity(y: RiskCategory[]): number {
    const total = y.length;
    if (total === 0) return 0;
    const counts: Record<string, number> = {};
    for (const label of y) {
      counts[label] = (counts[label] || 0) + 1;
    }
    let impurity = 1.0;
    for (const label in counts) {
      const prob = counts[label] / total;
      impurity -= prob * prob;
    }
    return impurity;
  }

  private buildTree(
    X: number[][],
    y: RiskCategory[],
    depth: number,
    randomFeatureCount?: number,
    rng: () => number = Math.random
  ): TreeNode {
    const nSamples = y.length;
    const currentImpurity = this.giniImpurity(y);

    const counts: Record<RiskCategory, number> = { Low: 0, Moderate: 0, High: 0, Extreme: 0 };
    for (const label of y) counts[label]++;

    let maxCount = -1;
    let majorityClass: RiskCategory = 'Low';
    for (const cls of RISK_CLASSES) {
      if (counts[cls] > maxCount) {
        maxCount = counts[cls];
        majorityClass = cls;
      }
    }

    const probabilities: Record<RiskCategory, number> = {
      Low: nSamples > 0 ? counts.Low / nSamples : 0,
      Moderate: nSamples > 0 ? counts.Moderate / nSamples : 0,
      High: nSamples > 0 ? counts.High / nSamples : 0,
      Extreme: nSamples > 0 ? counts.Extreme / nSamples : 0,
    };

    if (depth >= this.maxDepth || nSamples < this.minSamplesSplit || currentImpurity === 0) {
      return {
        isLeaf: true,
        prediction: majorityClass,
        probabilities,
        impurity: currentImpurity,
        sampleCount: nSamples,
      };
    }

    const numFeatures = X[0].length;
    let candidateFeatures = Array.from({ length: numFeatures }, (_, i) => i);
    if (randomFeatureCount && randomFeatureCount < numFeatures) {
      // Feature subsampling
      candidateFeatures.sort(() => rng() - 0.5);
      candidateFeatures = candidateFeatures.slice(0, randomFeatureCount);
    }

    let bestGain = -1;
    let bestFeature = -1;
    let bestThreshold = 0;
    let bestSplits: { leftX: number[][]; leftY: RiskCategory[]; rightX: number[][]; rightY: RiskCategory[] } | null = null;

    for (const feat of candidateFeatures) {
      // Find candidate thresholds
      const values = X.map(row => row[feat]);
      const uniqueVals = Array.from(new Set(values)).sort((a, b) => a - b);
      if (uniqueVals.length <= 1) continue;

      // Sample a subset of midpoints for fast tree building
      const midpoints: number[] = [];
      const step = Math.max(1, Math.floor(uniqueVals.length / 15));
      for (let i = 0; i < uniqueVals.length - 1; i += step) {
        midpoints.push((uniqueVals[i] + uniqueVals[i + 1]) / 2);
      }

      for (const thresh of midpoints) {
        const leftX: number[][] = [];
        const leftY: RiskCategory[] = [];
        const rightX: number[][] = [];
        const rightY: RiskCategory[] = [];

        for (let i = 0; i < nSamples; i++) {
          if (X[i][feat] <= thresh) {
            leftX.push(X[i]);
            leftY.push(y[i]);
          } else {
            rightX.push(X[i]);
            rightY.push(y[i]);
          }
        }

        if (leftY.length === 0 || rightY.length === 0) continue;

        const leftImp = this.giniImpurity(leftY);
        const rightImp = this.giniImpurity(rightY);
        const weightedImp = (leftY.length / nSamples) * leftImp + (rightY.length / nSamples) * rightImp;
        const gain = currentImpurity - weightedImp;

        if (gain > bestGain) {
          bestGain = gain;
          bestFeature = feat;
          bestThreshold = thresh;
          bestSplits = { leftX, leftY, rightX, rightY };
        }
      }
    }

    if (bestGain <= 0.0001 || !bestSplits) {
      return {
        isLeaf: true,
        prediction: majorityClass,
        probabilities,
        impurity: currentImpurity,
        sampleCount: nSamples,
      };
    }

    // Accumulate feature importance (normalized decrease in impurity * nSamples)
    this.featureImportances[bestFeature] += bestGain * nSamples;

    const leftChild = this.buildTree(bestSplits.leftX, bestSplits.leftY, depth + 1, randomFeatureCount, rng);
    const rightChild = this.buildTree(bestSplits.rightX, bestSplits.rightY, depth + 1, randomFeatureCount, rng);

    return {
      isLeaf: false,
      featureIndex: bestFeature,
      threshold: bestThreshold,
      left: leftChild,
      right: rightChild,
      impurity: currentImpurity,
      sampleCount: nSamples,
    };
  }

  predictProba(x: number[]): Record<RiskCategory, number> {
    if (!this.root) return { Low: 0.25, Moderate: 0.25, High: 0.25, Extreme: 0.25 };
    let curr: TreeNode = this.root;
    while (!curr.isLeaf) {
      if (curr.featureIndex === undefined || curr.threshold === undefined) break;
      if (x[curr.featureIndex] <= curr.threshold) {
        if (!curr.left) break;
        curr = curr.left;
      } else {
        if (!curr.right) break;
        curr = curr.right;
      }
    }
    return curr.probabilities || { Low: 1, Moderate: 0, High: 0, Extreme: 0 };
  }

  predict(x: number[]): RiskCategory {
    const proba = this.predictProba(x);
    let maxP = -1;
    let bestCls: RiskCategory = 'Low';
    for (const cls of RISK_CLASSES) {
      if (proba[cls] > maxP) {
        maxP = proba[cls];
        bestCls = cls;
      }
    }
    return bestCls;
  }
}

// Pseudo-random generator for reproducibility with seed
function createSeededRng(seed: number) {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return function () {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

export class RandomForestClassifier {
  nEstimators: number;
  maxDepth: number;
  randomState: number;
  trees: DecisionTreeClassifier[] = [];
  featureImportances: number[] = [];

  constructor(nEstimators = 100, maxDepth = 6, randomState = 42) {
    this.nEstimators = nEstimators;
    this.maxDepth = maxDepth;
    this.randomState = randomState;
  }

  fit(X: number[][], y: RiskCategory[]): void {
    const nSamples = X.length;
    const numFeatures = X[0].length;
    const maxFeatures = Math.max(1, Math.round(Math.sqrt(numFeatures)));
    const rng = createSeededRng(this.randomState);

    this.trees = [];
    const aggregatedImportances = new Array(numFeatures).fill(0);

    for (let t = 0; t < this.nEstimators; t++) {
      // Bootstrap sampling (with replacement)
      const bootX: number[][] = [];
      const bootY: RiskCategory[] = [];
      for (let i = 0; i < nSamples; i++) {
        const idx = Math.floor(rng() * nSamples);
        bootX.push(X[idx]);
        bootY.push(y[idx]);
      }

      const tree = new DecisionTreeClassifier(this.maxDepth, 2);
      tree.fit(bootX, bootY, maxFeatures, rng);
      this.trees.push(tree);

      for (let f = 0; f < numFeatures; f++) {
        aggregatedImportances[f] += tree.featureImportances[f] || 0;
      }
    }

    const sumImp = aggregatedImportances.reduce((a, b) => a + b, 0) || 1;
    this.featureImportances = aggregatedImportances.map(val => Number((val / sumImp).toFixed(4)));
  }

  predictProba(x: number[]): Record<RiskCategory, number> {
    const totals: Record<RiskCategory, number> = { Low: 0, Moderate: 0, High: 0, Extreme: 0 };
    if (this.trees.length === 0) return { Low: 0.25, Moderate: 0.25, High: 0.25, Extreme: 0.25 };

    for (const tree of this.trees) {
      const p = tree.predictProba(x);
      for (const cls of RISK_CLASSES) {
        totals[cls] += p[cls] || 0;
      }
    }

    const n = this.trees.length;
    return {
      Low: totals.Low / n,
      Moderate: totals.Moderate / n,
      High: totals.High / n,
      Extreme: totals.Extreme / n,
    };
  }

  predict(x: number[]): RiskCategory {
    const proba = this.predictProba(x);
    let maxP = -1;
    let bestCls: RiskCategory = 'Low';
    for (const cls of RISK_CLASSES) {
      if (proba[cls] > maxP) {
        maxP = proba[cls];
        bestCls = cls;
      }
    }
    return bestCls;
  }
}

// Logistic Regression Classifier (One-vs-Rest)
export class LogisticRegressionOvR {
  weights: Record<RiskCategory, number[]> = {
    Low: [],
    Moderate: [],
    High: [],
    Extreme: [],
  };
  biases: Record<RiskCategory, number> = {
    Low: 0,
    Moderate: 0,
    High: 0,
    Extreme: 0,
  };
  featureImportances: number[] = [];

  fit(X: number[][], y: RiskCategory[], epochs = 300, lr = 0.05): void {
    const numFeatures = X[0].length;
    const n = X.length;

    for (const cls of RISK_CLASSES) {
      const w = new Array(numFeatures).fill(0);
      let b = 0;
      const target = y.map(lbl => (lbl === cls ? 1 : 0));

      for (let epoch = 0; epoch < epochs; epoch++) {
        const gradW = new Array(numFeatures).fill(0);
        let gradB = 0;

        for (let i = 0; i < n; i++) {
          let z = b;
          for (let j = 0; j < numFeatures; j++) {
            z += w[j] * X[i][j];
          }
          const sig = 1 / (1 + Math.exp(-Math.max(-20, Math.min(20, z))));
          const err = sig - target[i];

          for (let j = 0; j < numFeatures; j++) {
            gradW[j] += err * X[i][j];
          }
          gradB += err;
        }

        for (let j = 0; j < numFeatures; j++) {
          w[j] -= (lr * gradW[j]) / n;
        }
        b -= (lr * gradB) / n;
      }

      this.weights[cls] = w;
      this.biases[cls] = b;
    }

    // Weight magnitude as feature importance
    const importances = new Array(numFeatures).fill(0);
    for (let j = 0; j < numFeatures; j++) {
      for (const cls of RISK_CLASSES) {
        importances[j] += Math.abs(this.weights[cls][j]);
      }
    }
    const sumImp = importances.reduce((a, b) => a + b, 0) || 1;
    this.featureImportances = importances.map(v => Number((v / sumImp).toFixed(4)));
  }

  predictProba(x: number[]): Record<RiskCategory, number> {
    const scores: Record<RiskCategory, number> = { Low: 0, Moderate: 0, High: 0, Extreme: 0 };
    let sumExp = 0;

    for (const cls of RISK_CLASSES) {
      let z = this.biases[cls];
      for (let j = 0; j < x.length; j++) {
        z += this.weights[cls][j] * x[j];
      }
      scores[cls] = Math.exp(Math.max(-20, Math.min(20, z)));
      sumExp += scores[cls];
    }

    return {
      Low: scores.Low / (sumExp || 1),
      Moderate: scores.Moderate / (sumExp || 1),
      High: scores.High / (sumExp || 1),
      Extreme: scores.Extreme / (sumExp || 1),
    };
  }

  predict(x: number[]): RiskCategory {
    const proba = this.predictProba(x);
    let best: RiskCategory = 'Low';
    let max = -1;
    for (const cls of RISK_CLASSES) {
      if (proba[cls] > max) {
        max = proba[cls];
        best = cls;
      }
    }
    return best;
  }
}

// Metrics Interface
export interface ClassMetrics {
  precision: number;
  recall: number;
  f1: number;
  support: number;
}

export interface ModelEvaluation {
  accuracy: number;
  macroF1: number;
  weightedF1: number;
  report: Record<RiskCategory, ClassMetrics>;
  confusionMatrix: number[][]; // 4x4 row: True, col: Pred
  featureImportances: { feature: FeatureKey; importance: number; percentage: number }[];
  trainCount: number;
  testCount: number;
}

export function evaluateModel(
  model: { predict: (x: number[]) => RiskCategory },
  X_test: number[][],
  y_test: RiskCategory[],
  trainCount: number,
  featureImportancesArr: number[]
): ModelEvaluation {
  const n = X_test.length;
  const matrix: number[][] = [
    [0, 0, 0, 0], // Low
    [0, 0, 0, 0], // Moderate
    [0, 0, 0, 0], // High
    [0, 0, 0, 0], // Extreme
  ];

  const classIndices: Record<RiskCategory, number> = {
    Low: 0,
    Moderate: 1,
    High: 2,
    Extreme: 3,
  };

  let correct = 0;

  for (let i = 0; i < n; i++) {
    const pred = model.predict(X_test[i]);
    const trueCls = y_test[i];
    const trueIdx = classIndices[trueCls];
    const predIdx = classIndices[pred];
    matrix[trueIdx][predIdx]++;
    if (pred === trueCls) {
      correct++;
    }
  }

  const accuracy = correct / (n || 1);
  const report: Record<RiskCategory, ClassMetrics> = {
    Low: { precision: 0, recall: 0, f1: 0, support: 0 },
    Moderate: { precision: 0, recall: 0, f1: 0, support: 0 },
    High: { precision: 0, recall: 0, f1: 0, support: 0 },
    Extreme: { precision: 0, recall: 0, f1: 0, support: 0 },
  };

  let macroF1Sum = 0;
  let weightedF1Sum = 0;

  for (let c = 0; c < 4; c++) {
    const cls = RISK_CLASSES[c];
    const tp = matrix[c][c];
    let fn = 0;
    for (let j = 0; j < 4; j++) {
      if (j !== c) fn += matrix[c][j];
    }
    let fp = 0;
    for (let i = 0; i < 4; i++) {
      if (i !== c) fp += matrix[i][c];
    }

    const support = tp + fn;
    const precision = tp + fp > 0 ? tp / (tp + fp) : 0;
    const recall = tp + fn > 0 ? tp / (tp + fn) : 0;
    const f1 = precision + recall > 0 ? (2 * precision * recall) / (precision + recall) : 0;

    report[cls] = {
      precision: Number(precision.toFixed(3)),
      recall: Number(recall.toFixed(3)),
      f1: Number(f1.toFixed(3)),
      support,
    };

    macroF1Sum += f1;
    weightedF1Sum += f1 * support;
  }

  const macroF1 = Number((macroF1Sum / 4).toFixed(3));
  const weightedF1 = Number((weightedF1Sum / (n || 1)).toFixed(3));

  const featureImportances = FEATURE_NAMES.map((name, idx) => ({
    feature: name,
    importance: featureImportancesArr[idx] || 0,
    percentage: Number(((featureImportancesArr[idx] || 0) * 100).toFixed(1)),
  })).sort((a, b) => b.importance - a.importance);

  return {
    accuracy: Number(accuracy.toFixed(3)),
    macroF1,
    weightedF1,
    report,
    confusionMatrix: matrix,
    featureImportances,
    trainCount,
    testCount: n,
  };
}

// Global Pre-trained Pipeline Instance (Matches Step 2 and Step 3 from user guide)
export interface TrainedPipeline {
  scaler: StandardScaler;
  model: RandomForestClassifier;
  evaluation: ModelEvaluation;
  features: typeof FEATURE_NAMES;
}

export function trainAlgerianPipeline(
  nEstimators = 100,
  maxDepth = 6,
  testRatio = 0.2,
  randomState = 42,
  modelType: 'RandomForest' | 'DecisionTree' | 'LogisticRegression' = 'RandomForest'
): {
  scaler: StandardScaler;
  model: { predict: (x: number[]) => RiskCategory; predictProba: (x: number[]) => Record<RiskCategory, number> };
  evaluation: ModelEvaluation;
} {
  // Extract features: ['Temperature', 'RH', 'Ws', 'ISI', 'BUI']
  const rawX = ALGERIAN_FIRES_DATASET.map(d => [
    d.Temperature,
    d.RH,
    d.Ws,
    d.ISI,
    d.BUI,
  ]);
  const rawY = ALGERIAN_FIRES_DATASET.map(d => d.Risk_Level);

  // Train / Test split with fixed seed
  const rng = createSeededRng(randomState);
  const indices = Array.from({ length: rawX.length }, (_, i) => i);
  // Shuffle indices
  for (let i = indices.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [indices[i], indices[j]] = [indices[j], indices[i]];
  }

  const testSize = Math.floor(rawX.length * testRatio);
  const testIndices = new Set(indices.slice(0, testSize));

  const X_train: number[][] = [];
  const y_train: RiskCategory[] = [];
  const X_test: number[][] = [];
  const y_test: RiskCategory[] = [];

  for (let i = 0; i < rawX.length; i++) {
    if (testIndices.has(i)) {
      X_test.push(rawX[i]);
      y_test.push(rawY[i]);
    } else {
      X_train.push(rawX[i]);
      y_train.push(rawY[i]);
    }
  }

  // Standardize
  const scaler = new StandardScaler();
  const X_train_scaled = scaler.fitTransform(X_train);
  const X_test_scaled = X_test.map(row => scaler.transform(row));

  let model: {
    predict: (x: number[]) => RiskCategory;
    predictProba: (x: number[]) => Record<RiskCategory, number>;
  };
  let featureImportancesArr: number[] = [];

  if (modelType === 'DecisionTree') {
    const dt = new DecisionTreeClassifier(maxDepth, 2);
    dt.fit(X_train_scaled, y_train);
    const sumImp = dt.featureImportances.reduce((a, b) => a + b, 0) || 1;
    featureImportancesArr = dt.featureImportances.map(v => v / sumImp);
    model = dt;
  } else if (modelType === 'LogisticRegression') {
    const lr = new LogisticRegressionOvR();
    lr.fit(X_train_scaled, y_train, 250, 0.08);
    featureImportancesArr = lr.featureImportances;
    model = lr;
  } else {
    // Random Forest (Default)
    const rf = new RandomForestClassifier(nEstimators, maxDepth, randomState);
    rf.fit(X_train_scaled, y_train);
    featureImportancesArr = rf.featureImportances;
    model = rf;
  }

  const evaluation = evaluateModel(model, X_test_scaled, y_test, X_train.length, featureImportancesArr);

  return {
    scaler,
    model,
    evaluation,
  };
}

// Create default singleton pipeline on initialization
export const DEFAULT_PIPELINE = trainAlgerianPipeline(100, 6, 0.2, 42, 'RandomForest');
