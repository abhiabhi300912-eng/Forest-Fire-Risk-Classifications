import React, { useState, useEffect } from 'react';
import {
  Flame,
  Cpu,
  Database,
  FileText,
  Calendar,
  Code2,
  Moon,
  Sun,
  ShieldAlert,
  Sparkles,
  ExternalLink,
  BookOpen,
  Sliders
} from 'lucide-react';
import { PredictorTab } from './components/PredictorTab';
import { TrainingLabTab } from './components/TrainingLabTab';
import { DatasetExplorerTab } from './components/DatasetExplorerTab';
import { TechnicalPaperTab } from './components/TechnicalPaperTab';
import { RoadmapTab } from './components/RoadmapTab';
import { CodeExportModal } from './components/CodeExportModal';

export default function App() {
  const [activeTab, setActiveTab] = useState<'predictor' | 'lab' | 'data' | 'paper' | 'roadmap'>('predictor');
  const [isCodeModalOpen, setIsCodeModalOpen] = useState(false);
  const [darkMode, setDarkMode] = useState<boolean>(true);

  // Apply dark mode class to root HTML
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors duration-200">
      {/* Top Global Navigation Bar */}
      <header className="sticky top-0 z-40 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo & Identity */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 via-rose-500 to-red-600 flex items-center justify-center text-white shadow-md shadow-amber-500/20">
                <Flame className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-base font-black tracking-tight text-slate-900 dark:text-white">
                    EcoGuard <span className="text-amber-500 font-mono font-medium text-xs px-1.5 py-0.5 rounded bg-amber-500/10 border border-amber-500/30">ML Suite</span>
                  </h1>
                </div>
                <p className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
                  Algerian Forest Fires Benchmark • Canadian FWI Multi-Class System
                </p>
              </div>
            </div>

            {/* Navigation Tabs */}
            <nav className="hidden md:flex items-center gap-1 bg-slate-100 dark:bg-slate-800/80 p-1 rounded-xl text-xs">
              <button
                onClick={() => setActiveTab('predictor')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold transition ${
                  activeTab === 'predictor'
                    ? 'bg-white dark:bg-slate-900 text-amber-600 dark:text-amber-400 shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <Sliders className="w-3.5 h-3.5" />
                <span>Live Predictor</span>
              </button>

              <button
                onClick={() => setActiveTab('lab')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold transition ${
                  activeTab === 'lab'
                    ? 'bg-white dark:bg-slate-900 text-amber-600 dark:text-amber-400 shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <Cpu className="w-3.5 h-3.5" />
                <span>ML Training Lab</span>
              </button>

              <button
                onClick={() => setActiveTab('data')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold transition ${
                  activeTab === 'data'
                    ? 'bg-white dark:bg-slate-900 text-amber-600 dark:text-amber-400 shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <Database className="w-3.5 h-3.5" />
                <span>Dataset & EDA</span>
              </button>

              <button
                onClick={() => setActiveTab('paper')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold transition ${
                  activeTab === 'paper'
                    ? 'bg-white dark:bg-slate-900 text-amber-600 dark:text-amber-400 shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <FileText className="w-3.5 h-3.5" />
                <span>Technical Paper & Viva</span>
              </button>

              <button
                onClick={() => setActiveTab('roadmap')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold transition ${
                  activeTab === 'roadmap'
                    ? 'bg-white dark:bg-slate-900 text-amber-600 dark:text-amber-400 shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>10-Day Plan</span>
              </button>
            </nav>

            {/* Quick Actions & Utilities */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsCodeModalOpen(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition shadow-sm"
              >
                <Code2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Export Python / Streamlit</span>
                <span className="sm:hidden">Code</span>
              </button>

              <button
                onClick={() => setDarkMode(!darkMode)}
                className="p-2 text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                title={darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
              >
                {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation bar */}
        <div className="md:hidden overflow-x-auto px-4 py-2 border-t border-slate-200 dark:border-slate-800 flex items-center gap-1.5 text-xs">
          <button
            onClick={() => setActiveTab('predictor')}
            className={`px-3 py-1 rounded-lg font-semibold whitespace-nowrap ${
              activeTab === 'predictor' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            Predictor
          </button>
          <button
            onClick={() => setActiveTab('lab')}
            className={`px-3 py-1 rounded-lg font-semibold whitespace-nowrap ${
              activeTab === 'lab' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            ML Lab
          </button>
          <button
            onClick={() => setActiveTab('data')}
            className={`px-3 py-1 rounded-lg font-semibold whitespace-nowrap ${
              activeTab === 'data' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            Dataset & EDA
          </button>
          <button
            onClick={() => setActiveTab('paper')}
            className={`px-3 py-1 rounded-lg font-semibold whitespace-nowrap ${
              activeTab === 'paper' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            Paper & Viva
          </button>
          <button
            onClick={() => setActiveTab('roadmap')}
            className={`px-3 py-1 rounded-lg font-semibold whitespace-nowrap ${
              activeTab === 'roadmap' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            10-Day Plan
          </button>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {activeTab === 'predictor' && <PredictorTab />}
        {activeTab === 'lab' && <TrainingLabTab />}
        {activeTab === 'data' && <DatasetExplorerTab />}
        {activeTab === 'paper' && <TechnicalPaperTab />}
        {activeTab === 'roadmap' && <RoadmapTab />}
      </main>

      {/* Footer */}
      <footer className="mt-12 border-t border-slate-200 dark:border-slate-800 py-6 text-center text-xs text-slate-500 dark:text-slate-400">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Flame className="w-4 h-4 text-amber-500" />
            <span>EcoGuard: Forest Fire Risk Classification System</span>
          </div>
          <div>
            Built with Algerian Forest Fires Dataset (UCI) & Canadian Forest Fire Weather Index (FWI) System
          </div>
          <div className="font-mono text-[11px] text-slate-400">
            Random Forest Ensemble (100 Trees) • F1 Optimized
          </div>
        </div>
      </footer>

      {/* Code Export Modal */}
      <CodeExportModal
        isOpen={isCodeModalOpen}
        onClose={() => setIsCodeModalOpen(false)}
      />
    </div>
  );
}
