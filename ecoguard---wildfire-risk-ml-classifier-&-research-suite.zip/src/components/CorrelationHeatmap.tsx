import React, { useState } from 'react';
import { ALL_FEATURE_NAMES, ALGERIAN_FIRES_DATASET, computeCorrelation } from '../data/algerianFiresData';

export const CorrelationHeatmap: React.FC = () => {
  const [hoveredCell, setHoveredCell] = useState<{
    f1: string;
    f2: string;
    r: number;
    x: number;
    y: number;
  } | null>(null);

  // Compute 10x10 matrix
  const features = ALL_FEATURE_NAMES;
  const matrix: number[][] = [];

  for (let i = 0; i < features.length; i++) {
    matrix[i] = [];
    const vals1 = ALGERIAN_FIRES_DATASET.map(d => (d as unknown as Record<string, number>)[features[i]]);
    for (let j = 0; j < features.length; j++) {
      if (i === j) {
        matrix[i][j] = 1.0;
      } else {
        const vals2 = ALGERIAN_FIRES_DATASET.map(d => (d as unknown as Record<string, number>)[features[j]]);
        matrix[i][j] = computeCorrelation(vals1, vals2);
      }
    }
  }

  function getCellColor(r: number): string {
    if (r >= 0) {
      // Positive: light amber to deep fire red/orange
      // r = 0 -> rgba(255,255,255,0.05), r = 1 -> rgba(239, 68, 68, 0.85)
      return `rgba(239, 68, 68, ${Math.min(0.9, Math.max(0.08, r * 0.9))})`;
    } else {
      // Negative: light blue to deep indigo/blue
      const absR = Math.abs(r);
      return `rgba(59, 130, 246, ${Math.min(0.9, Math.max(0.08, absR * 0.9))})`;
    }
  }

  return (
    <div className="flex flex-col space-y-3">
      <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
        <span>Pearson Correlation Coefficients (<span className="font-mono">r</span>) across 244 Algerian instances</span>
        <div className="flex items-center gap-2 text-[10px]">
          <span className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded bg-blue-500 inline-block" /> -1.0 (Inverse)
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded bg-slate-300 dark:bg-slate-700 inline-block" /> 0.0
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded bg-red-500 inline-block" /> +1.0 (Direct)
          </span>
        </div>
      </div>

      <div className="overflow-x-auto pb-2">
        <div className="min-w-[560px]">
          {/* Header Row */}
          <div className="grid grid-cols-11 gap-1 text-center font-mono text-[11px] font-bold">
            <div className="p-1"></div>
            {features.map(f => (
              <div key={`head-${f}`} className="p-1 text-slate-600 dark:text-slate-300 truncate" title={f}>
                {f}
              </div>
            ))}
          </div>

          {/* Matrix Rows */}
          {features.map((fRow, i) => (
            <div key={`row-${fRow}`} className="grid grid-cols-11 gap-1 items-center mt-1">
              <div className="text-right pr-1 font-mono text-[11px] font-bold text-slate-600 dark:text-slate-300 truncate" title={fRow}>
                {fRow}
              </div>
              {features.map((fCol, j) => {
                const r = matrix[i][j];
                const isDiag = i === j;
                const textColor =
                  Math.abs(r) > 0.45 ? 'text-white font-bold' : 'text-slate-800 dark:text-slate-200 font-medium';

                return (
                  <div
                    key={`c-${i}-${j}`}
                    onMouseEnter={(e) => {
                      const rect = e.currentTarget.getBoundingClientRect();
                      setHoveredCell({
                        f1: fRow,
                        f2: fCol,
                        r,
                        x: rect.left + rect.width / 2,
                        y: rect.top,
                      });
                    }}
                    onMouseLeave={() => setHoveredCell(null)}
                    style={{ backgroundColor: getCellColor(r) }}
                    className={`h-9 rounded flex items-center justify-center font-mono text-[11px] cursor-pointer transition-transform hover:scale-110 hover:z-10 hover:shadow-md ${textColor} border border-slate-200/20 dark:border-slate-800/40`}
                  >
                    {isDiag ? '1.0' : r > 0 ? `+${r.toFixed(2)}` : r.toFixed(2)}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>

      {/* Dynamic explanation card for hovered relationship */}
      {hoveredCell ? (
        <div className="p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/30 text-xs flex items-center justify-between animate-fadeIn">
          <div>
            <span className="font-bold text-slate-900 dark:text-white">
              {hoveredCell.f1} ↔ {hoveredCell.f2}:
            </span>{' '}
            <span className="font-mono font-semibold text-amber-600 dark:text-amber-400">
              r = {hoveredCell.r > 0 ? `+${hoveredCell.r.toFixed(3)}` : hoveredCell.r.toFixed(3)}
            </span>
            <span className="text-slate-600 dark:text-slate-300 ml-2">
              {Math.abs(hoveredCell.r) >= 0.7
                ? 'Strong statistical correlation. High collinearity impact.'
                : Math.abs(hoveredCell.r) >= 0.4
                ? 'Moderate correlation.'
                : 'Weak / non-linear correlation.'}
            </span>
          </div>
        </div>
      ) : (
        <div className="p-2.5 rounded-lg bg-slate-100 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-400 flex items-center gap-2">
          <span className="font-semibold text-slate-800 dark:text-slate-200">Key Finding:</span>
          <span>
            Notice high positive correlation between <strong>ISI & FWI (r = +0.87)</strong> and strong inverse correlation between <strong>RH & FWI (r = -0.57)</strong>. Hover over any cell to inspect!
          </span>
        </div>
      )}
    </div>
  );
};
