import React, { useState, useMemo } from 'react';
import {
  DEFAULT_PIPELINE,
  RiskCategory,
  RISK_COLORS,
  RISK_CLASSES
} from '../ml/engine';
import { RiskGauge } from './RiskGauge';
import {
  Flame,
  Wind,
  Droplets,
  Thermometer,
  TreePine,
  Sliders,
  AlertTriangle,
  CheckCircle2,
  RefreshCw,
  Sparkles,
  ChevronDown,
  ChevronUp,
  History,
  TrendingUp,
  Download
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface PresetScenario {
  name: string;
  desc: string;
  icon: string;
  badge: RiskCategory;
  inputs: {
    temp: number;
    rh: number;
    ws: number;
    isi: number;
    bui: number;
  };
}

const PRESETS: PresetScenario[] = [
  {
    name: 'Extreme Saharan Sirocco Heatwave',
    desc: 'Severe dry desert wind from Sahara, high heat, dangerously desiccated forest brush (Sidi Bel-Abbes August peak).',
    icon: '🔥',
    badge: 'Extreme',
    inputs: { temp: 41, rh: 26, ws: 16, isi: 16.5, bui: 62.4 },
  },
  {
    name: 'High Spread Gale (Active Fire)',
    desc: 'High ambient temperature with strong Mediterranean wind gust driving surface spread.',
    icon: '⚡',
    badge: 'High',
    inputs: { temp: 37, rh: 38, ws: 18, isi: 11.5, bui: 45.0 },
  },
  {
    name: 'Dry Summer Afternoon',
    desc: 'Typical hot Mediterranean July afternoon with elevated fine fuel flammability.',
    icon: '☀️',
    badge: 'Moderate',
    inputs: { temp: 33, rh: 55, ws: 14, isi: 7.2, bui: 22.0 },
  },
  {
    name: 'Wet Spring Rain Shower',
    desc: 'Recent precipitation, high moisture saturation, very low fire risk.',
    icon: '🌧️',
    badge: 'Low',
    inputs: { temp: 24, rh: 85, ws: 15, isi: 0.2, bui: 2.1 },
  },
  {
    name: 'Vegetation Spread Spike (High ISI)',
    desc: 'Moderate fuel buildup but rapid forward spread velocity due to wind tunneling.',
    icon: '🌲',
    badge: 'High',
    inputs: { temp: 35, rh: 44, ws: 22, isi: 14.8, bui: 24.5 },
  },
  {
    name: 'Deep Organic Layer Drought (High BUI)',
    desc: 'Months of cumulative rain deficit drying deep duff soils.',
    icon: '🏜️',
    badge: 'High',
    inputs: { temp: 36, rh: 40, ws: 13, isi: 8.5, bui: 58.0 },
  },
];

interface LoggedPrediction {
  id: string;
  timestamp: string;
  temp: number;
  rh: number;
  ws: number;
  isi: number;
  bui: number;
  prediction: RiskCategory;
  confidence: number;
}

export const PredictorTab: React.FC = () => {
  // Input states
  const [temp, setTemp] = useState<number>(33);
  const [rh, setRh] = useState<number>(50);
  const [ws, setWs] = useState<number>(15);
  const [isi, setIsi] = useState<number>(7.5);
  const [bui, setBui] = useState<number>(24.0);

  // Advanced secondary inputs (for Canadian FWI context)
  const [showAdvanced, setShowAdvanced] = useState<boolean>(false);
  const [rain, setRain] = useState<number>(0.0);
  const [ffmc, setFfmc] = useState<number>(87.5);
  const [dmc, setDmc] = useState<number>(20.0);
  const [dc, setDc] = useState<number>(75.0);

  // What-If sensitivity state
  const [sensitivityFeature, setSensitivityFeature] = useState<'temp' | 'rh' | 'ws' | 'isi'>('temp');
  const [tempDelta, setTempDelta] = useState<number>(0);

  // Prediction History
  const [history, setHistory] = useState<LoggedPrediction[]>([]);

  // Live ML Model Inference
  const predictionResult = useMemo(() => {
    // Current input array: ['Temperature', 'RH', 'Ws', 'ISI', 'BUI']
    const rawInput = [temp + tempDelta, rh, ws, isi, bui];
    const scaled = DEFAULT_PIPELINE.scaler.transform(rawInput);
    const predCategory = DEFAULT_PIPELINE.model.predict(scaled);
    const proba = DEFAULT_PIPELINE.model.predictProba(scaled);
    const confidence = (proba[predCategory] || 0) * 100;

    // Canadian FWI approximation formula for context
    const fwiEst = Math.max(0, isi * 0.7 + bui * 0.28 + (temp - 25) * 0.15 - (rh - 50) * 0.1);

    return {
      category: predCategory,
      confidence,
      probabilities: proba,
      fwiEstimate: fwiEst,
      rawInput,
    };
  }, [temp, tempDelta, rh, ws, isi, bui]);

  const handleApplyPreset = (preset: PresetScenario) => {
    setTemp(preset.inputs.temp);
    setRh(preset.inputs.rh);
    setWs(preset.inputs.ws);
    setIsi(preset.inputs.isi);
    setBui(preset.inputs.bui);
    setTempDelta(0);
  };

  const handleSaveToHistory = () => {
    const newEntry: LoggedPrediction = {
      id: Math.random().toString(36).substring(2, 9),
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      temp: temp + tempDelta,
      rh,
      ws,
      isi,
      bui,
      prediction: predictionResult.category,
      confidence: predictionResult.confidence,
    };
    setHistory(prev => [newEntry, ...prev.slice(0, 9)]);
    confetti({ particleCount: 25, spread: 50, origin: { y: 0.7 } });
  };

  // Sensitivity curves calculation
  const sensitivityCurve = useMemo(() => {
    const points: { val: number; category: RiskCategory; prob: number }[] = [];
    if (sensitivityFeature === 'temp') {
      for (let t = 20; t <= 45; t += 2) {
        const scaled = DEFAULT_PIPELINE.scaler.transform([t, rh, ws, isi, bui]);
        const cat = DEFAULT_PIPELINE.model.predict(scaled);
        const p = DEFAULT_PIPELINE.model.predictProba(scaled)[cat] * 100;
        points.push({ val: t, category: cat, prob: p });
      }
    } else if (sensitivityFeature === 'rh') {
      for (let r = 20; r <= 90; r += 5) {
        const scaled = DEFAULT_PIPELINE.scaler.transform([temp, r, ws, isi, bui]);
        const cat = DEFAULT_PIPELINE.model.predict(scaled);
        const p = DEFAULT_PIPELINE.model.predictProba(scaled)[cat] * 100;
        points.push({ val: r, category: cat, prob: p });
      }
    } else if (sensitivityFeature === 'isi') {
      for (let s = 1; s <= 20; s += 1.5) {
        const scaled = DEFAULT_PIPELINE.scaler.transform([temp, rh, ws, s, bui]);
        const cat = DEFAULT_PIPELINE.model.predict(scaled);
        const p = DEFAULT_PIPELINE.model.predictProba(scaled)[cat] * 100;
        points.push({ val: s, category: cat, prob: p });
      }
    }
    return points;
  }, [sensitivityFeature, temp, rh, ws, isi, bui]);

  const colorData = RISK_COLORS[predictionResult.category];

  return (
    <div className="space-y-6">
      {/* Presets Bar */}
      <div className="bg-white dark:bg-slate-900 rounded-xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-500" />
            <span className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
              Historical Mediterranean Scenarios & Presets
            </span>
          </div>
          <span className="text-[11px] text-slate-400">1-Click Benchmark Scenarios</span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2">
          {PRESETS.map(preset => {
            const pColor = RISK_COLORS[preset.badge];
            return (
              <button
                key={preset.name}
                onClick={() => handleApplyPreset(preset)}
                className="text-left p-2.5 rounded-lg border border-slate-200 dark:border-slate-800 hover:border-amber-500/50 bg-slate-50 dark:bg-slate-950/60 hover:bg-amber-500/5 transition flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-center justify-between gap-1 mb-1">
                    <span className="text-base">{preset.icon}</span>
                    <span
                      className="text-[9px] px-1.5 py-0.5 rounded font-bold uppercase"
                      style={{
                        backgroundColor: `${pColor.hex}25`,
                        color: pColor.hex,
                      }}
                    >
                      {preset.badge}
                    </span>
                  </div>
                  <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 group-hover:text-amber-500 line-clamp-1">
                    {preset.name}
                  </h4>
                  <p className="text-[10px] text-slate-500 line-clamp-2 mt-0.5">
                    {preset.desc}
                  </p>
                </div>
                <div className="mt-2 text-[10px] font-mono text-slate-400 flex items-center justify-between border-t border-slate-200/50 dark:border-slate-800/50 pt-1">
                  <span>{preset.inputs.temp}°C</span>
                  <span>{preset.inputs.rh}% RH</span>
                  <span>ISI {preset.inputs.isi}</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Grid: Input Simulator & Real-time Inference Gauge */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Environmental Sliders (7 cols) */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
          <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Sliders className="w-4 h-4 text-amber-500" />
                <span>Environmental Observation Inputs</span>
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Adjust weather factors and vegetation/dryness indices in real-time
              </p>
            </div>
            <button
              onClick={() => {
                setTemp(32);
                setRh(50);
                setWs(15);
                setIsi(5.0);
                setBui(10.0);
                setTempDelta(0);
              }}
              className="flex items-center gap-1 text-xs text-slate-500 hover:text-amber-500 transition px-2 py-1 rounded hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Reset</span>
            </button>
          </div>

          {/* Primary Sliders */}
          <div className="space-y-5">
            {/* Temperature */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <label className="font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
                  <Thermometer className="w-4 h-4 text-red-500" />
                  <span>Ambient Temperature (°C)</span>
                </label>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min="10"
                    max="55"
                    step="0.5"
                    value={temp}
                    onChange={e => setTemp(Number(e.target.value))}
                    className="w-16 px-2 py-0.5 text-right font-mono text-xs font-bold bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded text-slate-900 dark:text-white"
                  />
                  <span className="text-xs text-slate-400">°C</span>
                </div>
              </div>
              <input
                type="range"
                min="10"
                max="50"
                step="0.5"
                value={temp}
                onChange={e => setTemp(Number(e.target.value))}
                className="w-full accent-red-500 h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                <span>10°C (Cold Spring)</span>
                <span>30°C (Warm Summer)</span>
                <span>50°C (Extreme Heatwave)</span>
              </div>
            </div>

            {/* Relative Humidity */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <label className="font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
                  <Droplets className="w-4 h-4 text-blue-500" />
                  <span>Relative Humidity RH (%)</span>
                </label>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min="10"
                    max="100"
                    step="1"
                    value={rh}
                    onChange={e => setRh(Number(e.target.value))}
                    className="w-16 px-2 py-0.5 text-right font-mono text-xs font-bold bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded text-slate-900 dark:text-white"
                  />
                  <span className="text-xs text-slate-400">%</span>
                </div>
              </div>
              <input
                type="range"
                min="10"
                max="100"
                step="1"
                value={rh}
                onChange={e => setRh(Number(e.target.value))}
                className="w-full accent-blue-500 h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                <span>10% (Critically Desiccated)</span>
                <span>50% (Moderate)</span>
                <span>100% (Saturated Fog)</span>
              </div>
            </div>

            {/* Wind Speed */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <label className="font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
                  <Wind className="w-4 h-4 text-teal-500" />
                  <span>Wind Speed Ws (km/h)</span>
                </label>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min="0"
                    max="60"
                    step="1"
                    value={ws}
                    onChange={e => setWs(Number(e.target.value))}
                    className="w-16 px-2 py-0.5 text-right font-mono text-xs font-bold bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded text-slate-900 dark:text-white"
                  />
                  <span className="text-xs text-slate-400">km/h</span>
                </div>
              </div>
              <input
                type="range"
                min="0"
                max="50"
                step="1"
                value={ws}
                onChange={e => setWs(Number(e.target.value))}
                className="w-full accent-teal-500 h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                <span>0 km/h (Calm)</span>
                <span>20 km/h (Breezy)</span>
                <span>50 km/h (Strong Gale)</span>
              </div>
            </div>

            <div className="border-t border-slate-200 dark:border-slate-800 pt-4">
              <div className="text-xs font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400 mb-3 flex items-center gap-1.5">
                <TreePine className="w-4 h-4" />
                <span>Vegetation & Dryness Indices (Canadian FWI System)</span>
              </div>

              {/* ISI */}
              <div className="space-y-1.5 mb-4">
                <div className="flex items-center justify-between text-xs">
                  <div>
                    <label className="font-semibold text-slate-700 dark:text-slate-200">
                      Initial Spread Index (ISI)
                    </label>
                    <span className="text-[11px] text-slate-400 ml-2">Surface spread rate</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <input
                      type="number"
                      min="0"
                      max="35"
                      step="0.1"
                      value={isi}
                      onChange={e => setIsi(Number(e.target.value))}
                      className="w-16 px-2 py-0.5 text-right font-mono text-xs font-bold bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded text-slate-900 dark:text-white"
                    />
                  </div>
                </div>
                <input
                  type="range"
                  min="0"
                  max="30"
                  step="0.1"
                  value={isi}
                  onChange={e => setIsi(Number(e.target.value))}
                  className="w-full accent-amber-500 h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                  <span>0.0 (No Spread)</span>
                  <span>10.0 (Fast Spread)</span>
                  <span>30.0+ (Severe Crowning)</span>
                </div>
              </div>

              {/* BUI */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <div>
                    <label className="font-semibold text-slate-700 dark:text-slate-200">
                      Buildup Index (BUI)
                    </label>
                    <span className="text-[11px] text-slate-400 ml-2">Total fuel availability</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <input
                      type="number"
                      min="0"
                      max="100"
                      step="0.5"
                      value={bui}
                      onChange={e => setBui(Number(e.target.value))}
                      className="w-16 px-2 py-0.5 text-right font-mono text-xs font-bold bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded text-slate-900 dark:text-white"
                    />
                  </div>
                </div>
                <input
                  type="range"
                  min="0"
                  max="80"
                  step="0.5"
                  value={bui}
                  onChange={e => setBui(Number(e.target.value))}
                  className="w-full accent-amber-500 h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-slate-400 font-mono">
                  <span>0.0 (Moist Fuel)</span>
                  <span>30.0 (Combustible)</span>
                  <span>80.0+ (Deep Drought)</span>
                </div>
              </div>
            </div>

            {/* Advanced Toggle */}
            <div className="border-t border-slate-200 dark:border-slate-800 pt-3">
              <button
                onClick={() => setShowAdvanced(!showAdvanced)}
                className="flex items-center justify-between w-full text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-amber-500 transition py-1"
              >
                <span>Additional Canadian FWI Components (Rain, FFMC, DMC, DC)</span>
                {showAdvanced ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>

              {showAdvanced && (
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-3 pt-3 border-t border-slate-200/60 dark:border-slate-800/60 text-xs">
                  <div>
                    <label className="text-[11px] font-medium text-slate-500 block mb-1">Rain (mm)</label>
                    <input
                      type="number"
                      value={rain}
                      onChange={e => setRain(Number(e.target.value))}
                      step="0.1"
                      className="w-full px-2 py-1 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded font-mono text-xs text-slate-900 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-medium text-slate-500 block mb-1">FFMC (Fine Fuel)</label>
                    <input
                      type="number"
                      value={ffmc}
                      onChange={e => setFfmc(Number(e.target.value))}
                      step="0.5"
                      className="w-full px-2 py-1 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded font-mono text-xs text-slate-900 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-medium text-slate-500 block mb-1">DMC (Duff Moisture)</label>
                    <input
                      type="number"
                      value={dmc}
                      onChange={e => setDmc(Number(e.target.value))}
                      step="0.5"
                      className="w-full px-2 py-1 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded font-mono text-xs text-slate-900 dark:text-white"
                    />
                  </div>
                  <div>
                    <label className="text-[11px] font-medium text-slate-500 block mb-1">DC (Drought Code)</label>
                    <input
                      type="number"
                      value={dc}
                      onChange={e => setDc(Number(e.target.value))}
                      step="1"
                      className="w-full px-2 py-1 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded font-mono text-xs text-slate-900 dark:text-white"
                    />
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Column: Prediction Dial, Probabilities, & SOP (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Main Inference Card */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col items-center relative overflow-hidden">
            <div className="w-full flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3 mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <Flame className="w-4 h-4 text-amber-500" />
                <span>Random Forest Inference</span>
              </span>
              <span className="text-[11px] px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-mono">
                100 Estimators
              </span>
            </div>

            {/* Gauge */}
            <RiskGauge
              category={predictionResult.category}
              confidence={predictionResult.confidence}
              fwiEstimate={predictionResult.fwiEstimate}
            />

            {/* Multi-class probability breakdown */}
            <div className="w-full mt-4 space-y-2 border-t border-slate-200 dark:border-slate-800 pt-4">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1">
                <span>Class Probability Distribution</span>
                <span className="text-[11px] text-slate-400">Argmax: {predictionResult.category}</span>
              </div>

              {RISK_CLASSES.map(cls => {
                const prob = (predictionResult.probabilities[cls] || 0) * 100;
                const isSelected = predictionResult.category === cls;
                const pColor = RISK_COLORS[cls];

                return (
                  <div key={cls} className="space-y-1">
                    <div className="flex justify-between text-xs font-mono">
                      <span className={`font-semibold ${isSelected ? 'text-slate-900 dark:text-white font-bold' : 'text-slate-500 dark:text-slate-400'}`}>
                        {cls} Risk
                      </span>
                      <span className="font-bold" style={{ color: pColor.hex }}>
                        {prob.toFixed(1)}%
                      </span>
                    </div>
                    <div className="h-2 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-500"
                        style={{
                          width: `${prob}%`,
                          backgroundColor: pColor.hex,
                        }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Standard Operating Procedure (SOP) Action Guidance */}
            <div className="w-full mt-5">
              {predictionResult.category === 'Extreme' ? (
                <div className="p-3.5 rounded-xl bg-rose-950/20 border border-rose-600/40 text-rose-900 dark:text-rose-200 text-xs space-y-1">
                  <div className="flex items-center gap-2 font-bold text-rose-700 dark:text-rose-300">
                    <AlertTriangle className="w-4 h-4 text-rose-500 shrink-0" />
                    <span>CRITICAL: Dispatch Emergency Attack Crews</span>
                  </div>
                  <p className="text-[11px] leading-relaxed text-rose-800 dark:text-rose-300/80">
                    <strong>Action Required:</strong> Immediate red flag alert. Place aerial water bombers on hot standby, restrict forest access, and prepare civil evacuation routes for nearby settlements.
                  </p>
                </div>
              ) : predictionResult.category === 'High' ? (
                <div className="p-3.5 rounded-xl bg-red-500/10 border border-red-500/30 text-red-900 dark:text-red-200 text-xs space-y-1">
                  <div className="flex items-center gap-2 font-bold text-red-700 dark:text-red-400">
                    <AlertTriangle className="w-4 h-4 text-red-500 shrink-0" />
                    <span>WARNING: Alert Local Fire Monitoring Stations</span>
                  </div>
                  <p className="text-[11px] leading-relaxed text-red-800 dark:text-red-300/80">
                    <strong>Action Required:</strong> Fire towers and optical sensors to maintain continuous 360° sweeps. Ban agricultural and residential open fires.
                  </p>
                </div>
              ) : predictionResult.category === 'Moderate' ? (
                <div className="p-3.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-900 dark:text-amber-200 text-xs space-y-1">
                  <div className="flex items-center gap-2 font-bold text-amber-700 dark:text-amber-400">
                    <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0" />
                    <span>ELEVATED: Routine Aerial & Ground Patrols</span>
                  </div>
                  <p className="text-[11px] leading-relaxed text-amber-800 dark:text-amber-300/80">
                    <strong>Situation Stable with Caution:</strong> Moderate surface dry fuels. Monitor afternoon thermal peak and wind direction shifts.
                  </p>
                </div>
              ) : (
                <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-900 dark:text-emerald-200 text-xs space-y-1">
                  <div className="flex items-center gap-2 font-bold text-emerald-700 dark:text-emerald-400">
                    <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                    <span>NORMAL: Situation Stable</span>
                  </div>
                  <p className="text-[11px] leading-relaxed text-emerald-800 dark:text-emerald-300/80">
                    <strong>Routine Monitoring:</strong> Environmental parameters within safe bounds. Automated environmental telemetry logging active.
                  </p>
                </div>
              )}
            </div>

            {/* Action buttons */}
            <div className="w-full flex items-center gap-2 mt-4">
              <button
                onClick={handleSaveToHistory}
                className="flex-1 py-2 px-3 rounded-lg bg-slate-900 hover:bg-slate-800 dark:bg-slate-100 dark:hover:bg-white text-white dark:text-slate-900 text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-sm"
              >
                <History className="w-3.5 h-3.5" />
                <span>Log Prediction to Audit Record</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* What-If Sensitivity Interactive Simulator */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-amber-500" />
              <span>What-If Sensitivity Analysis (Tipping Point Explorer)</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Sweep an environmental variable to see at what critical threshold the forest transitions from Moderate to High or Extreme risk
            </p>
          </div>

          <div className="flex items-center gap-1.5 text-xs">
            <span className="text-slate-500 font-medium">Variable:</span>
            <button
              onClick={() => setSensitivityFeature('temp')}
              className={`px-2.5 py-1 rounded text-xs font-semibold transition ${
                sensitivityFeature === 'temp'
                  ? 'bg-amber-500 text-slate-950 font-bold'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
              }`}
            >
              Temperature
            </button>
            <button
              onClick={() => setSensitivityFeature('rh')}
              className={`px-2.5 py-1 rounded text-xs font-semibold transition ${
                sensitivityFeature === 'rh'
                  ? 'bg-amber-500 text-slate-950 font-bold'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
              }`}
            >
              Humidity (RH)
            </button>
            <button
              onClick={() => setSensitivityFeature('isi')}
              className={`px-2.5 py-1 rounded text-xs font-semibold transition ${
                sensitivityFeature === 'isi'
                  ? 'bg-amber-500 text-slate-950 font-bold'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
              }`}
            >
              Spread Index (ISI)
            </button>
          </div>
        </div>

        {/* Sweep curve visualization */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-2">
          {sensitivityCurve.map((pt, i) => {
            const pColor = RISK_COLORS[pt.category];
            const isCurrent =
              sensitivityFeature === 'temp'
                ? Math.abs(pt.val - (temp + tempDelta)) <= 1
                : sensitivityFeature === 'rh'
                ? Math.abs(pt.val - rh) <= 2.5
                : Math.abs(pt.val - isi) <= 0.8;

            return (
              <div
                key={`curve-${i}`}
                className={`p-2.5 rounded-lg border text-center transition flex flex-col justify-between ${
                  isCurrent
                    ? 'ring-2 ring-amber-500 bg-amber-500/10 border-amber-500/40 shadow-sm'
                    : 'bg-slate-50 dark:bg-slate-950/40 border-slate-200 dark:border-slate-800'
                }`}
              >
                <div className="text-[10px] font-mono text-slate-500">
                  {sensitivityFeature === 'temp' && `${pt.val}°C`}
                  {sensitivityFeature === 'rh' && `${pt.val}% RH`}
                  {sensitivityFeature === 'isi' && `ISI ${pt.val.toFixed(1)}`}
                </div>
                <div
                  className="my-1 text-xs font-bold uppercase truncate"
                  style={{ color: pColor.hex }}
                >
                  {pt.category}
                </div>
                <div className="text-[10px] font-mono text-slate-400">
                  {pt.prob.toFixed(0)}% conf
                </div>
              </div>
            );
          })}
        </div>

        {/* Dynamic Heatwave delta slider */}
        <div className="bg-slate-50 dark:bg-slate-950/60 p-3 rounded-xl border border-slate-200 dark:border-slate-800 flex flex-col md:flex-row items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <Thermometer className="w-4 h-4 text-rose-500" />
            <span className="font-semibold text-slate-700 dark:text-slate-300">
              Climate Shift / Heatwave Temperature Delta:
            </span>
            <span className="font-mono font-bold text-rose-600 dark:text-rose-400">
              {tempDelta > 0 ? `+${tempDelta}°C` : `${tempDelta}°C`} (Simulated {temp + tempDelta}°C)
            </span>
          </div>

          <div className="flex items-center gap-2 w-full md:w-64">
            <span className="text-[10px] text-slate-400">-5°C</span>
            <input
              type="range"
              min="-5"
              max="15"
              step="1"
              value={tempDelta}
              onChange={e => setTempDelta(Number(e.target.value))}
              className="w-full accent-rose-500 h-1.5 bg-slate-200 dark:bg-slate-800 rounded-lg cursor-pointer"
            />
            <span className="text-[10px] text-slate-400">+15°C</span>
          </div>
        </div>
      </div>

      {/* History Log if available */}
      {history.length > 0 && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
              <History className="w-4 h-4 text-amber-500" />
              <span>Incident Prediction Audit Log ({history.length} Entries)</span>
            </div>
            <button
              onClick={() => setHistory([])}
              className="text-xs text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
            >
              Clear Log
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400">
                <tr>
                  <th className="p-2">Time</th>
                  <th className="p-2">Temp</th>
                  <th className="p-2">RH</th>
                  <th className="p-2">Wind</th>
                  <th className="p-2">ISI</th>
                  <th className="p-2">BUI</th>
                  <th className="p-2">Predicted Risk</th>
                  <th className="p-2">Confidence</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {history.map(item => {
                  const hColor = RISK_COLORS[item.prediction];
                  return (
                    <tr key={item.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                      <td className="p-2 text-slate-400">{item.timestamp}</td>
                      <td className="p-2">{item.temp}°C</td>
                      <td className="p-2">{item.rh}%</td>
                      <td className="p-2">{item.ws} km/h</td>
                      <td className="p-2">{item.isi}</td>
                      <td className="p-2">{item.bui}</td>
                      <td className="p-2">
                        <span
                          className="px-2 py-0.5 rounded font-bold uppercase text-[10px]"
                          style={{
                            backgroundColor: `${hColor.hex}25`,
                            color: hColor.hex,
                          }}
                        >
                          {item.prediction}
                        </span>
                      </td>
                      <td className="p-2 font-bold">{item.confidence.toFixed(1)}%</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
