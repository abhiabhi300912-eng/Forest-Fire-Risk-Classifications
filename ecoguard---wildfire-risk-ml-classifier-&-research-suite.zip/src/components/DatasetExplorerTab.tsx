import React, { useState, useMemo } from 'react';
import {
  ALGERIAN_FIRES_DATASET,
  FireRecord,
  DATASET_STATS,
  ALL_FEATURE_NAMES
} from '../data/algerianFiresData';
import { RISK_COLORS, RiskCategory } from '../ml/engine';
import { CorrelationHeatmap } from './CorrelationHeatmap';
import { ScatterPlot } from './ScatterPlot';
import {
  Database,
  Search,
  Filter,
  Download,
  Table,
  Grid3X3,
  ScatterChart,
  BarChart,
  Calendar,
  MapPin,
  ChevronLeft,
  ChevronRight,
  Flame
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const DatasetExplorerTab: React.FC = () => {
  const [activeSubTab, setActiveSubTab] = useState<'table' | 'correlation' | 'scatter' | 'distributions'>('table');

  // Filters
  const [regionFilter, setRegionFilter] = useState<'All' | 'Bejaia' | 'Sidi Bel-abbes'>('All');
  const [riskFilter, setRiskFilter] = useState<'All' | RiskCategory>('All');
  const [classFilter, setClassFilter] = useState<'All' | 'fire' | 'not fire'>('All');
  const [monthFilter, setMonthFilter] = useState<'All' | '6' | '7' | '8' | '9'>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Pagination & Sorting
  const [page, setPage] = useState<number>(1);
  const pageSize = 15;
  const [sortField, setSortField] = useState<keyof FireRecord>('id');
  const [sortAsc, setSortAsc] = useState<boolean>(true);

  // Filtered dataset
  const filteredData = useMemo(() => {
    return ALGERIAN_FIRES_DATASET.filter(row => {
      if (regionFilter !== 'All' && row.Region !== regionFilter) return false;
      if (riskFilter !== 'All' && row.Risk_Level !== riskFilter) return false;
      if (classFilter !== 'All' && row.Classes !== classFilter) return false;
      if (monthFilter !== 'All' && row.month.toString() !== monthFilter) return false;
      if (searchQuery.trim() !== '') {
        const q = searchQuery.toLowerCase();
        const matches =
          row.Region.toLowerCase().includes(q) ||
          row.Classes.toLowerCase().includes(q) ||
          row.Risk_Level.toLowerCase().includes(q) ||
          row.Temperature.toString().includes(q) ||
          row.FWI.toString().includes(q);
        if (!matches) return false;
      }
      return true;
    });
  }, [regionFilter, riskFilter, classFilter, monthFilter, searchQuery]);

  // Sorted data
  const sortedData = useMemo(() => {
    return [...filteredData].sort((a, b) => {
      const aVal = a[sortField];
      const bVal = b[sortField];
      if (typeof aVal === 'string' && typeof bVal === 'string') {
        return sortAsc ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
      }
      return sortAsc ? (aVal as number) - (bVal as number) : (bVal as number) - (aVal as number);
    });
  }, [filteredData, sortField, sortAsc]);

  const totalPages = Math.ceil(sortedData.length / pageSize) || 1;
  const paginatedData = sortedData.slice((page - 1) * pageSize, page * pageSize);

  const handleSort = (field: keyof FireRecord) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(true);
    }
  };

  const handleExportCSV = () => {
    const headers = [
      'id', 'day', 'month', 'year', 'Temperature', 'RH', 'Ws', 'Rain',
      'FFMC', 'DMC', 'DC', 'ISI', 'BUI', 'FWI', 'Classes', 'Region', 'Risk_Level'
    ];
    const rows = sortedData.map(r => [
      r.id, r.day, r.month, r.year, r.Temperature, r.RH, r.Ws, r.Rain,
      r.FFMC, r.DMC, r.DC, r.ISI, r.BUI, r.FWI, r.Classes, r.Region, r.Risk_Level
    ]);
    const csvContent = [headers.join(','), ...rows.map(row => row.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `algerian_forest_fires_${regionFilter.toLowerCase()}_cleaned.csv`;
    link.click();
    URL.revokeObjectURL(url);
    confetti({ particleCount: 30, spread: 60, origin: { y: 0.8 } });
  };

  return (
    <div className="space-y-6">
      {/* Top Banner Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <div className="bg-white dark:bg-slate-900 rounded-xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="text-xs text-slate-500 font-semibold mb-1">Total Instances</div>
          <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white">
            {filteredData.length} <span className="text-xs text-slate-400 font-normal">/ 244</span>
          </div>
          <div className="text-[10px] text-slate-400 mt-1">Both Algerian regions</div>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="text-xs text-slate-500 font-semibold mb-1">Active Fires</div>
          <div className="text-2xl font-bold font-mono text-red-500">
            {filteredData.filter(d => d.Classes === 'fire').length}
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            {((filteredData.filter(d => d.Classes === 'fire').length / (filteredData.length || 1)) * 100).toFixed(1)}% of filtered
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="text-xs text-slate-500 font-semibold mb-1">Mean Temp / Humidity</div>
          <div className="text-2xl font-bold font-mono text-amber-500">
            {DATASET_STATS.Temperature.mean.toFixed(1)}°C
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            Mean RH: {DATASET_STATS.RH.mean.toFixed(1)}%
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="text-xs text-slate-500 font-semibold mb-1">High & Extreme Days</div>
          <div className="text-2xl font-bold font-mono text-rose-600 dark:text-rose-400">
            {filteredData.filter(d => d.Risk_Level === 'High' || d.Risk_Level === 'Extreme').length}
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            FWI &gt; 15.0 critical threshold
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="text-xs text-slate-500 font-semibold mb-1">Max Fire Weather Index</div>
          <div className="text-2xl font-bold font-mono text-purple-600 dark:text-purple-400">
            33.4
          </div>
          <div className="text-[10px] text-slate-400 mt-1">Peak in Sidi Bel-Abbes</div>
        </div>
      </div>

      {/* Explorer Container */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
        {/* Navigation & Controls */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-4">
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800/80 p-1 rounded-xl text-xs">
            <button
              onClick={() => setActiveSubTab('table')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition ${
                activeSubTab === 'table'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm font-semibold'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Table className="w-3.5 h-3.5 text-amber-500" />
              <span>Dataset Table ({filteredData.length})</span>
            </button>
            <button
              onClick={() => setActiveSubTab('correlation')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition ${
                activeSubTab === 'correlation'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm font-semibold'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Grid3X3 className="w-3.5 h-3.5 text-amber-500" />
              <span>Correlation Heatmap</span>
            </button>
            <button
              onClick={() => setActiveSubTab('scatter')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition ${
                activeSubTab === 'scatter'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-sm font-semibold'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <ScatterChart className="w-3.5 h-3.5 text-amber-500" />
              <span>Scatter Explorer</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleExportCSV}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition shadow-sm"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV ({filteredData.length})</span>
            </button>
          </div>
        </div>

        {/* Filters Bar (Only on Table view or global) */}
        <div className="flex flex-wrap items-center justify-between gap-3 text-xs bg-slate-50 dark:bg-slate-950/40 p-3 rounded-xl border border-slate-200 dark:border-slate-800">
          <div className="flex flex-wrap items-center gap-3">
            {/* Search */}
            <div className="relative w-44">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search values..."
                value={searchQuery}
                onChange={e => {
                  setSearchQuery(e.target.value);
                  setPage(1);
                }}
                className="w-full pl-8 pr-2.5 py-1.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-xs text-slate-900 dark:text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
              />
            </div>

            {/* Region */}
            <div className="flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5 text-slate-400" />
              <select
                value={regionFilter}
                onChange={e => {
                  setRegionFilter(e.target.value as unknown as 'All' | 'Bejaia' | 'Sidi Bel-abbes');
                  setPage(1);
                }}
                className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-2 py-1.5 text-xs text-slate-800 dark:text-slate-200"
              >
                <option value="All">All Regions (244)</option>
                <option value="Bejaia">Bejaia Region (122)</option>
                <option value="Sidi Bel-abbes">Sidi Bel-abbes Region (122)</option>
              </select>
            </div>

            {/* Risk Category */}
            <div className="flex items-center gap-1">
              <Flame className="w-3.5 h-3.5 text-slate-400" />
              <select
                value={riskFilter}
                onChange={e => {
                  setRiskFilter(e.target.value as unknown as 'All' | RiskCategory);
                  setPage(1);
                }}
                className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-2 py-1.5 text-xs text-slate-800 dark:text-slate-200"
              >
                <option value="All">All Risk Tiers</option>
                <option value="Low">Low Risk</option>
                <option value="Moderate">Moderate Risk</option>
                <option value="High">High Risk</option>
                <option value="Extreme">Extreme Risk</option>
              </select>
            </div>

            {/* Month */}
            <div className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <select
                value={monthFilter}
                onChange={e => {
                  setMonthFilter(e.target.value as unknown as 'All' | '6' | '7' | '8' | '9');
                  setPage(1);
                }}
                className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg px-2 py-1.5 text-xs text-slate-800 dark:text-slate-200"
              >
                <option value="All">All Months (Jun - Sep)</option>
                <option value="6">June</option>
                <option value="7">July</option>
                <option value="8">August</option>
                <option value="9">September</option>
              </select>
            </div>
          </div>

          <div className="text-slate-500 font-medium">
            Showing {sortedData.length} records
          </div>
        </div>

        {/* View Switching */}
        {activeSubTab === 'table' && (
          <div className="space-y-4">
            <div className="overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 select-none">
                  <tr>
                    <th className="p-2.5 cursor-pointer hover:text-amber-500" onClick={() => handleSort('id')}>
                      ID {sortField === 'id' && (sortAsc ? '↑' : '↓')}
                    </th>
                    <th className="p-2.5 cursor-pointer hover:text-amber-500" onClick={() => handleSort('Region')}>
                      Region {sortField === 'Region' && (sortAsc ? '↑' : '↓')}
                    </th>
                    <th className="p-2.5 cursor-pointer hover:text-amber-500" onClick={() => handleSort('day')}>
                      Date {sortField === 'day' && (sortAsc ? '↑' : '↓')}
                    </th>
                    <th className="p-2.5 cursor-pointer hover:text-amber-500" onClick={() => handleSort('Temperature')}>
                      Temp {sortField === 'Temperature' && (sortAsc ? '↑' : '↓')}
                    </th>
                    <th className="p-2.5 cursor-pointer hover:text-amber-500" onClick={() => handleSort('RH')}>
                      RH% {sortField === 'RH' && (sortAsc ? '↑' : '↓')}
                    </th>
                    <th className="p-2.5 cursor-pointer hover:text-amber-500" onClick={() => handleSort('Ws')}>
                      Ws {sortField === 'Ws' && (sortAsc ? '↑' : '↓')}
                    </th>
                    <th className="p-2.5 cursor-pointer hover:text-amber-500" onClick={() => handleSort('Rain')}>
                      Rain {sortField === 'Rain' && (sortAsc ? '↑' : '↓')}
                    </th>
                    <th className="p-2.5 cursor-pointer hover:text-amber-500" onClick={() => handleSort('FFMC')}>
                      FFMC {sortField === 'FFMC' && (sortAsc ? '↑' : '↓')}
                    </th>
                    <th className="p-2.5 cursor-pointer hover:text-amber-500" onClick={() => handleSort('ISI')}>
                      ISI {sortField === 'ISI' && (sortAsc ? '↑' : '↓')}
                    </th>
                    <th className="p-2.5 cursor-pointer hover:text-amber-500" onClick={() => handleSort('BUI')}>
                      BUI {sortField === 'BUI' && (sortAsc ? '↑' : '↓')}
                    </th>
                    <th className="p-2.5 cursor-pointer hover:text-amber-500" onClick={() => handleSort('FWI')}>
                      FWI {sortField === 'FWI' && (sortAsc ? '↑' : '↓')}
                    </th>
                    <th className="p-2.5 cursor-pointer hover:text-amber-500" onClick={() => handleSort('Risk_Level')}>
                      Risk Category {sortField === 'Risk_Level' && (sortAsc ? '↑' : '↓')}
                    </th>
                    <th className="p-2.5 cursor-pointer hover:text-amber-500" onClick={() => handleSort('Classes')}>
                      Class {sortField === 'Classes' && (sortAsc ? '↑' : '↓')}
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                  {paginatedData.map(r => {
                    const rColor = RISK_COLORS[r.Risk_Level];
                    return (
                      <tr key={r.id} className="hover:bg-slate-50/70 dark:hover:bg-slate-800/40">
                        <td className="p-2.5 text-slate-400">#{r.id}</td>
                        <td className="p-2.5 font-sans font-medium text-slate-800 dark:text-slate-200 truncate max-w-[120px]">
                          {r.Region}
                        </td>
                        <td className="p-2.5 text-slate-500">
                          {r.day}/{r.month}/12
                        </td>
                        <td className="p-2.5 font-bold text-slate-900 dark:text-white">
                          {r.Temperature}°C
                        </td>
                        <td className="p-2.5">{r.RH}%</td>
                        <td className="p-2.5">{r.Ws} km/h</td>
                        <td className="p-2.5 text-slate-500">{r.Rain.toFixed(1)}</td>
                        <td className="p-2.5">{r.FFMC}</td>
                        <td className="p-2.5 font-semibold text-amber-600 dark:text-amber-400">{r.ISI}</td>
                        <td className="p-2.5 font-semibold text-amber-600 dark:text-amber-400">{r.BUI}</td>
                        <td className="p-2.5 font-bold text-rose-600 dark:text-rose-400">{r.FWI}</td>
                        <td className="p-2.5">
                          <span
                            className="px-2 py-0.5 rounded font-bold uppercase text-[10px] whitespace-nowrap"
                            style={{
                              backgroundColor: `${rColor.hex}25`,
                              color: rColor.hex,
                            }}
                          >
                            {r.Risk_Level}
                          </span>
                        </td>
                        <td className="p-2.5">
                          <span
                            className={`px-1.5 py-0.5 rounded text-[10px] font-bold uppercase ${
                              r.Classes === 'fire'
                                ? 'bg-red-500/20 text-red-600 dark:text-red-400'
                                : 'bg-blue-500/20 text-blue-600 dark:text-blue-400'
                            }`}
                          >
                            {r.Classes}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Pagination Controls */}
            <div className="flex items-center justify-between text-xs text-slate-500">
              <div>
                Page <span className="font-bold text-slate-800 dark:text-slate-200">{page}</span> of{' '}
                <span className="font-bold text-slate-800 dark:text-slate-200">{totalPages}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  disabled={page <= 1}
                  onClick={() => setPage(p => Math.max(1, p - 1))}
                  className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-40 transition flex items-center gap-1"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                  <span>Previous</span>
                </button>
                <button
                  disabled={page >= totalPages}
                  onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                  className="px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800 disabled:opacity-40 transition flex items-center gap-1"
                >
                  <span>Next</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        )}

        {activeSubTab === 'correlation' && <CorrelationHeatmap />}

        {activeSubTab === 'scatter' && <ScatterPlot />}
      </div>
    </div>
  );
};
