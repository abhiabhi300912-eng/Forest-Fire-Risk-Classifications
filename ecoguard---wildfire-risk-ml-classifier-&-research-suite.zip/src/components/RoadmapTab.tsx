import React, { useState, useEffect } from 'react';
import {
  Calendar,
  CheckCircle2,
  Circle,
  Clock,
  Sparkles,
  ChevronRight,
  BookOpen,
  Terminal,
  FileCheck,
  Video
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface DayMilestone {
  dayRange: string;
  title: string;
  focus: string;
  tasks: string[];
  deliverables: string[];
  tips: string;
}

const ROADMAP_STEPS: DayMilestone[] = [
  {
    dayRange: 'Day 1 – Day 2',
    title: 'Data Sourcing, Ingestion & Cleaning',
    focus: 'Download UCI Algerian Forest Fires dataset; clean column names (strip whitespace).',
    tasks: [
      'Download raw algerian_fires.csv from UCI Machine Learning Repository.',
      'Strip leading and trailing whitespace from column headers (e.g. "Classes   " → "Classes").',
      'Handle secondary header row splitting Bejaia Region and Sidi Bel-Abbes Region into distinct tagged rows.',
      'Map continuous FWI (Fire Weather Index) into 4 discrete risk tiers: Low (0-5), Moderate (5-15), High (15-25), Extreme (25+).',
      'Verify missing values and type casting for numeric features (Temperature, RH, Ws, Rain, ISI, BUI).',
    ],
    deliverables: ['Cleaned data/algerian_fires.csv', 'Data validation sanity check script'],
    tips: 'Watch out for inadvertent string values in numeric columns in the raw UCI file like "14.6 9" or misplaced characters. Strip spaces thoroughly!',
  },
  {
    dayRange: 'Day 3 – Day 4',
    title: 'Exploratory Data Analysis (EDA) & Feature Correlation',
    focus: 'Plot Correlation Heatmap; check if Temperature vs. Risk shows a linear or non-linear trend.',
    tasks: [
      'Generate 10x10 Pearson Correlation Heatmap across all meteorological and fire behavior features.',
      'Investigate collinearity between ISI, BUI, and target FWI (verify r = +0.87 correlation).',
      'Plot distribution histograms for Temperature, Relative Humidity, and Wind Speed.',
      'Create bivariate scatter plots of Temperature vs FWI and ISI vs BUI colored by Risk Category.',
      'Analyze class balance across the 4 risk tiers (noting the lower frequency of Extreme events).',
    ],
    deliverables: ['01_eda_modeling.ipynb (EDA sections)', 'Feature correlation visualizations'],
    tips: 'Notice that while Temperature correlates with fire risk, high temperature alone without low humidity or dried fine fuel (ISI) is insufficient to cause a fire.',
  },
  {
    dayRange: 'Day 5 – Day 6',
    title: 'Machine Learning Modeling & Evaluation',
    focus: 'Compare Decision Tree vs. Random Forest vs. Logistic Regression; use F1-Score as primary metric.',
    tasks: [
      'Partition dataset into 80% train and 20% test sets using stratified sampling.',
      'Fit StandardScaler on training features ["Temperature", "RH", "Ws", "ISI", "BUI"].',
      'Train baseline Logistic Regression and evaluate linear decision boundary limitations.',
      'Train single Decision Tree (CART) and note tendency to overfit small regional splits.',
      'Train 100-estimator Random Forest Classifier with bootstrap aggregation and Gini decrease.',
      'Compute 4x4 Confusion Matrix and Classification Report (Precision, Recall, F1 per class).',
      'Calculate Feature Importances to determine primary drivers (ISI & BUI prominence).',
      'Serialize trained model to models/fire_model.pkl and scaler to models/scaler.pkl.',
    ],
    deliverables: ['models/fire_model.pkl', 'models/scaler.pkl', 'Model comparison evaluation table'],
    tips: 'Use Macro F1-score as your primary figure of merit. Because Extreme risk instances are a minority class, raw accuracy is deceptive.',
  },
  {
    dayRange: 'Day 7 – Day 8',
    title: 'Interactive Application (Streamlit / Web UI)',
    focus: 'Build the UI; add input validation (e.g., Humidity cannot be > 100%); real-time risk gauges.',
    tasks: [
      'Implement Streamlit app.py with side-by-side observation input columns.',
      'Enforce strict input boundaries: Humidity (0-100%), Temperature (0-55°C), Wind Speed (0-100 km/h).',
      'Load fire_model.pkl and scaler.pkl upon startup.',
      'Display predicted risk with color coding: Green (Low), Amber (Moderate), Red (High), Dark Red (Extreme).',
      'Add confidence percentage bar and multi-class probability table.',
      'Incorporate emergency action alerts ("Alert local fire monitoring stations" for High/Extreme).',
      'Add pre-configured benchmark scenario presets (e.g. Saharan Heatwave, Mediterranean Gale).',
    ],
    deliverables: ['app.py', 'requirements.txt', 'Verified local web application running on port 8501'],
    tips: 'Make sure your Streamlit app handles edge-case values gracefully without crashing if a user enters decimal fractions.',
  },
  {
    dayRange: 'Day 9 – Day 10',
    title: 'Technical Paper, Viva Prep & Video Demo',
    focus: 'Complete research paper; practice Viva defense questions; record 2-minute demo video.',
    tasks: [
      'Draft Abstract highlighting preemptive FWI multi-class categorization.',
      'Write Related Work section detailing Canadian Forest Fire Weather Index physical formulation.',
      'Document Methodology: feature selection rationale, standard scaling, and ensemble bagging.',
      'Conduct Error Analysis: explain why confusing High and Extreme is a "safe error" compared to false negative Low predictions.',
      'Review Viva Voce cheat sheet: Why Random Forest? Handling outliers? F1 vs Accuracy justification.',
      'Record a crisp 2-minute video demo demonstrating the web app predicting "Extreme" for high temp/low humidity.',
      'Assemble technical_paper.pdf and final GitHub project repository with comprehensive README.',
    ],
    deliverables: ['technical_paper.pdf', '2-Minute Video Demo Link', 'Final GitHub Repo & README.md'],
    tips: 'In your viva defense, emphasize the asymmetric loss matrix: in life-safety systems, high-vs-extreme confusion is safe, but low-vs-extreme confusion is catastrophic.',
  },
];

export const RoadmapTab: React.FC = () => {
  const [completedTasks, setCompletedTasks] = useState<Record<string, boolean>>(() => {
    try {
      const saved = localStorage.getItem('ecoguard_roadmap_progress');
      if (saved) return JSON.parse(saved);
    } catch {}
    // Default: first 2 days completed as demonstration
    return {
      '0-0': true,
      '0-1': true,
      '0-2': true,
      '0-3': true,
      '0-4': true,
      '1-0': true,
      '1-1': true,
    };
  });

  const toggleTask = (key: string) => {
    setCompletedTasks(prev => {
      const next = { ...prev, [key]: !prev[key] };
      try {
        localStorage.setItem('ecoguard_roadmap_progress', JSON.stringify(next));
      } catch {}
      return next;
    });
  };

  const totalTasks = ROADMAP_STEPS.reduce((sum, s) => sum + s.tasks.length, 0);
  const doneTasks = Object.values(completedTasks).filter(Boolean).length;
  const progressPct = Math.round((doneTasks / totalTasks) * 100);

  useEffect(() => {
    if (progressPct === 100) {
      confetti({ particleCount: 50, spread: 80, origin: { y: 0.6 } });
    }
  }, [progressPct]);

  return (
    <div className="space-y-6">
      {/* Header Progress Banner */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wider">
              <Calendar className="w-4 h-4" />
              <span>Project Execution Roadmap</span>
            </div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white mt-1">
              10-Day Sprint Plan & Submission Checklists
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Step-by-step milestones from dataset ingestion to technical paper and 2-minute demo video
            </p>
          </div>

          <div className="text-right">
            <div className="text-2xl font-bold font-mono text-amber-500">
              {progressPct}%
            </div>
            <div className="text-xs text-slate-500 font-medium">
              {doneTasks} of {totalTasks} Tasks Completed
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="h-2.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
          <div
            className="h-full rounded-full bg-gradient-to-r from-amber-500 to-rose-500 transition-all duration-500"
            style={{ width: `${progressPct}%` }}
          />
        </div>
      </div>

      {/* Step by Step Milestones */}
      <div className="space-y-4">
        {ROADMAP_STEPS.map((step, stepIdx) => {
          const stepDoneCount = step.tasks.filter((_, tIdx) => completedTasks[`${stepIdx}-${tIdx}`]).length;
          const isAllDone = stepDoneCount === step.tasks.length;

          return (
            <div
              key={step.dayRange}
              className={`bg-white dark:bg-slate-900 rounded-2xl p-6 border transition shadow-sm ${
                isAllDone
                  ? 'border-emerald-500/30 dark:border-emerald-500/20'
                  : 'border-slate-200 dark:border-slate-800'
              }`}
            >
              {/* Milestone Header */}
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-3 mb-4">
                <div className="flex items-center gap-3">
                  <span className="px-2.5 py-1 rounded-lg bg-amber-500/10 text-amber-600 dark:text-amber-400 font-bold font-mono text-xs">
                    {step.dayRange}
                  </span>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                      {step.title}
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      <strong>Focus:</strong> {step.focus}
                    </p>
                  </div>
                </div>

                <div className="text-xs font-mono text-slate-400">
                  {stepDoneCount}/{step.tasks.length} Completed
                </div>
              </div>

              {/* Tasks Checklist */}
              <div className="space-y-2 mb-4">
                <div className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2">
                  Action Checklist:
                </div>
                {step.tasks.map((task, taskIdx) => {
                  const key = `${stepIdx}-${taskIdx}`;
                  const isChecked = !!completedTasks[key];

                  return (
                    <button
                      key={key}
                      onClick={() => toggleTask(key)}
                      className="w-full flex items-start gap-2.5 text-left p-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 transition group"
                    >
                      {isChecked ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                      ) : (
                        <Circle className="w-4 h-4 text-slate-300 dark:text-slate-600 shrink-0 mt-0.5 group-hover:text-amber-500" />
                      )}
                      <span
                        className={`text-xs ${
                          isChecked
                            ? 'line-through text-slate-400 dark:text-slate-500'
                            : 'text-slate-700 dark:text-slate-200'
                        }`}
                      >
                        {task}
                      </span>
                    </button>
                  );
                })}
              </div>

              {/* Deliverables & Pro Tips */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-3 border-t border-slate-200 dark:border-slate-800 text-xs">
                <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950/40 border border-slate-200 dark:border-slate-800">
                  <div className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5 mb-1">
                    <FileCheck className="w-3.5 h-3.5 text-amber-500" />
                    <span>Target Deliverables:</span>
                  </div>
                  <ul className="list-disc list-inside space-y-0.5 text-slate-600 dark:text-slate-400 text-[11px]">
                    {step.deliverables.map((deliv, i) => (
                      <li key={i}>{deliv}</li>
                    ))}
                  </ul>
                </div>

                <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20">
                  <div className="font-bold text-amber-800 dark:text-amber-300 flex items-center gap-1.5 mb-1">
                    <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                    <span>Senior Engineer Pro Tip:</span>
                  </div>
                  <p className="text-[11px] text-slate-700 dark:text-slate-300 leading-snug">
                    {step.tips}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
