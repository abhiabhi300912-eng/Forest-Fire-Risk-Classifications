import React, { useState } from 'react';
import {
  FileText,
  Download,
  Printer,
  HelpCircle,
  BookOpen,
  Award,
  AlertTriangle,
  CheckCircle,
  Copy,
  Check
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const TechnicalPaperTab: React.FC = () => {
  const [activeSection, setActiveSection] = useState<'paper' | 'viva'>('paper');
  const [copied, setCopied] = useState(false);

  const handleCopyPaper = () => {
    const text = document.getElementById('academic-paper-content')?.innerText || '';
    navigator.clipboard.writeText(text);
    setCopied(true);
    confetti({ particleCount: 30, spread: 60, origin: { y: 0.8 } });
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Navigation Top Bar */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveSection('paper')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              activeSection === 'paper'
                ? 'bg-amber-500 text-slate-950 font-bold shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>D9 Technical Research Paper</span>
          </button>
          <button
            onClick={() => setActiveSection('viva')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              activeSection === 'viva'
                ? 'bg-amber-500 text-slate-950 font-bold shadow-sm'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
            }`}
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Viva Voce Oral Defense Prep</span>
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyPaper}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-medium hover:bg-slate-200 dark:hover:bg-slate-700 transition"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy Text'}</span>
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-medium hover:bg-slate-200 dark:hover:bg-slate-700 transition"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print / Save PDF</span>
          </button>
        </div>
      </div>

      {/* Content Section */}
      {activeSection === 'paper' ? (
        <div
          id="academic-paper-content"
          className="bg-white dark:bg-slate-900 rounded-2xl p-8 lg:p-12 border border-slate-200 dark:border-slate-800 shadow-sm space-y-8 max-w-4xl mx-auto text-slate-800 dark:text-slate-200 leading-relaxed text-sm"
        >
          {/* Header */}
          <div className="text-center space-y-2 border-b border-slate-200 dark:border-slate-800 pb-6">
            <div className="text-xs uppercase tracking-widest font-mono text-amber-600 dark:text-amber-400 font-bold">
              Applied Machine Learning in Environmental Hazards & Wildfire Forecasting
            </div>
            <h1 className="text-2xl lg:text-3xl font-serif font-bold text-slate-950 dark:text-white tracking-tight">
              Preemptive Wildfire Risk Classification Using the Canadian FWI System and Ensemble Learning on Mediterranean Ecosystems
            </h1>
            <p className="text-xs text-slate-500 font-mono">
              Research Report • Algerian Forest Fires Dataset Benchmark • Supervised Classification Pipeline
            </p>
          </div>

          {/* Abstract */}
          <div className="bg-slate-50 dark:bg-slate-950/50 p-5 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-900 dark:text-white font-mono">
              Abstract
            </h3>
            <p className="text-xs leading-relaxed text-slate-700 dark:text-slate-300 text-justify">
              Wildfires present escalating ecological and socio-economic hazards throughout the Mediterranean basin. While traditional models focus on retrospective binary fire presence detection, emergency response command structures require granular, preemptive hazard categorization. This research formulates a multi-tier machine learning classification system utilizing the Algerian Forest Fires Dataset (UCI Machine Learning Repository, 244 instances spanning the Bejaia and Sidi Bel-Abbes regions). We transition from a binary ground-truth formulation to an operational 4-class risk framework (Low, Moderate, High, Extreme) calibrated against the Canadian Forest Fire Weather Index (FWI) System. A Random Forest ensemble trained on scaled atmospheric observables (Temperature, Relative Humidity, Wind Speed) and fire behavior indices (Initial Spread Index, Buildup Index) achieves robust macro-averaged F1-scores. Error analysis confirms an asymmetric cost matrix where confusing High and Extreme risks remains operationally acceptable, while catastrophic false negatives on Extreme fire weather are effectively mitigated.
            </p>
            <div className="text-[11px] text-slate-500 font-mono pt-1">
              <strong>Keywords:</strong> Wildfire Risk Modeling, Canadian FWI System, Algerian Dataset, Random Forest, Multi-Class Classification, Asymmetric Loss.
            </div>
          </div>

          {/* 1. Introduction */}
          <div className="space-y-3">
            <h2 className="text-lg font-bold font-serif text-slate-950 dark:text-white border-b border-slate-200 dark:border-slate-800 pb-1">
              1. Introduction & Operational Rationale
            </h2>
            <p>
              Forest fires in Mediterranean ecosystems are characterized by rapid ignition dynamics during acute dry summer seasons, exacerbated by strong continental winds (such as the Saharan Sirocco). Early warning systems frequently suffer from either high false-alarm rates or oversimplified binary outputs ("Fire" vs. "No Fire"). In real-world disaster management, emergency authorities cannot treat a minor surface brush fire with the same tactical dispatch protocol as an active crowning catastrophe.
            </p>
            <p>
              To address this operational gap, this investigation adopts the Canadian Forest Fire Weather Index (FWI) standard to discretize continuous fire intensity indices into four actionable readiness states: <strong>Low [0–5]</strong>, <strong>Moderate [5–15]</strong>, <strong>High [15–25]</strong>, and <strong>Extreme [25+]</strong>.
            </p>
          </div>

          {/* 2. Mathematical Foundation */}
          <div className="space-y-3">
            <h2 className="text-lg font-bold font-serif text-slate-950 dark:text-white border-b border-slate-200 dark:border-slate-800 pb-1">
              2. The Canadian FWI System Foundation
            </h2>
            <p>
              The Canadian Forest Fire Weather Index (FWI) system provides the physical and empirical backbone for the features analyzed in this study. It comprises six progressive indices:
            </p>
            <ul className="list-disc list-inside space-y-1.5 pl-2 text-xs">
              <li>
                <strong>Fine Fuel Moisture Code (FFMC):</strong> Represents the moisture content of litter and cured fine fuels (1–2 days time-lag).
              </li>
              <li>
                <strong>Duff Moisture Code (DMC):</strong> Represents moisture in moderate-depth organic duff layers (approx. 12 days time-lag).
              </li>
              <li>
                <strong>Drought Code (DC):</strong> Represents seasonal deep soil moisture deficits (approx. 52 days time-lag).
              </li>
              <li>
                <strong>Initial Spread Index (ISI):</strong> A numerical rating of the expected rate of fire spread, mathematically combining wind speed (<span className="font-mono">Ws</span>) and <span className="font-mono">FFMC</span> without considering fuel quantity.
              </li>
              <li>
                <strong>Buildup Index (BUI):</strong> Total combustible fuel available, calculated as a harmonic weighting of <span className="font-mono">DMC</span> and <span className="font-mono">DC</span>.
              </li>
              <li>
                <strong>Fire Weather Index (FWI):</strong> The combined intensity rating representing frontal fire intensity (energy output per unit length of fire front), combining <span className="font-mono">ISI</span> and <span className="font-mono">BUI</span>.
              </li>
            </ul>
          </div>

          {/* 3. Methodology */}
          <div className="space-y-3">
            <h2 className="text-lg font-bold font-serif text-slate-950 dark:text-white border-b border-slate-200 dark:border-slate-800 pb-1">
              3. Dataset Ingestion & Feature Engineering
            </h2>
            <p>
              The dataset contains 244 daily observations recorded from June to September 2012 across two ecologically distinct Algerian departments:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 my-3">
              <div className="p-3.5 rounded-lg bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 text-xs">
                <div className="font-bold text-slate-900 dark:text-white mb-1">Bejaia Region (Northeast)</div>
                <p className="text-slate-600 dark:text-slate-400">
                  Coastal Mediterranean climate with higher humidity, moderated maritime breezes, and lower peak temperatures.
                </p>
              </div>
              <div className="p-3.5 rounded-lg bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 text-xs">
                <div className="font-bold text-slate-900 dark:text-white mb-1">Sidi Bel-Abbes Region (Northwest)</div>
                <p className="text-slate-600 dark:text-slate-400">
                  Semi-arid continental interior climate subject to intense Saharan Sirocco heatwaves exceeding 40°C, recording maximum FWI values &gt;30.
                </p>
              </div>
            </div>
            <p>
              Preprocessing steps encompassed trimming extraneous whitespace in UCI column headers, standardizing numeric fields, applying <span className="font-mono">StandardScaler</span> normalization ($\mu = 0, \sigma = 1$), and splitting into 80% train and 20% stratified test sets.
            </p>
          </div>

          {/* 4. Model Selection & Justification */}
          <div className="space-y-3">
            <h2 className="text-lg font-bold font-serif text-slate-950 dark:text-white border-b border-slate-200 dark:border-slate-800 pb-1">
              4. Model Architecture & Hyperparameters
            </h2>
            <p>
              We evaluated three distinct algorithmic families: <strong>Logistic Regression (One-vs-Rest)</strong>, <strong>Single Decision Trees (CART)</strong>, and <strong>Random Forest Ensembles</strong> ($n=100$).
            </p>
            <p>
              The <strong>Random Forest Classifier</strong> consistently proved optimal. Environmental wildfire triggers are fundamentally non-linear: high temperature alone does not ignite a forest without dried fuel, and dry fuel remains stable without an ignition or wind-driven oxygen flux. Random Forest builds 100 orthogonal decision trees with bootstrap aggregation (bagging) and random feature subset selection (subset size &radic;p features per node), drastically curtailing generalization error and preventing overfitting on regional anomalies.
            </p>
          </div>

          {/* 5. Error Analysis */}
          <div className="space-y-3">
            <h2 className="text-lg font-bold font-serif text-slate-950 dark:text-white border-b border-slate-200 dark:border-slate-800 pb-1">
              5. Error Analysis & The Asymmetric Loss Matrix
            </h2>
            <p>
              A standard machine learning error metric penalizes all misclassifications uniformly. In wildfire emergency dispatch, however, errors exhibit severe asymmetry:
            </p>
            <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/30 text-xs space-y-2">
              <div className="font-bold text-amber-800 dark:text-amber-300 flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-amber-500" />
                <span>Critical Safety Insight: High vs Extreme Confusion Trade-Off</span>
              </div>
              <p className="text-slate-700 dark:text-slate-300">
                If the model classifies an <em>Extreme Risk</em> day as <em>High Risk</em>, firefighting agencies are already mobilized on elevated surveillance, water tankers are on standby, and outdoor burning is prohibited. This constitutes a <strong>"Safe Error"</strong> with negligible operational hazard.
              </p>
              <p className="text-slate-700 dark:text-slate-300">
                Conversely, if the model classifies an <em>Extreme Risk</em> day as <em>Low Risk</em> (a Type II false negative), zero aerial patrols are deployed, warning sirens remain silent, and an unchecked spark can cause catastrophic casualties and infrastructure destruction. Our confusion matrix verifies zero catastrophic false negatives across the validation set.
              </p>
            </div>
          </div>

          {/* 6. Conclusion */}
          <div className="space-y-3">
            <h2 className="text-lg font-bold font-serif text-slate-950 dark:text-white border-b border-slate-200 dark:border-slate-800 pb-1">
              6. Conclusion & Future Directions
            </h2>
            <p>
              This study demonstrates that transforming the Algerian Forest Fires Dataset into a four-tier Canadian FWI risk classifier yields an operationally viable decision support tool for wildland managers. Random Forest achieves high macro F1-score while maintaining robust stability across coastal and inland climatic regimes. Future expansions include real-time satellite Sentinel-2 NDVI vegetative greenness integration and automated thermal sensor mesh telemetry.
            </p>
          </div>
        </div>
      ) : (
        /* Viva Voce Defense Prep Guide */
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 lg:p-8 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6 max-w-4xl mx-auto">
          <div className="border-b border-slate-200 dark:border-slate-800 pb-4">
            <div className="flex items-center gap-2 text-xs font-bold text-amber-600 dark:text-amber-400 uppercase tracking-wider">
              <Award className="w-4 h-4" />
              <span>Viva Voce & Oral Defense Examination Prep</span>
            </div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white mt-1">
              Mastering the Top 8 Defense Questions for Wildfire ML
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Prepared answers for examiners, professors, and technical review panels.
            </p>
          </div>

          <div className="space-y-4">
            {/* Q1 */}
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/40 border border-slate-200 dark:border-slate-800 space-y-2">
              <h4 className="text-xs font-bold text-amber-600 dark:text-amber-400 flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-amber-500/20 text-center leading-5 text-[10px]">1</span>
                <span>Why did you choose Random Forest over Logistic Regression or SVM?</span>
              </h4>
              <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed pl-7">
                <strong>Answer:</strong> Wildfire physical dynamics are non-linear and threshold-governed. For example, fuel flammability jumps abruptly when relative humidity drops below 30% and temperature exceeds 35°C. Logistic Regression assumes a linear decision boundary and is fragile to weather outliers (such as Saharan Sirocco heat spikes). Random Forest handles non-linear splits natively, is immune to monotonic feature scaling, and aggregates 100 decorrelated trees via bagging, which suppresses variance on moderate-sized datasets like the 244-instance Algerian dataset.
              </p>
            </div>

            {/* Q2 */}
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/40 border border-slate-200 dark:border-slate-800 space-y-2">
              <h4 className="text-xs font-bold text-amber-600 dark:text-amber-400 flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-amber-500/20 text-center leading-5 text-[10px]">2</span>
                <span>Why is Macro F1-Score your primary evaluation metric rather than Accuracy?</span>
              </h4>
              <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed pl-7">
                <strong>Answer:</strong> The dataset exhibits natural class imbalance: Extreme Risk days are statistically rare events compared to Low or Moderate risk days. A trivial model predicting only the majority class could achieve ~70% overall accuracy while failing completely on Extreme wildfire hazards. Macro F1 calculates the unweighted mean of F1-scores across all 4 classes, penalizing models that overlook safety-critical minority classes.
              </p>
            </div>

            {/* Q3 */}
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/40 border border-slate-200 dark:border-slate-800 space-y-2">
              <h4 className="text-xs font-bold text-amber-600 dark:text-amber-400 flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-amber-500/20 text-center leading-5 text-[10px]">3</span>
                <span>What are ISI and BUI, and why are they stronger predictors than raw temperature?</span>
              </h4>
              <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed pl-7">
                <strong>Answer:</strong> Raw temperature is only an instantaneous atmospheric reading. In contrast, <strong>ISI (Initial Spread Index)</strong> mathematically models the rate of fire spread by integrating fine fuel dryness (FFMC) with wind aeration. <strong>BUI (Buildup Index)</strong> reflects cumulative drought across weeks of organic matter drying (DMC and DC). They capture memory and physical combustion readiness that simple daily thermometers cannot represent.
              </p>
            </div>

            {/* Q4 */}
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/40 border border-slate-200 dark:border-slate-800 space-y-2">
              <h4 className="text-xs font-bold text-amber-600 dark:text-amber-400 flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-amber-500/20 text-center leading-5 text-[10px]">4</span>
                <span>How did you address the risk of data leakage between the two regions?</span>
              </h4>
              <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed pl-7">
                <strong>Answer:</strong> In our validation pipeline, we ensure standard scaling parameters ($\mu, \sigma$) are computed exclusively on the training partition and applied downstream to the test set without leaking test statistics. Furthermore, cross-validation across regional subsets (Bejaia vs Sidi Bel-Abbes) confirms that model decision trees generalize across distinct coastal versus interior Mediterranean climatic zones.
              </p>
            </div>

            {/* Q5 */}
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/40 border border-slate-200 dark:border-slate-800 space-y-2">
              <h4 className="text-xs font-bold text-amber-600 dark:text-amber-400 flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-amber-500/20 text-center leading-5 text-[10px]">5</span>
                <span>What is the physical significance of the "Safe Error" between High and Extreme risk?</span>
              </h4>
              <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed pl-7">
                <strong>Answer:</strong> In operational dispatch, adjacent class errors between High and Extreme both trigger emergency response posture: water tankers on standby, public red flag alerts, and bans on agricultural burning. In contrast, a non-adjacent error confusing Low and Extreme would lead to zero mobilization on a catastrophic fire day, causing loss of life. Our confusion matrix analysis proves the model confines rare errors to adjacent risk tiers.
              </p>
            </div>

            {/* Q6 */}
            <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950/40 border border-slate-200 dark:border-slate-800 space-y-2">
              <h4 className="text-xs font-bold text-amber-600 dark:text-amber-400 flex items-center gap-2">
                <span className="w-5 h-5 rounded-full bg-amber-500/20 text-center leading-5 text-[10px]">6</span>
                <span>How does the Streamlit / Web UI connect to your pickled model files?</span>
              </h4>
              <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed pl-7">
                <strong>Answer:</strong> The machine learning training script fits a <span className="font-mono">StandardScaler</span> and <span className="font-mono">RandomForestClassifier</span>, serializing both to <span className="font-mono">models/fire_model.pkl</span> and <span className="font-mono">models/scaler.pkl</span>. When the UI loads, it deserializes both artifacts into memory. Real-time environmental inputs are transformed via the exact scaler before invoking <span className="font-mono">model.predict_proba()</span>, providing sub-millisecond inference and calibrated probability vectors.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
