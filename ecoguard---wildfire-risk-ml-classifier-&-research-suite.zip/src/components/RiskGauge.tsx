import React from 'react';
import { RiskCategory, RISK_COLORS } from '../ml/engine';

interface RiskGaugeProps {
  category: RiskCategory;
  confidence: number;
  fwiEstimate?: number;
}

export const RiskGauge: React.FC<RiskGaugeProps> = ({ category, confidence, fwiEstimate }) => {
  // Angle range: -90 deg (left) to +90 deg (right) -> total 180 degrees
  // Low: 0-25% (-90 to -45 deg)
  // Moderate: 25-50% (-45 to 0 deg)
  // High: 50-75% (0 to 45 deg)
  // Extreme: 75-100% (45 to 90 deg)
  const categoryAngles: Record<RiskCategory, number> = {
    Low: -67.5,
    Moderate: -22.5,
    High: 22.5,
    Extreme: 67.5,
  };

  const currentAngle = categoryAngles[category];
  const colorData = RISK_COLORS[category];

  return (
    <div className="flex flex-col items-center justify-center p-4">
      <div className="relative w-64 h-36 flex items-center justify-center">
        <svg viewBox="0 0 200 115" className="w-full h-full overflow-visible">
          <defs>
            <linearGradient id="gaugeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#10B981" />
              <stop offset="33%" stopColor="#F59E0B" />
              <stop offset="66%" stopColor="#EF4444" />
              <stop offset="100%" stopColor="#991B1B" />
            </linearGradient>
            <filter id="gaugeGlow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* Background track */}
          <path
            d="M 20 100 A 80 80 0 0 1 180 100"
            fill="none"
            stroke="currentColor"
            strokeWidth="14"
            className="text-slate-200 dark:text-slate-800"
            strokeLinecap="round"
          />

          {/* Color track segments */}
          {/* Low: 20 -> 55 */}
          <path
            d="M 20 100 A 80 80 0 0 1 43.4 43.4"
            fill="none"
            stroke="#10B981"
            strokeWidth="14"
            strokeLinecap="round"
            className="opacity-80"
          />
          {/* Moderate: 43.4 -> 100 20 */}
          <path
            d="M 43.4 43.4 A 80 80 0 0 1 100 20"
            fill="none"
            stroke="#F59E0B"
            strokeWidth="14"
            className="opacity-80"
          />
          {/* High: 100 20 -> 156.6 43.4 */}
          <path
            d="M 100 20 A 80 80 0 0 1 156.6 43.4"
            fill="none"
            stroke="#EF4444"
            strokeWidth="14"
            className="opacity-80"
          />
          {/* Extreme: 156.6 43.4 -> 180 100 */}
          <path
            d="M 156.6 43.4 A 80 80 0 0 1 180 100"
            fill="none"
            stroke="#991B1B"
            strokeWidth="14"
            strokeLinecap="round"
            className="opacity-90"
          />

          {/* Center Pivot */}
          <circle cx="100" cy="100" r="10" fill="#1E293B" className="dark:fill-slate-200" />
          <circle cx="100" cy="100" r="5" fill={colorData.hex} />

          {/* Animated Needle */}
          <g
            style={{
              transformOrigin: '100px 100px',
              transform: `rotate(${currentAngle}deg)`,
              transition: 'transform 0.6s cubic-bezier(0.34, 1.56, 0.64, 1)',
            }}
          >
            <polygon
              points="97,100 103,100 101,24 99,24"
              fill={colorData.hex}
              filter="url(#gaugeGlow)"
            />
            <circle cx="100" cy="23" r="3" fill="#ffffff" />
          </g>
        </svg>

        {/* Labels under arc */}
        <div className="absolute -bottom-1 left-2 text-[10px] font-semibold text-emerald-600 dark:text-emerald-400">
          LOW
        </div>
        <div className="absolute top-2 left-10 text-[10px] font-semibold text-amber-500">
          MOD
        </div>
        <div className="absolute top-2 right-10 text-[10px] font-semibold text-red-500">
          HIGH
        </div>
        <div className="absolute -bottom-1 right-2 text-[10px] font-bold text-rose-700 dark:text-rose-400">
          EXTREME
        </div>
      </div>

      {/* Main output readout */}
      <div className="mt-3 text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-base font-bold tracking-wide border shadow-sm"
          style={{
            backgroundColor: `${colorData.hex}18`,
            borderColor: `${colorData.hex}50`,
            color: colorData.hex,
          }}
        >
          <span className="w-2.5 h-2.5 rounded-full animate-pulse" style={{ backgroundColor: colorData.hex }} />
          <span>{category.toUpperCase()} RISK</span>
        </div>
        <div className="text-xs text-slate-500 dark:text-slate-400 mt-1 font-medium">
          Model Confidence: <span className="font-semibold text-slate-800 dark:text-slate-200">{confidence.toFixed(1)}%</span>
          {fwiEstimate !== undefined && (
            <span className="ml-2 text-slate-400 dark:text-slate-500">| FWI Index: ~{fwiEstimate.toFixed(1)}</span>
          )}
        </div>
      </div>
    </div>
  );
};
