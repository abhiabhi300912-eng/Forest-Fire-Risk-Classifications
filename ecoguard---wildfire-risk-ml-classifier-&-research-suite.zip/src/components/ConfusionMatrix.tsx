import React from 'react';
import { RISK_CLASSES, RiskCategory } from '../ml/engine';

interface ConfusionMatrixProps {
  matrix: number[][];
  classNames?: RiskCategory[];
}

export const ConfusionMatrix: React.FC<ConfusionMatrixProps> = ({
  matrix,
  classNames = RISK_CLASSES,
}) => {
  // Find max value in matrix for intensity scale
  let maxVal = 1;
  let totalSamples = 0;
  matrix.forEach(row => {
    row.forEach(val => {
      if (val > maxVal) maxVal = val;
      totalSamples += val;
    });
  });

  return (
    <div className="w-full overflow-x-auto">
      <div className="min-w-[340px]">
        {/* Header label */}
        <div className="text-center text-xs font-semibold text-slate-500 dark:text-slate-400 mb-2 uppercase tracking-wider">
          Predicted Risk Category →
        </div>

        <div className="grid grid-cols-5 gap-1.5 text-center text-xs">
          {/* Top-left corner */}
          <div className="flex items-center justify-center p-2 text-[11px] font-semibold text-slate-400">
            Actual ↓
          </div>
          {classNames.map(cls => (
            <div
              key={`col-${cls}`}
              className="p-2 font-bold rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 truncate"
            >
              {cls}
            </div>
          ))}

          {/* Matrix Rows */}
          {matrix.map((row, rowIdx) => {
            const rowClass = classNames[rowIdx];
            const rowSum = row.reduce((a, b) => a + b, 0);

            return (
              <React.Fragment key={`row-${rowClass}`}>
                {/* Row label */}
                <div className="p-2 font-bold rounded bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 flex items-center justify-center truncate">
                  {rowClass}
                </div>

                {/* Cells */}
                {row.map((val, colIdx) => {
                  const isDiagonal = rowIdx === colIdx;
                  const ratio = maxVal > 0 ? val / maxVal : 0;
                  const pctOfRow = rowSum > 0 ? Math.round((val / rowSum) * 100) : 0;

                  let bgStyle = '';
                  let textColor = '';

                  if (isDiagonal) {
                    if (val > 0) {
                      bgStyle = `rgba(16, 185, 129, ${0.15 + ratio * 0.75})`;
                      textColor = ratio > 0.4 ? 'text-white' : 'text-emerald-900 dark:text-emerald-100 font-bold';
                    } else {
                      bgStyle = 'rgba(241, 245, 249, 0.5)';
                      textColor = 'text-slate-400';
                    }
                  } else {
                    if (val > 0) {
                      // Off-diagonal error
                      // Moderate error vs severe error (Low confused with Extreme)
                      const dist = Math.abs(rowIdx - colIdx);
                      if (dist >= 2) {
                        bgStyle = `rgba(239, 68, 68, ${0.2 + ratio * 0.6})`;
                        textColor = 'text-red-950 dark:text-red-100 font-bold';
                      } else {
                        bgStyle = `rgba(245, 158, 11, ${0.15 + ratio * 0.5})`;
                        textColor = 'text-amber-950 dark:text-amber-100 font-semibold';
                      }
                    } else {
                      bgStyle = 'transparent';
                      textColor = 'text-slate-400 dark:text-slate-600';
                    }
                  }

                  return (
                    <div
                      key={`cell-${rowIdx}-${colIdx}`}
                      className={`relative group rounded p-2.5 flex flex-col items-center justify-center border border-slate-200/50 dark:border-slate-800 transition-all ${textColor}`}
                      style={{ backgroundColor: bgStyle }}
                      title={`Actual: ${rowClass}, Predicted: ${classNames[colIdx]} (${val} samples, ${pctOfRow}% of actual ${rowClass})`}
                    >
                      <span className="text-sm font-bold">{val}</span>
                      <span className="text-[10px] opacity-80">{pctOfRow}%</span>

                      {/* Tooltip on hover */}
                      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 hidden group-hover:block z-20 pointer-events-none bg-slate-900 text-white text-[10px] rounded px-2 py-1 whitespace-nowrap shadow-xl">
                        True: {rowClass} | Pred: {classNames[colIdx]}
                        <br />
                        Count: {val} / {rowSum} ({pctOfRow}%)
                      </div>
                    </div>
                  );
                })}
              </React.Fragment>
            );
          })}
        </div>

        <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 mt-3 px-1">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded bg-emerald-500/70 inline-block" />
            <span>Diagonal: Correct Predictions</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded bg-amber-500/50 inline-block" />
            <span>Off-Diagonal: Misclassifications</span>
          </div>
          <div className="font-medium">Total Test: {totalSamples} instances</div>
        </div>
      </div>
    </div>
  );
};
