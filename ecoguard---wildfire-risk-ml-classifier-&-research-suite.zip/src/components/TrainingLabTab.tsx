import React, { useState } from 'react';
import {
  trainAlgerianPipeline,
  RISK_CLASSES,
  RiskCategory
} from '../ml/engine';
import { ConfusionMatrix } from './ConfusionMatrix';
import { FeatureImportanceChart } from './FeatureImportanceChart';
import {
  Play,
  RotateCcw,
  Cpu,
  BarChart3,
  Layers,
  Award,
  CheckCircle,
  HelpCircle,
  Sliders,
  Sparkles
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const TrainingLabTab: React.FC = () => {
  // Hyperparameter States
  const [modelType, setModelType] = useState<'RandomForest' | 'DecisionTree' | 'LogisticRegression'>('RandomForest');
  const [nEstimators, setNEstimators] = useState<number>(100);
  const [maxDepth, setMaxDepth] = useState<number>(6);
  const [testSplit, setTestSplit] = useState<number>(0.2);
  const [randomSeed, setRandomSeed] = useState<number>(42);

  const [isTraining, setIsTraining] = useState<boolean>(false);

  // Trained pipeline result
  const [pipelineState, setPipelineState] = useState(() =>
    trainAlgerianPipeline(100, 6, 0.2, 42, 'RandomForest')
  );

  const handleRetrain = () => {
    setIsTraining(true);
    setTimeout(() => {
      const newPipeline = trainAlgerianPipeline(nEstimators, maxDepth, testSplit, randomSeed, modelType);
      setPipelineState(newPipeline);
      setIsTraining(false);
      confetti({ particleCount: 35, spread: 60, origin: { y: 0.6 } });
    }, 200);
  };

  const evalData = pipelineState.evaluation;

  return (
    <div className="space-y-6">
      {/* Configuration & Hyperparameters Panel */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-800 pb-4">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Cpu className="w-5 h-5 text-amber-500" />
              <span>Machine Learning Experimentation Arena</span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Train, fine-tune, and evaluate models directly on the 244 Algerian Forest Fires records
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setModelType('RandomForest');
                setNEstimators(100);
                setMaxDepth(6);
                setTestSplit(0.2);
                setRandomSeed(42);
              }}
              className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition flex items-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Defaults</span>
            </button>
            <button
              onClick={handleRetrain}
              disabled={isTraining}
              className="px-4 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition flex items-center gap-2 shadow-sm disabled:opacity-50"
            >
              <Play className={`w-3.5 h-3.5 ${isTraining ? 'animate-spin' : ''}`} />
              <span>{isTraining ? 'Training Trees...' : 'Train & Evaluate Model'}</span>
            </button>
          </div>
        </div>

        {/* Algorithm Selection */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <button
            onClick={() => setModelType('RandomForest')}
            className={`p-3.5 rounded-xl border text-left transition flex flex-col justify-between ${
              modelType === 'RandomForest'
                ? 'border-amber-500 bg-amber-500/10 shadow-sm'
                : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-slate-50 dark:bg-slate-950/40'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold text-slate-900 dark:text-white">Random Forest (Recommended)</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-600 dark:text-amber-300 font-bold">
                  Ensemble
                </span>
              </div>
              <p className="text-[11px] text-slate-500 leading-snug">
                Bagged decision forest with feature subspace sampling. Captures non-linear thresholds and complex weather interactions.
              </p>
            </div>
            <div className="mt-2 text-[10px] font-mono text-slate-400">
              n_estimators={nEstimators}, criterion="gini"
            </div>
          </button>

          <button
            onClick={() => setModelType('DecisionTree')}
            className={`p-3.5 rounded-xl border text-left transition flex flex-col justify-between ${
              modelType === 'DecisionTree'
                ? 'border-amber-500 bg-amber-500/10 shadow-sm'
                : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-slate-50 dark:bg-slate-950/40'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold text-slate-900 dark:text-white">Decision Tree (CART)</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-600 dark:text-blue-300 font-bold">
                  Single Tree
                </span>
              </div>
              <p className="text-[11px] text-slate-500 leading-snug">
                Highly interpretable single binary splitting tree. Fast but prone to variance and overfitting on edge cases.
              </p>
            </div>
            <div className="mt-2 text-[10px] font-mono text-slate-400">
              max_depth={maxDepth}
            </div>
          </button>

          <button
            onClick={() => setModelType('LogisticRegression')}
            className={`p-3.5 rounded-xl border text-left transition flex flex-col justify-between ${
              modelType === 'LogisticRegression'
                ? 'border-amber-500 bg-amber-500/10 shadow-sm'
                : 'border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 bg-slate-50 dark:bg-slate-950/40'
            }`}
          >
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold text-slate-900 dark:text-white">Logistic Regression (OvR)</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-purple-500/20 text-purple-600 dark:text-purple-300 font-bold">
                  Linear Baseline
                </span>
              </div>
              <p className="text-[11px] text-slate-500 leading-snug">
                Multinomial One-vs-Rest linear classifier with Sigmoid activation. Demonstrates why linear models struggle with heatwave spikes.
              </p>
            </div>
            <div className="mt-2 text-[10px] font-mono text-slate-400">
              solver="ovr", standard_scaled
            </div>
          </button>
        </div>

        {/* Hyperparameters Controls */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-2 border-t border-slate-200 dark:border-slate-800 text-xs">
          <div>
            <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
              Number of Trees (n_estimators)
            </label>
            <select
              value={nEstimators}
              disabled={modelType !== 'RandomForest'}
              onChange={e => setNEstimators(Number(e.target.value))}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg p-2 font-mono text-xs text-slate-900 dark:text-white disabled:opacity-50"
            >
              <option value={20}>20 Trees (Fast)</option>
              <option value={50}>50 Trees</option>
              <option value={100}>100 Trees (Standard)</option>
              <option value={150}>150 Trees (Robust)</option>
            </select>
          </div>

          <div>
            <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
              Max Depth (Tree Complexity)
            </label>
            <select
              value={maxDepth}
              disabled={modelType === 'LogisticRegression'}
              onChange={e => setMaxDepth(Number(e.target.value))}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg p-2 font-mono text-xs text-slate-900 dark:text-white disabled:opacity-50"
            >
              <option value={3}>Depth 3 (High Bias)</option>
              <option value={4}>Depth 4</option>
              <option value={6}>Depth 6 (Optimal)</option>
              <option value={8}>Depth 8</option>
              <option value={10}>Depth 10 (High Variance)</option>
            </select>
          </div>

          <div>
            <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
              Test Split Ratio (Validation)
            </label>
            <select
              value={testSplit}
              onChange={e => setTestSplit(Number(e.target.value))}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg p-2 font-mono text-xs text-slate-900 dark:text-white"
            >
              <option value={0.15}>15% Test (37 test / 207 train)</option>
              <option value={0.20}>20% Test (48 test / 196 train - Standard)</option>
              <option value={0.30}>30% Test (73 test / 171 train)</option>
              <option value={0.40}>40% Test (97 test / 147 train)</option>
            </select>
          </div>

          <div>
            <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
              Random Seed (random_state)
            </label>
            <select
              value={randomSeed}
              onChange={e => setRandomSeed(Number(e.target.value))}
              className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg p-2 font-mono text-xs text-slate-900 dark:text-white"
            >
              <option value={42}>42 (Standard Benchmark)</option>
              <option value={101}>101</option>
              <option value={7}>7</option>
              <option value={999}>999</option>
            </select>
          </div>
        </div>
      </div>

      {/* Metric Cards Banner */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 rounded-xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="text-xs text-slate-500 font-semibold mb-1">Test Set Accuracy</div>
          <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white">
            {(evalData.accuracy * 100).toFixed(1)}%
          </div>
          <div className="text-[10px] text-emerald-600 dark:text-emerald-400 mt-1 font-medium">
            Across {evalData.testCount} unseen instances
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="text-xs text-slate-500 font-semibold mb-1">Macro F1-Score (Primary)</div>
          <div className="text-2xl font-bold font-mono text-amber-500">
            {evalData.macroF1.toFixed(3)}
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            Equal weight across imbalanced classes
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="text-xs text-slate-500 font-semibold mb-1">Weighted F1-Score</div>
          <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white">
            {evalData.weightedF1.toFixed(3)}
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            Weighted by class sample frequency
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="text-xs text-slate-500 font-semibold mb-1">Sample Partitioning</div>
          <div className="text-2xl font-bold font-mono text-slate-900 dark:text-white">
            {evalData.trainCount} / {evalData.testCount}
          </div>
          <div className="text-[10px] text-slate-400 mt-1">
            Train / Test instances split (244 total)
          </div>
        </div>
      </div>

      {/* Two Column Layout: Confusion Matrix & Classification Report */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Confusion Matrix (6 cols) */}
        <div className="lg:col-span-6 bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-amber-500" />
                <span>Multi-Class Confusion Matrix</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                True positive diagonal vs false positive / false negative off-diagonals
              </p>
            </div>
            <span className="text-[11px] px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 font-mono text-slate-600 dark:text-slate-400">
              4x4 Matrix
            </span>
          </div>

          <ConfusionMatrix matrix={evalData.confusionMatrix} />
        </div>

        {/* Classification Report Table (6 cols) */}
        <div className="lg:col-span-6 bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-amber-500" />
                <span>Classification Report (Precision, Recall, F1)</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Detailed performance metrics segmented per individual risk tier
              </p>
            </div>
            <span className="text-[11px] px-2 py-0.5 rounded bg-amber-500/10 text-amber-600 dark:text-amber-400 font-bold font-mono">
              F1 Primary
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 dark:text-slate-400">
                <tr>
                  <th className="p-2.5 font-bold">Class</th>
                  <th className="p-2.5 font-bold">Precision</th>
                  <th className="p-2.5 font-bold">Recall</th>
                  <th className="p-2.5 font-bold text-amber-600 dark:text-amber-400">F1-Score</th>
                  <th className="p-2.5 font-bold">Support</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {RISK_CLASSES.map(cls => {
                  const m = evalData.report[cls];
                  return (
                    <tr key={cls} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/40">
                      <td className="p-2.5 font-sans font-bold text-slate-800 dark:text-slate-200">
                        {cls} Risk
                      </td>
                      <td className="p-2.5">{m.precision.toFixed(3)}</td>
                      <td className="p-2.5">{m.recall.toFixed(3)}</td>
                      <td className="p-2.5 font-bold text-amber-600 dark:text-amber-400">
                        {m.f1.toFixed(3)}
                      </td>
                      <td className="p-2.5 text-slate-400">{m.support}</td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot className="border-t-2 border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/30 font-bold">
                <tr>
                  <td className="p-2.5">Macro Avg</td>
                  <td className="p-2.5">
                    {(
                      Object.values(evalData.report).reduce((s, c) => s + c.precision, 0) / 4
                    ).toFixed(3)}
                  </td>
                  <td className="p-2.5">
                    {(
                      Object.values(evalData.report).reduce((s, c) => s + c.recall, 0) / 4
                    ).toFixed(3)}
                  </td>
                  <td className="p-2.5 text-amber-600 dark:text-amber-400">{evalData.macroF1.toFixed(3)}</td>
                  <td className="p-2.5 text-slate-400">{evalData.testCount}</td>
                </tr>
                <tr>
                  <td className="p-2.5">Weighted Avg</td>
                  <td className="p-2.5">-</td>
                  <td className="p-2.5">-</td>
                  <td className="p-2.5 text-slate-900 dark:text-white">{evalData.weightedF1.toFixed(3)}</td>
                  <td className="p-2.5 text-slate-400">{evalData.testCount}</td>
                </tr>
              </tfoot>
            </table>
          </div>

          <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400">
            <span className="font-semibold text-slate-800 dark:text-slate-200">Metric Note:</span> In wildfire risk classification, <strong>F1-score</strong> is critical because Extreme and High risk days occur less frequently than Low risk days. High accuracy alone could be deceptive if a model failed to identify rare Extreme events.
          </div>
        </div>
      </div>

      {/* Feature Importance & Viva Defense Justification */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Feature Importance (6 cols) */}
        <div className="lg:col-span-6 bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-500" />
                <span>Feature Importance Rankings (Gini Decrease)</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Mean decrease in impurity across all decision splits
              </p>
            </div>
            <span className="text-[11px] px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 font-mono text-slate-500">
              Normalized %
            </span>
          </div>

          <FeatureImportanceChart data={evalData.featureImportances} />
        </div>

        {/* Academic Viva Voce Defense Card (6 cols) */}
        <div className="lg:col-span-6 bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
          <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-amber-500" />
                <span>Defense Justification: Why Random Forest?</span>
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Examiner response script and machine learning architectural rationale
              </p>
            </div>
            <span className="text-[11px] px-2 py-0.5 rounded bg-amber-500/10 text-amber-600 dark:text-amber-400 font-bold">
              Viva Script
            </span>
          </div>

          <div className="space-y-3 text-xs leading-relaxed text-slate-600 dark:text-slate-300">
            <blockquote className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border-l-4 border-amber-500 italic text-slate-800 dark:text-slate-200">
              "I chose a Random Forest Classifier because environmental wildfire data exhibits highly non-linear threshold behaviors. While Logistic Regression assumes a linear hyper-plane, wildfire propagation requires non-linear combinations of dry fuel (ISI/BUI) and sudden atmospheric heat spikes. Random Forest handles weather outliers (like Saharan Sirocco heatwaves) with high resilience and natively provides feature importances."
            </blockquote>

            <div className="space-y-2 pt-2">
              <div className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-900 dark:text-white">Handling Multi-Collinearity:</strong> Atmospheric indices like ISI and Temperature correlate, but tree ensembles split on subspace features rather than suffering from unstable linear matrix inversion.
                </div>
              </div>

              <div className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-900 dark:text-white">Variance Reduction through Bagging:</strong> Individual decision trees tend to overfit small regional datasets (244 samples); bagging 100 trees reduces variance exponentially.
                </div>
              </div>

              <div className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                <div>
                  <strong className="text-slate-900 dark:text-white">Calibrated Class Probabilities:</strong> Enables probabilistic decision boundaries, permitting emergency dispatchers to set safety-critical probability cutoffs.
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
