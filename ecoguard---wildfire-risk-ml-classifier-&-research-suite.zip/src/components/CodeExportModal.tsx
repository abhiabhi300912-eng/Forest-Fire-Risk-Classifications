import React, { useState } from 'react';
import { Copy, Check, X, FileCode, Terminal, BookOpen, Download } from 'lucide-react';
import confetti from 'canvas-confetti';

interface CodeExportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const STREAMLIT_CODE = `import streamlit as st
import pandas as pd
import numpy as np
import pickle

# Load model and scaler trained on Algerian Forest Fires Dataset
try:
    model = pickle.load(open('models/fire_model.pkl', 'rb'))
    scaler = pickle.load(open('models/scaler.pkl', 'rb'))
except Exception as e:
    st.error(f"Error loading model files: {e}. Please run the training script first.")
    st.stop()

st.set_page_config(page_title="EcoGuard: Forest Fire Risk Classifier", layout="centered", page_icon="🔥")

st.title("🔥 Forest Fire Risk Classification")
st.write("Enter environmental observations to predict wildfire risk level using the Canadian FWI System & Algerian Dataset.")

# Input Layout
col1, col2 = st.columns(2)

with col1:
    temp = st.number_input("Temperature (°C)", min_value=0.0, max_value=55.0, value=32.0, step=0.5)
    hum = st.number_input("Humidity RH (%)", min_value=0.0, max_value=100.0, value=45.0, step=1.0)
    wind = st.number_input("Wind Speed Ws (km/h)", min_value=0.0, max_value=100.0, value=15.0, step=1.0)

with col2:
    isi = st.number_input("Vegetation / Spread Indicator (ISI)", min_value=0.0, max_value=50.0, value=7.5, step=0.1)
    bui = st.number_input("Dryness / Buildup Indicator (BUI)", min_value=0.0, max_value=100.0, value=25.0, step=0.5)

# Prediction Logic
if st.button("🔥 Analyze Risk", type="primary", use_container_width=True):
    # Preprocess inputs
    input_data = np.array([[temp, hum, wind, isi, bui]])
    input_scaled = scaler.transform(input_data)
    
    # Predict
    prediction = model.predict(input_scaled)[0]
    probabilities = model.predict_proba(input_scaled)[0]
    classes = model.classes_
    confidence = np.max(probabilities) * 100
    
    # UI Output
    color_map = {
        "Low": "#10B981",
        "Moderate": "#F59E0B",
        "High": "#EF4444",
        "Extreme": "#991B1B"
    }
    color = color_map.get(prediction, "#EF4444")
    
    st.markdown(f"### Result: <span style='color:{color}; font-weight:bold;'>{prediction} Risk</span>", unsafe_allow_html=True)
    st.progress(confidence / 100)
    st.write(f"Confidence: **{confidence:.2f}%**")
    
    # Multi-class breakdown
    st.write("#### Class Probabilities:")
    prob_df = pd.DataFrame({
        "Category": classes,
        "Probability": [f"{p*100:.1f}%" for p in probabilities]
    })
    st.table(prob_df)
    
    # Guidance
    if prediction in ['High', 'Extreme']:
        st.error("⚠️ Action Required: Alert local fire monitoring stations & initiate tactical readiness.")
    elif prediction == 'Moderate':
        st.warning("⚡ Moderate Caution: Increase lookout patrols and restrict controlled open burns.")
    else:
        st.success("✅ Situation Stable: Continue routine automated monitoring.")
`;

const JUPYTER_CODE = `# Forest Fire Risk Classification Pipeline
# Dataset: Algerian Forest Fires Dataset (UCI Machine Learning Repository)

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix, f1_score
import pickle
import os

# 1. Load Data
# Note: Ensure headers are stripped of any accidental whitespace (common in raw UCI Algerian file)
df = pd.read_csv('data/algerian_fires.csv')
df.columns = df.columns.str.strip()

# 2. Create Target Multi-Class Risk Categories based on Canadian FWI System
def categorize_risk(fwi):
    try:
        f = float(fwi)
        if f <= 5.0:
            return 'Low'
        elif f <= 15.0:
            return 'Moderate'
        elif f <= 25.0:
            return 'High'
        else:
            return 'Extreme'
    except:
        return 'Low'

df['Risk_Level'] = df['FWI'].apply(categorize_risk)

# 3. Select Features as per Problem Statement
# Combines ambient weather + vegetation/dryness indices
features = ['Temperature', 'RH', 'Ws', 'ISI', 'BUI']
X = df[features]
y = df['Risk_Level']

# 4. Train / Test Split and Feature Standardization
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# 5. Model Training: Random Forest Classifier
# 100 decision trees with bootstrap aggregation and Gini decrease
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train_scaled, y_train)

# 6. Evaluation
y_pred = model.predict(X_test_scaled)
print("=== Classification Report ===")
print(classification_report(y_test, y_pred))

print("=== Confusion Matrix ===")
print(confusion_matrix(y_test, y_pred, labels=['Low', 'Moderate', 'High', 'Extreme']))

# Feature Importances
importances = pd.Series(model.feature_importances_, index=features).sort_values(ascending=False)
print("\\n=== Feature Importances ===")
print(importances)

# 7. Serialization for Streamlit Application
os.makedirs('models', exist_ok=True)
pickle.dump(model, open('models/fire_model.pkl', 'wb'))
pickle.dump(scaler, open('models/scaler.pkl', 'wb'))
print("\\nSuccessfully saved fire_model.pkl and scaler.pkl to models/")
`;

const REQUIREMENTS_TXT = `streamlit>=1.28.0
pandas>=2.0.0
numpy>=1.24.0
scikit-learn>=1.3.0
matplotlib>=3.7.0
seaborn>=0.12.0
`;

const README_MD = `# 🔥 EcoGuard: Wildfire Risk ML Classification

This repository contains the complete machine learning pipeline and interactive Streamlit application for predicting forest fire risk levels based on the **Algerian Forest Fires Dataset** (UCI Machine Learning Repository) and the **Canadian Forest Fire Weather Index (FWI) System**.

## 📁 Repository Structure
\`\`\`
forest-fire-risk/
├── data/
│   └── algerian_fires.csv
├── models/
│   ├── fire_model.pkl
│   └── scaler.pkl
├── notebooks/
│   └── 01_eda_modeling.ipynb
├── app.py
├── requirements.txt
├── technical_paper.pdf
└── README.md
\`\`\`

## 🚀 Quick Start

### 1. Install Dependencies
\`\`\`bash
pip install -r requirements.txt
\`\`\`

### 2. Train the Model & Export Weights
\`\`\`bash
python notebooks/01_eda_modeling.py
\`\`\`
This produces \`models/fire_model.pkl\` and \`models/scaler.pkl\`.

### 3. Launch the Streamlit App
\`\`\`bash
streamlit run app.py
\`\`\`
The application will open in your browser at \`http://localhost:8501\`.

## 🧠 Risk Category Breakdown (Canadian FWI Scale)
- **Low Risk (0 - 5)**: Minimal fire activity, surface smoldering only.
- **Moderate Risk (5 - 15)**: Noticeable spread in dry grass and brush; regular monitoring.
- **High Risk (15 - 25)**: Active crowning, rapid spread; pre-position fire suppression assets.
- **Extreme Risk (25+)**: Violent blowup conditions, long-distance spotting; emergency evacuation protocols.
`;

export const CodeExportModal: React.FC<CodeExportModalProps> = ({ isOpen, onClose }) => {
  const [activeTab, setActiveTab] = useState<'streamlit' | 'notebook' | 'requirements' | 'readme'>('streamlit');
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const currentCode =
    activeTab === 'streamlit'
      ? STREAMLIT_CODE
      : activeTab === 'notebook'
      ? JUPYTER_CODE
      : activeTab === 'requirements'
      ? REQUIREMENTS_TXT
      : README_MD;

  const handleCopy = () => {
    navigator.clipboard.writeText(currentCode);
    setCopied(true);
    confetti({ particleCount: 30, spread: 60, origin: { y: 0.8 } });
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const filename =
      activeTab === 'streamlit'
        ? 'app.py'
        : activeTab === 'notebook'
        ? '01_eda_modeling.py'
        : activeTab === 'requirements'
        ? 'requirements.txt'
        : 'README.md';

    const blob = new Blob([currentCode], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fadeIn">
      <div className="relative w-full max-w-4xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/60">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-500 flex items-center justify-center">
              <FileCode className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                Python & Streamlit Source Code Repository
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Production-ready code matching the project specifications
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab selection */}
        <div className="flex items-center justify-between px-6 py-2.5 bg-slate-100/70 dark:bg-slate-950/50 border-b border-slate-200 dark:border-slate-800 text-xs">
          <div className="flex items-center gap-1">
            <button
              onClick={() => setActiveTab('streamlit')}
              className={`px-3 py-1.5 rounded-lg font-medium transition ${
                activeTab === 'streamlit'
                  ? 'bg-white dark:bg-slate-800 text-amber-600 dark:text-amber-400 shadow-sm font-semibold'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              app.py (Streamlit)
            </button>
            <button
              onClick={() => setActiveTab('notebook')}
              className={`px-3 py-1.5 rounded-lg font-medium transition ${
                activeTab === 'notebook'
                  ? 'bg-white dark:bg-slate-800 text-amber-600 dark:text-amber-400 shadow-sm font-semibold'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              01_eda_modeling.py
            </button>
            <button
              onClick={() => setActiveTab('requirements')}
              className={`px-3 py-1.5 rounded-lg font-medium transition ${
                activeTab === 'requirements'
                  ? 'bg-white dark:bg-slate-800 text-amber-600 dark:text-amber-400 shadow-sm font-semibold'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              requirements.txt
            </button>
            <button
              onClick={() => setActiveTab('readme')}
              className={`px-3 py-1.5 rounded-lg font-medium transition ${
                activeTab === 'readme'
                  ? 'bg-white dark:bg-slate-800 text-amber-600 dark:text-amber-400 shadow-sm font-semibold'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              README.md
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownload}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-300 dark:hover:bg-slate-700 transition"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download</span>
            </button>
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-amber-500 text-slate-950 font-bold hover:bg-amber-400 transition"
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied!' : 'Copy Code'}</span>
            </button>
          </div>
        </div>

        {/* Code Content */}
        <div className="p-6 overflow-y-auto flex-1 font-mono text-xs bg-slate-950 text-slate-100">
          <pre className="whitespace-pre overflow-x-auto leading-relaxed">
            <code>{currentCode}</code>
          </pre>
        </div>

        {/* Footer info */}
        <div className="px-6 py-3 bg-slate-50 dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
          <div className="flex items-center gap-2">
            <Terminal className="w-3.5 h-3.5 text-amber-500" />
            <span>Ready for submission / production deployment</span>
          </div>
          <span className="font-mono">Python 3.9+ | scikit-learn 1.3+</span>
        </div>
      </div>
    </div>
  );
};
