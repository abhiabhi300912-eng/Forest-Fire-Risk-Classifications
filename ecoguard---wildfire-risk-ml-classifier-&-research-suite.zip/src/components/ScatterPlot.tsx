import React, { useState } from 'react';
import { ALL_FEATURE_NAMES, ALGERIAN_FIRES_DATASET, FireRecord } from '../data/algerianFiresData';
import { RISK_COLORS, RiskCategory } from '../ml/engine';

export const ScatterPlot: React.FC = () => {
  const [xFeature, setXFeature] = useState<string>('Temperature');
  const [yFeature, setYFeature] = useState<string>('FWI');
  const [colorMode, setColorMode] = useState<'risk' | 'class'>('risk');
  const [hoveredPoint, setHoveredPoint] = useState<FireRecord | null>(null);

  const xVals = ALGERIAN_FIRES_DATASET.map(d => (d as unknown as Record<string, number>)[xFeature]);
  const yVals = ALGERIAN_FIRES_DATASET.map(d => (d as unknown as Record<string, number>)[yFeature]);

  const minX = Math.min(...xVals);
  const maxX = Math.max(...xVals);
  const minY = Math.min(...yVals);
  const maxY = Math.max(...yVals);

  // SVG dimensions
  const width = 500;
  const height = 280;
  const padding = 45;

  const getSvgX = (val: number) => {
    const range = maxX - minX || 1;
    return padding + ((val - minX) / range) * (width - 2 * padding);
  };

  const getSvgY = (val: number) => {
    const range = maxY - minY || 1;
    return height - padding - ((val - minY) / range) * (height - 2 * padding);
  };

  return (
    <div className="space-y-3">
      {/* Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 text-xs bg-slate-50 dark:bg-slate-800/40 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="font-semibold text-slate-700 dark:text-slate-300">X Axis:</span>
            <select
              value={xFeature}
              onChange={e => setXFeature(e.target.value)}
              className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded px-2 py-1 text-xs text-slate-800 dark:text-slate-200"
            >
              {ALL_FEATURE_NAMES.map(f => (
                <option key={`x-${f}`} value={f}>{f}</option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="font-semibold text-slate-700 dark:text-slate-300">Y Axis:</span>
            <select
              value={yFeature}
              onChange={e => setYFeature(e.target.value)}
              className="bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded px-2 py-1 text-xs text-slate-800 dark:text-slate-200"
            >
              {ALL_FEATURE_NAMES.map(f => (
                <option key={`y-${f}`} value={f}>{f}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-slate-500 font-medium">Color By:</span>
          <button
            onClick={() => setColorMode('risk')}
            className={`px-2.5 py-1 rounded text-xs font-medium transition ${
              colorMode === 'risk'
                ? 'bg-amber-500 text-slate-950 font-bold'
                : 'bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
            }`}
          >
            Risk Category
          </button>
          <button
            onClick={() => setColorMode('class')}
            className={`px-2.5 py-1 rounded text-xs font-medium transition ${
              colorMode === 'class'
                ? 'bg-amber-500 text-slate-950 font-bold'
                : 'bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
            }`}
          >
            Fire / Not Fire
          </button>
        </div>
      </div>

      {/* SVG Canvas */}
      <div className="relative w-full overflow-hidden bg-slate-900/5 dark:bg-slate-950/40 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-center">
        <svg viewBox={`0 0 ${width} ${height}`} className="w-full h-auto max-h-[340px]">
          {/* Grid lines */}
          <line
            x1={padding}
            y1={height - padding}
            x2={width - padding}
            y2={height - padding}
            stroke="#94a3b8"
            strokeWidth="1.5"
          />
          <line
            x1={padding}
            y1={padding}
            x2={padding}
            y2={height - padding}
            stroke="#94a3b8"
            strokeWidth="1.5"
          />

          {/* Intermediate grid lines */}
          {[0.25, 0.5, 0.75].map(ratio => {
            const gy = height - padding - ratio * (height - 2 * padding);
            const gx = padding + ratio * (width - 2 * padding);
            return (
              <g key={`grid-${ratio}`}>
                <line
                  x1={padding}
                  y1={gy}
                  x2={width - padding}
                  y2={gy}
                  stroke="currentColor"
                  className="text-slate-300 dark:text-slate-800"
                  strokeDasharray="3 3"
                />
                <line
                  x1={gx}
                  y1={padding}
                  x2={gx}
                  y2={height - padding}
                  stroke="currentColor"
                  className="text-slate-300 dark:text-slate-800"
                  strokeDasharray="3 3"
                />
              </g>
            );
          })}

          {/* Axis Labels */}
          <text
            x={width / 2}
            y={height - 10}
            textAnchor="middle"
            className="text-[11px] font-semibold fill-slate-600 dark:fill-slate-400"
          >
            {xFeature} ({minX} → {maxX})
          </text>
          <text
            x={15}
            y={height / 2}
            textAnchor="middle"
            transform={`rotate(-90 15 ${height / 2})`}
            className="text-[11px] font-semibold fill-slate-600 dark:fill-slate-400"
          >
            {yFeature} ({minY} → {maxY})
          </text>

          {/* Scatter Points */}
          {ALGERIAN_FIRES_DATASET.map(d => {
            const x = (d as unknown as Record<string, number>)[xFeature];
            const y = (d as unknown as Record<string, number>)[yFeature];
            const svgX = getSvgX(x);
            const svgY = getSvgY(y);

            let color = RISK_COLORS[d.Risk_Level].hex;
            if (colorMode === 'class') {
              color = d.Classes === 'fire' ? '#EF4444' : '#3B82F6';
            }

            const isHovered = hoveredPoint?.id === d.id;

            return (
              <circle
                key={`pt-${d.id}`}
                cx={svgX}
                cy={svgY}
                r={isHovered ? 6 : 3.5}
                fill={color}
                stroke={isHovered ? '#ffffff' : 'rgba(0,0,0,0.2)'}
                strokeWidth={isHovered ? 2 : 0.5}
                className="transition-all cursor-pointer opacity-85 hover:opacity-100"
                onMouseEnter={() => setHoveredPoint(d)}
                onMouseLeave={() => setHoveredPoint(null)}
              />
            );
          })}
        </svg>

        {/* Hover Detail Card */}
        {hoveredPoint && (
          <div className="absolute top-3 right-3 bg-slate-900/90 backdrop-blur-md text-white text-xs p-3 rounded-lg border border-slate-700 shadow-xl pointer-events-none animate-fadeIn space-y-1">
            <div className="font-bold flex items-center justify-between gap-3 border-b border-slate-700 pb-1">
              <span>{hoveredPoint.Region} ({hoveredPoint.day}/{hoveredPoint.month}/2012)</span>
              <span
                className="px-1.5 py-0.5 rounded text-[10px] font-bold"
                style={{ backgroundColor: `${RISK_COLORS[hoveredPoint.Risk_Level].hex}40`, color: RISK_COLORS[hoveredPoint.Risk_Level].hex }}
              >
                {hoveredPoint.Risk_Level} Risk
              </span>
            </div>
            <div className="grid grid-cols-2 gap-x-4 gap-y-0.5 text-[11px] text-slate-300">
              <div>Temp: <span className="font-semibold text-white">{hoveredPoint.Temperature}°C</span></div>
              <div>RH: <span className="font-semibold text-white">{hoveredPoint.RH}%</span></div>
              <div>Wind: <span className="font-semibold text-white">{hoveredPoint.Ws} km/h</span></div>
              <div>Rain: <span className="font-semibold text-white">{hoveredPoint.Rain} mm</span></div>
              <div>ISI: <span className="font-semibold text-amber-300">{hoveredPoint.ISI}</span></div>
              <div>BUI: <span className="font-semibold text-amber-300">{hoveredPoint.BUI}</span></div>
              <div>FWI: <span className="font-semibold text-rose-300">{hoveredPoint.FWI}</span></div>
              <div>Class: <span className="font-semibold text-white uppercase">{hoveredPoint.Classes}</span></div>
            </div>
          </div>
        )}
      </div>

      {/* Legend */}
      <div className="flex items-center justify-center gap-4 text-xs font-medium">
        {colorMode === 'risk' ? (
          (['Low', 'Moderate', 'High', 'Extreme'] as RiskCategory[]).map(cat => (
            <div key={`legend-${cat}`} className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full" style={{ backgroundColor: RISK_COLORS[cat].hex }} />
              <span className="text-slate-700 dark:text-slate-300">{cat} ({ALGERIAN_FIRES_DATASET.filter(d => d.Risk_Level === cat).length})</span>
            </div>
          ))
        ) : (
          <>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-red-500" />
              <span className="text-slate-700 dark:text-slate-300">Fire ({ALGERIAN_FIRES_DATASET.filter(d => d.Classes === 'fire').length})</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full bg-blue-500" />
              <span className="text-slate-700 dark:text-slate-300">Not Fire ({ALGERIAN_FIRES_DATASET.filter(d => d.Classes === 'not fire').length})</span>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
