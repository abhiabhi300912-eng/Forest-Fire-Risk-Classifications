import React from 'react';
import { FeatureKey } from '../data/algerianFiresData';

interface FeatureImportanceItem {
  feature: FeatureKey;
  importance: number;
  percentage: number;
}

interface FeatureImportanceChartProps {
  data: FeatureImportanceItem[];
}

const FEATURE_DESCRIPTIONS: Record<string, string> = {
  ISI: 'Initial Spread Index: Fire propagation velocity combining wind speed & fine fuel dryness.',
  BUI: 'Buildup Index: Total combustible fuel availability combining duff layer & deep drought.',
  Temperature: 'Ambient Dry-Bulb Air Temperature (°C): Drives rapid fuel desiccation and heat transfer.',
  RH: 'Relative Humidity (%): Atmospheric vapor deficit determining surface moisture exchange.',
  Ws: 'Wind Speed (km/h): Oxygen supply rate and forward flame deflection.',
  Rain: 'Precipitation (mm): Immediate moisture replenishment quenching organic surface layers.',
  FFMC: 'Fine Fuel Moisture Code: Flammability of surface leaf litter and cured grasses.',
  DMC: 'Duff Moisture Code: Moderate-depth organic duff layer moisture.',
  DC: 'Drought Code: Seasonal deep organic layer drought index.',
};

export const FeatureImportanceChart: React.FC<FeatureImportanceChartProps> = ({ data }) => {
  const maxPct = Math.max(...data.map(d => d.percentage), 1);

  return (
    <div className="space-y-3">
      {data.map((item, index) => {
        const widthPct = Math.max(5, (item.percentage / maxPct) * 100);
        const description = FEATURE_DESCRIPTIONS[item.feature] || 'Environmental indicator';

        return (
          <div key={item.feature} className="group relative">
            <div className="flex items-center justify-between text-xs font-semibold mb-1">
              <span className="flex items-center gap-1.5 text-slate-800 dark:text-slate-200">
                <span className="w-5 h-5 rounded-full bg-slate-100 dark:bg-slate-800 text-[10px] font-bold text-slate-500 dark:text-slate-400 flex items-center justify-center">
                  #{index + 1}
                </span>
                <span className="font-mono text-sm">{item.feature}</span>
                <span className="text-[11px] font-normal text-slate-500 dark:text-slate-400">
                  {item.feature === 'ISI' && '(Fire Spread Index)'}
                  {item.feature === 'BUI' && '(Fuel Buildup Index)'}
                  {item.feature === 'Temperature' && '(Thermal Desiccation)'}
                  {item.feature === 'RH' && '(Vapor Pressure Deficit)'}
                  {item.feature === 'Ws' && '(Wind Aeration)'}
                </span>
              </span>
              <span className="font-mono font-bold text-amber-600 dark:text-amber-400">
                {item.percentage.toFixed(1)}%
              </span>
            </div>

            <div className="h-3 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden p-0.5">
              <div
                className="h-full rounded-full transition-all duration-700 bg-gradient-to-r from-amber-500 to-rose-500 shadow-sm"
                style={{ width: `${widthPct}%` }}
              />
            </div>

            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1 leading-tight">
              {description}
            </p>
          </div>
        );
      })}
    </div>
  );
};
