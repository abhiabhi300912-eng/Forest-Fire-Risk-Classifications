export interface FireRecord {
  id: number;
  day: number;
  month: number;
  year: number;
  Temperature: number;
  RH: number;
  Ws: number;
  Rain: number;
  FFMC: number;
  DMC: number;
  DC: number;
  ISI: number;
  BUI: number;
  FWI: number;
  Classes: 'fire' | 'not fire';
  Region: 'Bejaia' | 'Sidi Bel-abbes';
  Risk_Level: 'Low' | 'Moderate' | 'High' | 'Extreme';
}

export function categorizeRisk(fwi: number): 'Low' | 'Moderate' | 'High' | 'Extreme' {
  if (fwi <= 5) return 'Low';
  if (fwi <= 15) return 'Moderate';
  if (fwi <= 25) return 'High';
  return 'Extreme';
}

// 244 records faithfully reflecting the Algerian Forest Fires Dataset from UCI ML repository
export const ALGERIAN_FIRES_DATASET: FireRecord[] = [
  // Bejaia Region (June to September 2012)
  { id: 1, day: 1, month: 6, year: 2012, Temperature: 29, RH: 57, Ws: 18, Rain: 0.0, FFMC: 65.7, DMC: 3.4, DC: 7.6, ISI: 1.3, BUI: 3.4, FWI: 0.5, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 2, day: 2, month: 6, year: 2012, Temperature: 29, RH: 61, Ws: 13, Rain: 1.3, FFMC: 64.4, DMC: 4.1, DC: 7.6, ISI: 1.0, BUI: 3.9, FWI: 0.4, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 3, day: 3, month: 6, year: 2012, Temperature: 26, RH: 82, Ws: 22, Rain: 13.1, FFMC: 47.1, DMC: 2.5, DC: 7.1, ISI: 0.3, BUI: 2.7, FWI: 0.1, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 4, day: 4, month: 6, year: 2012, Temperature: 25, RH: 89, Ws: 13, Rain: 2.5, FFMC: 28.6, DMC: 1.3, DC: 6.9, ISI: 0.0, BUI: 1.7, FWI: 0.0, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 5, day: 5, month: 6, year: 2012, Temperature: 27, RH: 77, Ws: 16, Rain: 0.0, FFMC: 64.8, DMC: 3.0, DC: 14.2, ISI: 1.2, BUI: 3.9, FWI: 0.5, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 6, day: 6, month: 6, year: 2012, Temperature: 31, RH: 67, Ws: 14, Rain: 0.0, FFMC: 82.6, DMC: 5.8, DC: 22.2, ISI: 3.1, BUI: 7.0, FWI: 2.5, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 7, day: 7, month: 6, year: 2012, Temperature: 33, RH: 54, Ws: 13, Rain: 0.0, FFMC: 88.2, DMC: 9.9, DC: 30.5, ISI: 6.4, BUI: 10.9, FWI: 7.2, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 8, day: 8, month: 6, year: 2012, Temperature: 30, RH: 73, Ws: 15, Rain: 0.0, FFMC: 86.6, DMC: 12.1, DC: 38.3, ISI: 5.6, BUI: 13.5, FWI: 7.1, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 9, day: 9, month: 6, year: 2012, Temperature: 25, RH: 88, Ws: 13, Rain: 0.2, FFMC: 52.9, DMC: 7.9, DC: 38.8, ISI: 0.4, BUI: 10.5, FWI: 0.3, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 10, day: 10, month: 6, year: 2012, Temperature: 28, RH: 79, Ws: 12, Rain: 0.0, FFMC: 73.2, DMC: 9.5, DC: 46.3, ISI: 1.3, BUI: 12.6, FWI: 0.9, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 11, day: 11, month: 6, year: 2012, Temperature: 31, RH: 65, Ws: 14, Rain: 0.0, FFMC: 84.4, DMC: 13.1, DC: 53.8, ISI: 4.1, BUI: 15.8, FWI: 5.6, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 12, day: 12, month: 6, year: 2012, Temperature: 26, RH: 81, Ws: 19, Rain: 0.0, FFMC: 84.0, DMC: 13.8, DC: 61.4, ISI: 4.8, BUI: 17.7, FWI: 7.1, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 13, day: 13, month: 6, year: 2012, Temperature: 27, RH: 84, Ws: 21, Rain: 1.2, FFMC: 50.0, DMC: 6.7, DC: 17.0, ISI: 0.5, BUI: 6.7, FWI: 0.2, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 14, day: 14, month: 6, year: 2012, Temperature: 30, RH: 78, Ws: 17, Rain: 0.0, FFMC: 80.1, DMC: 8.3, DC: 25.5, ISI: 2.7, BUI: 9.7, FWI: 2.4, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 15, day: 15, month: 6, year: 2012, Temperature: 28, RH: 80, Ws: 17, Rain: 0.3, FFMC: 79.9, DMC: 11.1, DC: 33.9, ISI: 2.5, BUI: 12.6, FWI: 2.6, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 16, day: 16, month: 6, year: 2012, Temperature: 29, RH: 89, Ws: 19, Rain: 0.1, FFMC: 79.1, DMC: 9.6, DC: 16.6, ISI: 2.9, BUI: 9.9, FWI: 2.3, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 17, day: 17, month: 6, year: 2012, Temperature: 30, RH: 89, Ws: 16, Rain: 0.2, FFMC: 77.1, DMC: 8.3, DC: 17.6, ISI: 1.8, BUI: 8.6, FWI: 1.4, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 18, day: 18, month: 6, year: 2012, Temperature: 31, RH: 78, Ws: 14, Rain: 0.3, FFMC: 56.9, DMC: 1.9, DC: 8.0, ISI: 0.7, BUI: 2.4, FWI: 0.2, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 19, day: 19, month: 6, year: 2012, Temperature: 31, RH: 55, Ws: 16, Rain: 0.1, FFMC: 83.7, DMC: 4.6, DC: 12.4, ISI: 3.6, BUI: 5.0, FWI: 2.8, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 20, day: 20, month: 6, year: 2012, Temperature: 30, RH: 80, Ws: 16, Rain: 0.4, FFMC: 59.8, DMC: 3.4, DC: 27.1, ISI: 0.9, BUI: 5.1, FWI: 0.4, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 21, day: 21, month: 6, year: 2012, Temperature: 30, RH: 78, Ws: 14, Rain: 0.0, FFMC: 81.0, DMC: 6.3, DC: 31.6, ISI: 2.6, BUI: 8.4, FWI: 2.2, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 22, day: 22, month: 6, year: 2012, Temperature: 31, RH: 67, Ws: 17, Rain: 0.1, FFMC: 79.1, DMC: 7.0, DC: 39.5, ISI: 2.4, BUI: 9.7, FWI: 2.3, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 23, day: 23, month: 6, year: 2012, Temperature: 32, RH: 62, Ws: 18, Rain: 0.1, FFMC: 81.4, DMC: 8.2, DC: 47.7, ISI: 3.3, BUI: 11.5, FWI: 3.8, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 24, day: 24, month: 6, year: 2012, Temperature: 32, RH: 66, Ws: 17, Rain: 0.0, FFMC: 85.9, DMC: 11.2, DC: 55.8, ISI: 5.6, BUI: 14.9, FWI: 7.5, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 25, day: 25, month: 6, year: 2012, Temperature: 31, RH: 64, Ws: 15, Rain: 0.0, FFMC: 86.7, DMC: 14.2, DC: 63.8, ISI: 5.7, BUI: 18.3, FWI: 8.4, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 26, day: 26, month: 6, year: 2012, Temperature: 31, RH: 64, Ws: 18, Rain: 0.0, FFMC: 86.8, DMC: 17.8, DC: 71.8, ISI: 6.7, BUI: 21.6, FWI: 10.6, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 27, day: 27, month: 6, year: 2012, Temperature: 34, RH: 53, Ws: 18, Rain: 0.0, FFMC: 89.0, DMC: 21.6, DC: 80.3, ISI: 9.2, BUI: 25.8, FWI: 15.0, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 28, day: 28, month: 6, year: 2012, Temperature: 32, RH: 55, Ws: 14, Rain: 0.0, FFMC: 89.1, DMC: 25.5, DC: 88.5, ISI: 7.6, BUI: 29.7, FWI: 13.9, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 29, day: 29, month: 6, year: 2012, Temperature: 32, RH: 53, Ws: 15, Rain: 0.0, FFMC: 89.6, DMC: 30.2, DC: 96.6, ISI: 8.2, BUI: 33.7, FWI: 15.7, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'High' },
  { id: 30, day: 30, month: 6, year: 2012, Temperature: 33, RH: 52, Ws: 15, Rain: 0.0, FFMC: 89.7, DMC: 34.2, DC: 104.8, ISI: 8.5, BUI: 37.6, FWI: 16.8, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'High' },
  { id: 31, day: 1, month: 7, year: 2012, Temperature: 29, RH: 68, Ws: 19, Rain: 1.0, FFMC: 59.9, DMC: 10.1, DC: 62.6, ISI: 1.2, BUI: 14.8, FWI: 0.9, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 32, day: 2, month: 7, year: 2012, Temperature: 27, RH: 75, Ws: 19, Rain: 1.2, FFMC: 55.7, DMC: 4.8, DC: 18.0, ISI: 0.8, BUI: 5.7, FWI: 0.3, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 33, day: 3, month: 7, year: 2012, Temperature: 32, RH: 76, Ws: 20, Rain: 0.7, FFMC: 61.9, DMC: 5.6, DC: 17.6, ISI: 1.2, BUI: 6.4, FWI: 0.6, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 34, day: 4, month: 7, year: 2012, Temperature: 33, RH: 78, Ws: 17, Rain: 0.0, FFMC: 80.1, DMC: 8.2, DC: 28.5, ISI: 2.7, BUI: 9.7, FWI: 2.4, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 35, day: 5, month: 7, year: 2012, Temperature: 33, RH: 68, Ws: 15, Rain: 0.0, FFMC: 85.0, DMC: 11.0, DC: 39.5, ISI: 4.6, BUI: 13.0, FWI: 5.8, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 36, day: 6, month: 7, year: 2012, Temperature: 32, RH: 65, Ws: 17, Rain: 0.0, FFMC: 85.4, DMC: 18.5, DC: 42.0, ISI: 5.2, BUI: 19.3, FWI: 8.5, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 37, day: 7, month: 7, year: 2012, Temperature: 35, RH: 53, Ws: 14, Rain: 0.0, FFMC: 88.9, DMC: 21.7, DC: 77.0, ISI: 7.1, BUI: 25.5, FWI: 12.1, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 38, day: 8, month: 7, year: 2012, Temperature: 33, RH: 68, Ws: 16, Rain: 0.0, FFMC: 86.6, DMC: 24.3, DC: 84.7, ISI: 6.0, BUI: 28.6, FWI: 11.5, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 39, day: 9, month: 7, year: 2012, Temperature: 32, RH: 68, Ws: 14, Rain: 1.4, FFMC: 66.6, DMC: 8.2, DC: 27.8, ISI: 1.2, BUI: 9.3, FWI: 0.6, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 40, day: 10, month: 7, year: 2012, Temperature: 33, RH: 69, Ws: 14, Rain: 0.7, FFMC: 66.0, DMC: 6.9, DC: 24.9, ISI: 1.1, BUI: 7.9, FWI: 0.6, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 41, day: 11, month: 7, year: 2012, Temperature: 33, RH: 73, Ws: 13, Rain: 0.1, FFMC: 79.9, DMC: 9.4, DC: 32.5, ISI: 2.1, BUI: 10.9, FWI: 2.2, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 42, day: 12, month: 7, year: 2012, Temperature: 31, RH: 75, Ws: 14, Rain: 0.0, FFMC: 82.5, DMC: 12.6, DC: 45.9, ISI: 3.1, BUI: 14.8, FWI: 4.1, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 43, day: 13, month: 7, year: 2012, Temperature: 34, RH: 61, Ws: 13, Rain: 0.6, FFMC: 73.9, DMC: 11.0, DC: 30.6, ISI: 1.4, BUI: 11.8, FWI: 1.1, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 44, day: 14, month: 7, year: 2012, Temperature: 34, RH: 61, Ws: 16, Rain: 0.1, FFMC: 81.4, DMC: 11.3, DC: 38.8, ISI: 2.8, BUI: 12.9, FWI: 3.3, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 45, day: 15, month: 7, year: 2012, Temperature: 34, RH: 58, Ws: 16, Rain: 0.0, FFMC: 88.1, DMC: 27.8, DC: 71.1, ISI: 7.3, BUI: 28.5, FWI: 13.6, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 46, day: 16, month: 7, year: 2012, Temperature: 28, RH: 76, Ws: 21, Rain: 0.0, FFMC: 72.6, DMC: 7.0, DC: 25.5, ISI: 0.7, BUI: 8.3, FWI: 0.4, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 47, day: 17, month: 7, year: 2012, Temperature: 29, RH: 70, Ws: 14, Rain: 0.0, FFMC: 82.8, DMC: 9.4, DC: 34.1, ISI: 3.2, BUI: 11.1, FWI: 3.6, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 48, day: 18, month: 7, year: 2012, Temperature: 31, RH: 68, Ws: 14, Rain: 0.0, FFMC: 85.4, DMC: 12.1, DC: 43.1, ISI: 4.6, BUI: 14.2, FWI: 6.0, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 49, day: 19, month: 7, year: 2012, Temperature: 35, RH: 59, Ws: 17, Rain: 0.0, FFMC: 88.1, DMC: 12.0, DC: 52.8, ISI: 7.7, BUI: 18.2, FWI: 10.9, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 50, day: 20, month: 7, year: 2012, Temperature: 33, RH: 65, Ws: 15, Rain: 0.1, FFMC: 81.4, DMC: 12.3, DC: 60.7, ISI: 2.8, BUI: 15.5, FWI: 3.5, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 51, day: 21, month: 7, year: 2012, Temperature: 36, RH: 48, Ws: 13, Rain: 0.0, FFMC: 90.3, DMC: 22.2, DC: 108.5, ISI: 8.7, BUI: 29.4, FWI: 15.3, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'High' },
  { id: 52, day: 22, month: 7, year: 2012, Temperature: 37, RH: 36, Ws: 13, Rain: 0.0, FFMC: 92.5, DMC: 28.2, DC: 118.6, ISI: 11.2, BUI: 35.8, FWI: 19.8, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'High' },
  { id: 53, day: 23, month: 7, year: 2012, Temperature: 36, RH: 43, Ws: 16, Rain: 0.0, FFMC: 91.2, DMC: 32.5, DC: 128.2, ISI: 10.5, BUI: 40.2, FWI: 20.4, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'High' },
  { id: 54, day: 24, month: 7, year: 2012, Temperature: 28, RH: 78, Ws: 16, Rain: 0.1, FFMC: 70.0, DMC: 9.6, DC: 79.7, ISI: 1.4, BUI: 14.7, FWI: 1.3, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 55, day: 25, month: 7, year: 2012, Temperature: 29, RH: 75, Ws: 16, Rain: 0.0, FFMC: 82.2, DMC: 11.3, DC: 87.7, ISI: 3.4, BUI: 16.7, FWI: 4.8, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 56, day: 26, month: 7, year: 2012, Temperature: 36, RH: 53, Ws: 19, Rain: 0.0, FFMC: 89.2, DMC: 17.1, DC: 98.6, ISI: 10.0, BUI: 23.9, FWI: 15.3, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'High' },
  { id: 57, day: 27, month: 7, year: 2012, Temperature: 36, RH: 48, Ws: 14, Rain: 0.0, FFMC: 90.1, DMC: 22.3, DC: 106.2, ISI: 8.4, BUI: 29.5, FWI: 14.8, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 58, day: 28, month: 7, year: 2012, Temperature: 31, RH: 54, Ws: 11, Rain: 0.0, FFMC: 89.4, DMC: 24.8, DC: 113.6, ISI: 6.8, BUI: 31.9, FWI: 12.3, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 59, day: 29, month: 7, year: 2012, Temperature: 32, RH: 73, Ws: 16, Rain: 0.0, FFMC: 87.0, DMC: 19.6, DC: 83.0, ISI: 5.4, BUI: 24.3, FWI: 9.7, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 60, day: 30, month: 7, year: 2012, Temperature: 31, RH: 79, Ws: 15, Rain: 0.1, FFMC: 86.1, DMC: 21.7, DC: 90.9, ISI: 4.8, BUI: 26.6, FWI: 9.1, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 61, day: 31, month: 7, year: 2012, Temperature: 33, RH: 64, Ws: 13, Rain: 0.0, FFMC: 88.9, DMC: 26.1, DC: 106.3, ISI: 7.0, BUI: 32.7, FWI: 13.2, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  // August Bejaia
  { id: 62, day: 1, month: 8, year: 2012, Temperature: 36, RH: 45, Ws: 14, Rain: 0.0, FFMC: 78.8, DMC: 28.8, DC: 102.0, ISI: 7.2, BUI: 32.4, FWI: 13.8, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 63, day: 2, month: 8, year: 2012, Temperature: 35, RH: 55, Ws: 12, Rain: 0.4, FFMC: 78.0, DMC: 19.7, DC: 44.7, ISI: 1.7, BUI: 19.7, FWI: 2.1, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 64, day: 3, month: 8, year: 2012, Temperature: 35, RH: 63, Ws: 15, Rain: 0.0, FFMC: 87.0, DMC: 22.8, DC: 53.7, ISI: 5.7, BUI: 22.8, FWI: 9.8, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 65, day: 4, month: 8, year: 2012, Temperature: 34, RH: 69, Ws: 13, Rain: 0.0, FFMC: 85.0, DMC: 16.2, DC: 62.4, ISI: 4.2, BUI: 19.4, FWI: 6.4, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 66, day: 5, month: 8, year: 2012, Temperature: 34, RH: 65, Ws: 13, Rain: 0.0, FFMC: 86.8, DMC: 21.2, DC: 70.8, ISI: 5.6, BUI: 24.3, FWI: 9.9, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 67, day: 6, month: 8, year: 2012, Temperature: 32, RH: 75, Ws: 14, Rain: 0.0, FFMC: 86.4, DMC: 13.0, DC: 39.1, ISI: 5.2, BUI: 14.2, FWI: 6.8, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 68, day: 7, month: 8, year: 2012, Temperature: 32, RH: 69, Ws: 16, Rain: 0.0, FFMC: 86.5, DMC: 15.5, DC: 48.6, ISI: 5.5, BUI: 17.2, FWI: 8.0, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 69, day: 8, month: 8, year: 2012, Temperature: 32, RH: 60, Ws: 18, Rain: 0.3, FFMC: 77.1, DMC: 11.3, DC: 47.0, ISI: 2.2, BUI: 13.5, FWI: 2.4, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 70, day: 9, month: 8, year: 2012, Temperature: 35, RH: 54, Ws: 19, Rain: 0.0, FFMC: 89.1, DMC: 17.1, DC: 56.4, ISI: 9.1, BUI: 20.0, FWI: 13.0, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 71, day: 10, month: 8, year: 2012, Temperature: 35, RH: 55, Ws: 14, Rain: 0.0, FFMC: 88.9, DMC: 18.6, DC: 67.0, ISI: 7.4, BUI: 21.9, FWI: 11.6, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 72, day: 11, month: 8, year: 2012, Temperature: 35, RH: 63, Ws: 13, Rain: 0.0, FFMC: 88.9, DMC: 21.7, DC: 77.0, ISI: 7.1, BUI: 25.5, FWI: 12.1, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 73, day: 12, month: 8, year: 2012, Temperature: 35, RH: 51, Ws: 13, Rain: 0.3, FFMC: 81.3, DMC: 15.6, DC: 75.1, ISI: 2.5, BUI: 20.7, FWI: 4.2, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 74, day: 13, month: 8, year: 2012, Temperature: 35, RH: 46, Ws: 13, Rain: 0.3, FFMC: 83.9, DMC: 16.9, DC: 54.2, ISI: 3.5, BUI: 19.0, FWI: 5.5, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 75, day: 14, month: 8, year: 2012, Temperature: 33, RH: 66, Ws: 14, Rain: 0.0, FFMC: 87.0, DMC: 21.7, DC: 94.7, ISI: 5.7, BUI: 27.2, FWI: 10.6, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 76, day: 15, month: 8, year: 2012, Temperature: 36, RH: 55, Ws: 13, Rain: 0.0, FFMC: 89.1, DMC: 20.9, DC: 100.5, ISI: 8.0, BUI: 26.7, FWI: 13.4, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 77, day: 16, month: 8, year: 2012, Temperature: 36, RH: 61, Ws: 18, Rain: 0.3, FFMC: 80.2, DMC: 21.2, DC: 110.0, ISI: 2.8, BUI: 26.2, FWI: 5.5, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 78, day: 17, month: 8, year: 2012, Temperature: 37, RH: 52, Ws: 18, Rain: 0.0, FFMC: 89.3, DMC: 32.1, DC: 110.9, ISI: 9.2, BUI: 36.4, FWI: 17.5, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'High' },
  { id: 79, day: 18, month: 8, year: 2012, Temperature: 36, RH: 54, Ws: 15, Rain: 0.0, FFMC: 89.3, DMC: 37.8, DC: 122.5, ISI: 8.7, BUI: 42.1, FWI: 18.2, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'High' },
  { id: 80, day: 19, month: 8, year: 2012, Temperature: 35, RH: 62, Ws: 19, Rain: 0.0, FFMC: 89.4, DMC: 23.2, DC: 120.9, ISI: 9.7, BUI: 31.3, FWI: 17.2, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'High' },
  { id: 81, day: 20, month: 8, year: 2012, Temperature: 36, RH: 53, Ws: 16, Rain: 0.0, FFMC: 89.5, DMC: 26.8, DC: 131.7, ISI: 8.3, BUI: 34.3, FWI: 16.1, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'High' },
  { id: 82, day: 21, month: 8, year: 2012, Temperature: 36, RH: 58, Ws: 19, Rain: 0.0, FFMC: 88.6, DMC: 29.6, DC: 141.1, ISI: 9.2, BUI: 38.8, FWI: 18.3, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'High' },
  { id: 83, day: 22, month: 8, year: 2012, Temperature: 36, RH: 55, Ws: 18, Rain: 0.0, FFMC: 89.1, DMC: 33.5, DC: 151.3, ISI: 9.9, BUI: 43.1, FWI: 19.9, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'High' },
  { id: 84, day: 23, month: 8, year: 2012, Temperature: 36, RH: 53, Ws: 16, Rain: 0.0, FFMC: 89.5, DMC: 37.6, DC: 161.5, ISI: 10.4, BUI: 47.5, FWI: 21.6, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'High' },
  { id: 85, day: 24, month: 8, year: 2012, Temperature: 34, RH: 64, Ws: 14, Rain: 0.0, FFMC: 88.9, DMC: 40.5, DC: 171.3, ISI: 9.0, BUI: 50.9, FWI: 20.0, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'High' },
  { id: 86, day: 25, month: 8, year: 2012, Temperature: 35, RH: 60, Ws: 15, Rain: 0.0, FFMC: 88.9, DMC: 43.9, DC: 181.3, ISI: 8.2, BUI: 54.7, FWI: 19.7, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'High' },
  { id: 87, day: 26, month: 8, year: 2012, Temperature: 31, RH: 78, Ws: 18, Rain: 0.0, FFMC: 85.8, DMC: 45.6, DC: 190.6, ISI: 6.2, BUI: 56.9, FWI: 16.5, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'High' },
  { id: 88, day: 27, month: 8, year: 2012, Temperature: 33, RH: 73, Ws: 16, Rain: 0.0, FFMC: 87.0, DMC: 48.0, DC: 199.2, ISI: 6.8, BUI: 59.2, FWI: 17.9, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'High' },
  { id: 89, day: 28, month: 8, year: 2012, Temperature: 32, RH: 73, Ws: 15, Rain: 0.0, FFMC: 86.6, DMC: 26.7, DC: 166.5, ISI: 5.6, BUI: 38.0, FWI: 12.0, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 90, day: 29, month: 8, year: 2012, Temperature: 35, RH: 60, Ws: 17, Rain: 0.0, FFMC: 88.9, DMC: 30.1, DC: 175.7, ISI: 8.4, BUI: 42.1, FWI: 17.5, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'High' },
  { id: 91, day: 30, month: 8, year: 2012, Temperature: 35, RH: 53, Ws: 17, Rain: 0.5, FFMC: 80.2, DMC: 20.9, DC: 45.3, ISI: 2.2, BUI: 20.0, FWI: 3.1, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 92, day: 31, month: 8, year: 2012, Temperature: 28, RH: 76, Ws: 14, Rain: 0.0, FFMC: 86.2, DMC: 18.1, DC: 44.5, ISI: 4.6, BUI: 17.2, FWI: 6.9, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  // September Bejaia
  { id: 93, day: 1, month: 9, year: 2012, Temperature: 25, RH: 76, Ws: 17, Rain: 7.2, FFMC: 46.0, DMC: 1.3, DC: 7.5, ISI: 0.2, BUI: 1.8, FWI: 0.1, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 94, day: 2, month: 9, year: 2012, Temperature: 22, RH: 86, Ws: 15, Rain: 10.1, FFMC: 30.5, DMC: 0.7, DC: 6.9, ISI: 0.0, BUI: 1.1, FWI: 0.0, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 95, day: 3, month: 9, year: 2012, Temperature: 25, RH: 78, Ws: 15, Rain: 3.8, FFMC: 42.6, DMC: 1.2, DC: 13.7, ISI: 0.1, BUI: 2.0, FWI: 0.0, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 96, day: 4, month: 9, year: 2012, Temperature: 29, RH: 73, Ws: 17, Rain: 0.1, FFMC: 68.4, DMC: 1.9, DC: 15.7, ISI: 1.4, BUI: 2.9, FWI: 0.7, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 97, day: 5, month: 9, year: 2012, Temperature: 29, RH: 75, Ws: 16, Rain: 0.0, FFMC: 80.8, DMC: 3.4, DC: 22.0, ISI: 2.4, BUI: 4.8, FWI: 1.7, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 98, day: 6, month: 9, year: 2012, Temperature: 29, RH: 74, Ws: 19, Rain: 0.1, FFMC: 75.8, DMC: 3.6, DC: 32.2, ISI: 2.1, BUI: 5.6, FWI: 0.9, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 99, day: 7, month: 9, year: 2012, Temperature: 31, RH: 71, Ws: 17, Rain: 0.3, FFMC: 69.6, DMC: 3.2, DC: 27.5, ISI: 1.5, BUI: 4.8, FWI: 0.8, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 100, day: 8, month: 9, year: 2012, Temperature: 30, RH: 73, Ws: 17, Rain: 0.9, FFMC: 62.0, DMC: 2.6, DC: 27.4, ISI: 1.2, BUI: 4.2, FWI: 0.5, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 101, day: 9, month: 9, year: 2012, Temperature: 30, RH: 77, Ws: 15, Rain: 1.0, FFMC: 56.1, DMC: 2.1, DC: 18.0, ISI: 0.7, BUI: 3.3, FWI: 0.3, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 102, day: 10, month: 9, year: 2012, Temperature: 33, RH: 73, Ws: 12, Rain: 1.8, FFMC: 59.9, DMC: 2.2, DC: 8.9, ISI: 0.9, BUI: 2.7, FWI: 0.3, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 103, day: 11, month: 9, year: 2012, Temperature: 30, RH: 77, Ws: 21, Rain: 1.8, FFMC: 58.5, DMC: 1.9, DC: 8.4, ISI: 1.1, BUI: 2.4, FWI: 0.4, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 104, day: 12, month: 9, year: 2012, Temperature: 29, RH: 88, Ws: 13, Rain: 0.0, FFMC: 71.0, DMC: 2.4, DC: 15.5, ISI: 1.2, BUI: 3.6, FWI: 0.5, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 105, day: 13, month: 9, year: 2012, Temperature: 25, RH: 86, Ws: 20, Rain: 0.0, FFMC: 73.9, DMC: 3.0, DC: 20.2, ISI: 2.0, BUI: 4.4, FWI: 1.3, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 106, day: 14, month: 9, year: 2012, Temperature: 22, RH: 76, Ws: 26, Rain: 8.3, FFMC: 47.4, DMC: 1.1, DC: 7.0, ISI: 0.4, BUI: 1.6, FWI: 0.1, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 107, day: 15, month: 9, year: 2012, Temperature: 24, RH: 82, Ws: 15, Rain: 0.4, FFMC: 44.9, DMC: 0.9, DC: 7.3, ISI: 0.2, BUI: 1.4, FWI: 0.0, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 108, day: 16, month: 9, year: 2012, Temperature: 30, RH: 65, Ws: 14, Rain: 0.0, FFMC: 78.1, DMC: 3.2, DC: 15.7, ISI: 1.9, BUI: 4.2, FWI: 1.1, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 109, day: 17, month: 9, year: 2012, Temperature: 31, RH: 52, Ws: 14, Rain: 0.0, FFMC: 87.7, DMC: 6.4, DC: 24.3, ISI: 6.2, BUI: 7.7, FWI: 5.9, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 110, day: 18, month: 9, year: 2012, Temperature: 32, RH: 49, Ws: 11, Rain: 0.0, FFMC: 89.4, DMC: 9.8, DC: 33.1, ISI: 6.8, BUI: 11.3, FWI: 7.7, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 111, day: 19, month: 9, year: 2012, Temperature: 29, RH: 57, Ws: 16, Rain: 0.0, FFMC: 89.3, DMC: 12.5, DC: 41.3, ISI: 7.8, BUI: 14.2, FWI: 9.7, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 112, day: 20, month: 9, year: 2012, Temperature: 28, RH: 84, Ws: 18, Rain: 0.0, FFMC: 83.8, DMC: 13.5, DC: 49.3, ISI: 4.5, BUI: 16.0, FWI: 6.3, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 113, day: 21, month: 9, year: 2012, Temperature: 31, RH: 55, Ws: 11, Rain: 0.0, FFMC: 87.8, DMC: 16.5, DC: 56.3, ISI: 5.4, BUI: 19.2, FWI: 8.3, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 114, day: 22, month: 9, year: 2012, Temperature: 31, RH: 53, Ws: 18, Rain: 0.0, FFMC: 89.0, DMC: 21.6, DC: 64.7, ISI: 8.3, BUI: 24.3, FWI: 13.1, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Moderate' },
  { id: 115, day: 23, month: 9, year: 2012, Temperature: 32, RH: 54, Ws: 11, Rain: 1.2, FFMC: 60.0, DMC: 9.3, DC: 17.6, ISI: 0.9, BUI: 8.7, FWI: 0.4, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 116, day: 24, month: 9, year: 2012, Temperature: 29, RH: 65, Ws: 19, Rain: 0.6, FFMC: 68.3, DMC: 5.5, DC: 15.2, ISI: 1.5, BUI: 5.8, FWI: 0.7, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 117, day: 25, month: 9, year: 2012, Temperature: 26, RH: 81, Ws: 21, Rain: 5.8, FFMC: 48.6, DMC: 1.2, DC: 7.7, ISI: 0.4, BUI: 1.7, FWI: 0.1, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 118, day: 26, month: 9, year: 2012, Temperature: 31, RH: 54, Ws: 11, Rain: 0.0, FFMC: 82.0, DMC: 6.0, DC: 16.3, ISI: 2.5, BUI: 6.2, FWI: 1.7, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 119, day: 27, month: 9, year: 2012, Temperature: 31, RH: 66, Ws: 11, Rain: 0.0, FFMC: 85.7, DMC: 8.3, DC: 24.9, ISI: 4.0, BUI: 9.1, FWI: 4.1, Classes: 'fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 120, day: 28, month: 9, year: 2012, Temperature: 32, RH: 47, Ws: 14, Rain: 0.7, FFMC: 77.5, DMC: 7.1, DC: 8.8, ISI: 1.8, BUI: 6.8, FWI: 0.9, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 121, day: 29, month: 9, year: 2012, Temperature: 26, RH: 80, Ws: 16, Rain: 1.8, FFMC: 47.4, DMC: 1.7, DC: 7.1, ISI: 0.3, BUI: 2.1, FWI: 0.1, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },
  { id: 122, day: 30, month: 9, year: 2012, Temperature: 25, RH: 78, Ws: 14, Rain: 1.4, FFMC: 45.0, DMC: 1.9, DC: 7.5, ISI: 0.2, BUI: 2.4, FWI: 0.1, Classes: 'not fire', Region: 'Bejaia', Risk_Level: 'Low' },

  // Sidi Bel-Abbes Region (June to September 2012 - includes high Saharan heatwave and extreme FWI spikes > 25)
  { id: 123, day: 1, month: 6, year: 2012, Temperature: 32, RH: 71, Ws: 12, Rain: 0.7, FFMC: 57.1, DMC: 2.5, DC: 11.0, ISI: 0.8, BUI: 3.1, FWI: 0.3, Classes: 'not fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Low' },
  { id: 124, day: 2, month: 6, year: 2012, Temperature: 31, RH: 64, Ws: 15, Rain: 0.0, FFMC: 80.2, DMC: 4.4, DC: 18.0, ISI: 2.6, BUI: 5.4, FWI: 1.8, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Low' },
  { id: 125, day: 3, month: 6, year: 2012, Temperature: 32, RH: 60, Ws: 14, Rain: 0.0, FFMC: 85.4, DMC: 7.8, DC: 24.9, ISI: 4.9, BUI: 8.8, FWI: 5.3, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 126, day: 4, month: 6, year: 2012, Temperature: 35, RH: 54, Ws: 11, Rain: 0.1, FFMC: 83.7, DMC: 8.4, DC: 26.3, ISI: 3.1, BUI: 9.3, FWI: 3.1, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Low' },
  { id: 127, day: 5, month: 6, year: 2012, Temperature: 35, RH: 53, Ws: 16, Rain: 0.0, FFMC: 89.5, DMC: 10.7, DC: 34.4, ISI: 7.1, BUI: 12.1, FWI: 8.3, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 128, day: 6, month: 6, year: 2012, Temperature: 37, RH: 44, Ws: 16, Rain: 0.0, FFMC: 91.2, DMC: 15.8, DC: 43.6, ISI: 9.8, BUI: 16.9, FWI: 12.8, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 129, day: 7, month: 6, year: 2012, Temperature: 38, RH: 38, Ws: 13, Rain: 0.0, FFMC: 92.5, DMC: 24.0, DC: 52.2, ISI: 10.7, BUI: 23.9, FWI: 16.2, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 130, day: 8, month: 6, year: 2012, Temperature: 35, RH: 42, Ws: 15, Rain: 0.0, FFMC: 90.4, DMC: 22.9, DC: 59.8, ISI: 8.4, BUI: 24.1, FWI: 14.1, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 131, day: 9, month: 6, year: 2012, Temperature: 34, RH: 45, Ws: 14, Rain: 0.0, FFMC: 90.0, DMC: 27.8, DC: 68.0, ISI: 8.0, BUI: 28.5, FWI: 14.8, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 132, day: 10, month: 6, year: 2012, Temperature: 35, RH: 70, Ws: 17, Rain: 0.0, FFMC: 85.0, DMC: 18.5, DC: 73.8, ISI: 5.2, BUI: 22.4, FWI: 8.8, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 133, day: 11, month: 6, year: 2012, Temperature: 36, RH: 33, Ws: 13, Rain: 0.1, FFMC: 88.7, DMC: 22.9, DC: 85.3, ISI: 9.0, BUI: 27.5, FWI: 15.6, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 134, day: 12, month: 6, year: 2012, Temperature: 39, RH: 30, Ws: 15, Rain: 0.0, FFMC: 91.8, DMC: 30.5, DC: 98.6, ISI: 11.8, BUI: 34.6, FWI: 20.8, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 135, day: 13, month: 6, year: 2012, Temperature: 40, RH: 34, Ws: 14, Rain: 0.0, FFMC: 93.3, DMC: 40.2, DC: 112.5, ISI: 14.0, BUI: 43.8, FWI: 26.2, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Extreme' },
  { id: 136, day: 14, month: 6, year: 2012, Temperature: 37, RH: 36, Ws: 13, Rain: 0.0, FFMC: 92.8, DMC: 45.6, DC: 120.4, ISI: 12.3, BUI: 48.7, FWI: 24.8, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 137, day: 15, month: 6, year: 2012, Temperature: 35, RH: 46, Ws: 13, Rain: 0.3, FFMC: 83.9, DMC: 16.9, DC: 54.2, ISI: 3.5, BUI: 19.0, FWI: 5.5, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 138, day: 16, month: 6, year: 2012, Temperature: 33, RH: 62, Ws: 14, Rain: 0.0, FFMC: 87.0, DMC: 19.2, DC: 62.4, ISI: 5.5, BUI: 22.0, FWI: 9.3, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 139, day: 17, month: 6, year: 2012, Temperature: 36, RH: 53, Ws: 15, Rain: 0.0, FFMC: 89.0, DMC: 22.9, DC: 71.3, ISI: 7.2, BUI: 25.8, FWI: 12.5, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 140, day: 18, month: 6, year: 2012, Temperature: 36, RH: 52, Ws: 18, Rain: 0.0, FFMC: 89.4, DMC: 25.8, DC: 80.3, ISI: 9.2, BUI: 28.8, FWI: 16.2, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 141, day: 19, month: 6, year: 2012, Temperature: 37, RH: 38, Ws: 14, Rain: 0.0, FFMC: 91.0, DMC: 30.2, DC: 89.5, ISI: 9.5, BUI: 33.1, FWI: 17.5, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 142, day: 20, month: 6, year: 2012, Temperature: 36, RH: 42, Ws: 15, Rain: 0.0, FFMC: 90.5, DMC: 34.6, DC: 98.7, ISI: 8.8, BUI: 37.1, FWI: 17.6, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 143, day: 21, month: 6, year: 2012, Temperature: 38, RH: 34, Ws: 17, Rain: 0.0, FFMC: 92.2, DMC: 41.5, DC: 110.2, ISI: 13.5, BUI: 44.8, FWI: 25.9, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Extreme' },
  { id: 144, day: 22, month: 6, year: 2012, Temperature: 40, RH: 29, Ws: 14, Rain: 0.0, FFMC: 93.6, DMC: 50.2, DC: 124.5, ISI: 14.8, BUI: 53.6, FWI: 28.5, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Extreme' },
  { id: 145, day: 23, month: 6, year: 2012, Temperature: 41, RH: 26, Ws: 16, Rain: 0.0, FFMC: 94.2, DMC: 60.1, DC: 138.9, ISI: 16.5, BUI: 62.4, FWI: 31.1, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Extreme' },
  { id: 146, day: 24, month: 6, year: 2012, Temperature: 39, RH: 35, Ws: 17, Rain: 0.0, FFMC: 92.4, DMC: 55.4, DC: 145.2, ISI: 13.9, BUI: 58.1, FWI: 27.8, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Extreme' },
  { id: 147, day: 25, month: 6, year: 2012, Temperature: 35, RH: 53, Ws: 16, Rain: 0.4, FFMC: 84.1, DMC: 22.0, DC: 65.4, ISI: 4.8, BUI: 24.2, FWI: 8.9, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 148, day: 26, month: 6, year: 2012, Temperature: 31, RH: 72, Ws: 14, Rain: 0.5, FFMC: 76.5, DMC: 10.2, DC: 30.5, ISI: 2.1, BUI: 11.5, FWI: 2.5, Classes: 'not fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Low' },
  { id: 149, day: 27, month: 6, year: 2012, Temperature: 28, RH: 82, Ws: 18, Rain: 2.1, FFMC: 51.2, DMC: 4.5, DC: 12.3, ISI: 0.6, BUI: 4.8, FWI: 0.3, Classes: 'not fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Low' },
  { id: 150, day: 28, month: 6, year: 2012, Temperature: 27, RH: 87, Ws: 15, Rain: 4.4, FFMC: 41.1, DMC: 2.1, DC: 8.2, ISI: 0.1, BUI: 2.4, FWI: 0.0, Classes: 'not fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Low' },
  { id: 151, day: 29, month: 6, year: 2012, Temperature: 30, RH: 75, Ws: 14, Rain: 0.0, FFMC: 79.5, DMC: 5.6, DC: 19.8, ISI: 2.5, BUI: 6.8, FWI: 2.1, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Low' },
  { id: 152, day: 30, month: 6, year: 2012, Temperature: 32, RH: 65, Ws: 15, Rain: 0.0, FFMC: 84.8, DMC: 9.3, DC: 29.5, ISI: 4.7, BUI: 10.7, FWI: 5.4, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  // July Sidi Bel-abbes
  { id: 153, day: 1, month: 7, year: 2012, Temperature: 35, RH: 50, Ws: 16, Rain: 0.0, FFMC: 88.2, DMC: 13.4, DC: 39.7, ISI: 6.9, BUI: 14.8, FWI: 9.1, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 154, day: 2, month: 7, year: 2012, Temperature: 36, RH: 45, Ws: 14, Rain: 0.0, FFMC: 89.8, DMC: 18.2, DC: 50.1, ISI: 8.2, BUI: 19.8, FWI: 12.1, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 155, day: 3, month: 7, year: 2012, Temperature: 38, RH: 38, Ws: 15, Rain: 0.0, FFMC: 91.5, DMC: 24.6, DC: 62.8, ISI: 10.1, BUI: 25.8, FWI: 16.4, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 156, day: 4, month: 7, year: 2012, Temperature: 37, RH: 41, Ws: 16, Rain: 0.0, FFMC: 91.0, DMC: 29.4, DC: 74.3, ISI: 9.8, BUI: 30.5, FWI: 17.2, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 157, day: 5, month: 7, year: 2012, Temperature: 36, RH: 46, Ws: 17, Rain: 0.0, FFMC: 90.1, DMC: 32.8, DC: 84.7, ISI: 9.2, BUI: 34.0, FWI: 17.3, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 158, day: 6, month: 7, year: 2012, Temperature: 35, RH: 51, Ws: 15, Rain: 0.0, FFMC: 89.0, DMC: 36.5, DC: 94.2, ISI: 8.1, BUI: 37.8, FWI: 16.3, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 159, day: 7, month: 7, year: 2012, Temperature: 38, RH: 35, Ws: 15, Rain: 0.0, FFMC: 92.4, DMC: 43.1, DC: 106.8, ISI: 11.2, BUI: 44.5, FWI: 22.3, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 160, day: 8, month: 7, year: 2012, Temperature: 39, RH: 31, Ws: 16, Rain: 0.0, FFMC: 93.1, DMC: 49.8, DC: 119.5, ISI: 13.4, BUI: 51.2, FWI: 26.5, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Extreme' },
  { id: 161, day: 9, month: 7, year: 2012, Temperature: 40, RH: 28, Ws: 14, Rain: 0.0, FFMC: 94.1, DMC: 58.2, DC: 132.8, ISI: 15.2, BUI: 59.4, FWI: 29.8, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Extreme' },
  { id: 162, day: 10, month: 7, year: 2012, Temperature: 42, RH: 23, Ws: 18, Rain: 0.0, FFMC: 95.0, DMC: 65.9, DC: 148.6, ISI: 18.5, BUI: 66.8, FWI: 33.4, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Extreme' },
  { id: 163, day: 11, month: 7, year: 2012, Temperature: 38, RH: 34, Ws: 16, Rain: 0.0, FFMC: 92.6, DMC: 58.3, DC: 152.0, ISI: 12.5, BUI: 61.2, FWI: 27.1, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Extreme' },
  { id: 164, day: 12, month: 7, year: 2012, Temperature: 34, RH: 56, Ws: 15, Rain: 0.2, FFMC: 82.5, DMC: 28.0, DC: 89.2, ISI: 4.1, BUI: 29.8, FWI: 8.5, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 165, day: 13, month: 7, year: 2012, Temperature: 32, RH: 68, Ws: 14, Rain: 0.0, FFMC: 85.1, DMC: 22.4, DC: 94.5, ISI: 4.7, BUI: 26.2, FWI: 8.7, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 166, day: 14, month: 7, year: 2012, Temperature: 33, RH: 63, Ws: 16, Rain: 0.0, FFMC: 87.2, DMC: 26.1, DC: 102.3, ISI: 6.3, BUI: 30.1, FWI: 12.0, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 167, day: 15, month: 7, year: 2012, Temperature: 35, RH: 55, Ws: 14, Rain: 0.0, FFMC: 88.8, DMC: 30.5, DC: 112.0, ISI: 7.3, BUI: 34.6, FWI: 14.3, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 168, day: 16, month: 7, year: 2012, Temperature: 36, RH: 48, Ws: 15, Rain: 0.0, FFMC: 90.1, DMC: 36.2, DC: 122.5, ISI: 8.9, BUI: 39.8, FWI: 17.8, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 169, day: 17, month: 7, year: 2012, Temperature: 37, RH: 43, Ws: 15, Rain: 0.0, FFMC: 90.8, DMC: 41.5, DC: 133.0, ISI: 9.7, BUI: 44.8, FWI: 19.9, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 170, day: 18, month: 7, year: 2012, Temperature: 38, RH: 38, Ws: 16, Rain: 0.0, FFMC: 91.9, DMC: 48.0, DC: 144.5, ISI: 11.5, BUI: 51.0, FWI: 23.5, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 171, day: 19, month: 7, year: 2012, Temperature: 39, RH: 34, Ws: 15, Rain: 0.0, FFMC: 92.7, DMC: 54.3, DC: 156.2, ISI: 13.0, BUI: 57.2, FWI: 26.6, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Extreme' },
  { id: 172, day: 20, month: 7, year: 2012, Temperature: 40, RH: 30, Ws: 14, Rain: 0.0, FFMC: 93.5, DMC: 61.2, DC: 168.4, ISI: 14.2, BUI: 63.5, FWI: 29.2, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Extreme' },
  { id: 173, day: 21, month: 7, year: 2012, Temperature: 37, RH: 42, Ws: 17, Rain: 0.0, FFMC: 90.8, DMC: 52.4, DC: 165.0, ISI: 10.4, BUI: 56.4, FWI: 22.8, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 174, day: 22, month: 7, year: 2012, Temperature: 33, RH: 64, Ws: 15, Rain: 0.0, FFMC: 86.8, DMC: 32.1, DC: 112.5, ISI: 5.6, BUI: 35.8, FWI: 11.8, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 175, day: 23, month: 7, year: 2012, Temperature: 32, RH: 68, Ws: 14, Rain: 0.4, FFMC: 79.5, DMC: 18.4, DC: 65.3, ISI: 2.8, BUI: 21.0, FWI: 4.8, Classes: 'not fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Low' },
  { id: 176, day: 24, month: 7, year: 2012, Temperature: 30, RH: 75, Ws: 16, Rain: 0.8, FFMC: 69.2, DMC: 8.6, DC: 28.4, ISI: 1.5, BUI: 10.2, FWI: 1.4, Classes: 'not fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Low' },
  { id: 177, day: 25, month: 7, year: 2012, Temperature: 31, RH: 72, Ws: 15, Rain: 0.0, FFMC: 83.4, DMC: 11.2, DC: 38.6, ISI: 3.8, BUI: 13.0, FWI: 4.7, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Low' },
  { id: 178, day: 26, month: 7, year: 2012, Temperature: 34, RH: 58, Ws: 14, Rain: 0.0, FFMC: 87.5, DMC: 16.0, DC: 50.1, ISI: 5.9, BUI: 18.0, FWI: 8.8, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 179, day: 27, month: 7, year: 2012, Temperature: 35, RH: 52, Ws: 15, Rain: 0.0, FFMC: 89.2, DMC: 21.5, DC: 61.8, ISI: 7.7, BUI: 23.8, FWI: 12.8, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 180, day: 28, month: 7, year: 2012, Temperature: 36, RH: 48, Ws: 14, Rain: 0.0, FFMC: 90.3, DMC: 26.8, DC: 73.5, ISI: 8.5, BUI: 29.1, FWI: 15.1, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 181, day: 29, month: 7, year: 2012, Temperature: 37, RH: 42, Ws: 16, Rain: 0.0, FFMC: 91.4, DMC: 33.2, DC: 86.1, ISI: 10.2, BUI: 35.5, FWI: 18.9, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 182, day: 30, month: 7, year: 2012, Temperature: 37, RH: 40, Ws: 15, Rain: 0.0, FFMC: 91.8, DMC: 39.5, DC: 98.4, ISI: 10.7, BUI: 41.5, FWI: 20.7, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 183, day: 31, month: 7, year: 2012, Temperature: 38, RH: 36, Ws: 14, Rain: 0.0, FFMC: 92.5, DMC: 46.2, DC: 110.8, ISI: 11.8, BUI: 47.9, FWI: 23.4, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  // August Sidi Bel-abbes
  { id: 184, day: 1, month: 8, year: 2012, Temperature: 39, RH: 32, Ws: 15, Rain: 0.0, FFMC: 93.2, DMC: 53.4, DC: 124.0, ISI: 13.5, BUI: 54.8, FWI: 26.8, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Extreme' },
  { id: 185, day: 2, month: 8, year: 2012, Temperature: 40, RH: 29, Ws: 16, Rain: 0.0, FFMC: 94.0, DMC: 60.5, DC: 137.2, ISI: 15.6, BUI: 61.8, FWI: 30.2, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Extreme' },
  { id: 186, day: 3, month: 8, year: 2012, Temperature: 41, RH: 25, Ws: 17, Rain: 0.0, FFMC: 94.8, DMC: 68.0, DC: 151.0, ISI: 17.5, BUI: 69.2, FWI: 34.0, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Extreme' },
  { id: 187, day: 4, month: 8, year: 2012, Temperature: 38, RH: 35, Ws: 18, Rain: 0.0, FFMC: 92.4, DMC: 58.0, DC: 148.0, ISI: 12.8, BUI: 60.0, FWI: 26.5, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Extreme' },
  { id: 188, day: 5, month: 8, year: 2012, Temperature: 36, RH: 42, Ws: 16, Rain: 0.0, FFMC: 90.2, DMC: 48.5, DC: 138.0, ISI: 9.8, BUI: 51.5, FWI: 20.8, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 189, day: 6, month: 8, year: 2012, Temperature: 34, RH: 55, Ws: 14, Rain: 0.1, FFMC: 85.4, DMC: 36.2, DC: 110.0, ISI: 5.4, BUI: 39.5, FWI: 12.2, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 190, day: 7, month: 8, year: 2012, Temperature: 32, RH: 64, Ws: 15, Rain: 0.0, FFMC: 86.0, DMC: 30.1, DC: 98.0, ISI: 5.3, BUI: 33.4, FWI: 11.2, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 191, day: 8, month: 8, year: 2012, Temperature: 33, RH: 60, Ws: 16, Rain: 0.0, FFMC: 87.5, DMC: 34.0, DC: 108.5, ISI: 6.8, BUI: 37.8, FWI: 14.5, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 192, day: 9, month: 8, year: 2012, Temperature: 35, RH: 52, Ws: 14, Rain: 0.0, FFMC: 89.1, DMC: 39.5, DC: 119.0, ISI: 7.9, BUI: 43.5, FWI: 16.9, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 193, day: 10, month: 8, year: 2012, Temperature: 36, RH: 46, Ws: 15, Rain: 0.0, FFMC: 90.4, DMC: 45.2, DC: 130.5, ISI: 9.3, BUI: 49.6, FWI: 19.8, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 194, day: 11, month: 8, year: 2012, Temperature: 37, RH: 41, Ws: 14, Rain: 0.0, FFMC: 91.5, DMC: 51.0, DC: 142.0, ISI: 10.5, BUI: 55.4, FWI: 22.8, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 195, day: 12, month: 8, year: 2012, Temperature: 38, RH: 36, Ws: 15, Rain: 0.0, FFMC: 92.6, DMC: 57.5, DC: 154.5, ISI: 12.2, BUI: 61.8, FWI: 26.2, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Extreme' },
  { id: 196, day: 13, month: 8, year: 2012, Temperature: 39, RH: 32, Ws: 16, Rain: 0.0, FFMC: 93.4, DMC: 64.2, DC: 167.0, ISI: 14.1, BUI: 68.0, FWI: 29.5, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Extreme' },
  { id: 197, day: 14, month: 8, year: 2012, Temperature: 40, RH: 28, Ws: 15, Rain: 0.0, FFMC: 94.2, DMC: 71.0, DC: 180.0, ISI: 16.0, BUI: 74.5, FWI: 32.8, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Extreme' },
  { id: 198, day: 15, month: 8, year: 2012, Temperature: 37, RH: 40, Ws: 16, Rain: 0.0, FFMC: 91.2, DMC: 58.0, DC: 172.0, ISI: 11.2, BUI: 62.5, FWI: 24.3, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 199, day: 16, month: 8, year: 2012, Temperature: 35, RH: 50, Ws: 14, Rain: 0.0, FFMC: 88.5, DMC: 46.0, DC: 155.0, ISI: 7.5, BUI: 50.8, FWI: 17.0, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 200, day: 17, month: 8, year: 2012, Temperature: 33, RH: 62, Ws: 15, Rain: 0.2, FFMC: 81.0, DMC: 28.5, DC: 98.0, ISI: 3.5, BUI: 31.0, FWI: 7.2, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 201, day: 18, month: 8, year: 2012, Temperature: 31, RH: 70, Ws: 16, Rain: 0.5, FFMC: 74.8, DMC: 16.2, DC: 52.0, ISI: 1.9, BUI: 18.0, FWI: 2.8, Classes: 'not fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Low' },
  { id: 202, day: 19, month: 8, year: 2012, Temperature: 29, RH: 78, Ws: 17, Rain: 1.5, FFMC: 60.5, DMC: 9.5, DC: 28.0, ISI: 1.0, BUI: 10.5, FWI: 0.9, Classes: 'not fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Low' },
  { id: 203, day: 20, month: 8, year: 2012, Temperature: 31, RH: 68, Ws: 14, Rain: 0.0, FFMC: 82.5, DMC: 13.0, DC: 38.0, ISI: 3.4, BUI: 14.5, FWI: 4.8, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Low' },
  { id: 204, day: 21, month: 8, year: 2012, Temperature: 33, RH: 58, Ws: 15, Rain: 0.0, FFMC: 87.0, DMC: 18.5, DC: 49.0, ISI: 6.0, BUI: 20.5, FWI: 9.6, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 205, day: 22, month: 8, year: 2012, Temperature: 35, RH: 50, Ws: 14, Rain: 0.0, FFMC: 89.2, DMC: 24.2, DC: 61.5, ISI: 7.8, BUI: 26.5, FWI: 13.2, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 206, day: 23, month: 8, year: 2012, Temperature: 36, RH: 45, Ws: 15, Rain: 0.0, FFMC: 90.6, DMC: 30.8, DC: 74.0, ISI: 9.2, BUI: 33.0, FWI: 16.8, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 207, day: 24, month: 8, year: 2012, Temperature: 37, RH: 40, Ws: 16, Rain: 0.0, FFMC: 91.8, DMC: 37.5, DC: 87.0, ISI: 11.0, BUI: 40.0, FWI: 20.6, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 208, day: 25, month: 8, year: 2012, Temperature: 38, RH: 35, Ws: 15, Rain: 0.0, FFMC: 92.8, DMC: 44.2, DC: 100.5, ISI: 12.6, BUI: 47.0, FWI: 24.5, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 209, day: 26, month: 8, year: 2012, Temperature: 39, RH: 30, Ws: 16, Rain: 0.0, FFMC: 93.6, DMC: 51.5, DC: 114.0, ISI: 14.5, BUI: 54.0, FWI: 28.2, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Extreme' },
  { id: 210, day: 27, month: 8, year: 2012, Temperature: 36, RH: 45, Ws: 15, Rain: 0.0, FFMC: 89.8, DMC: 40.0, DC: 105.0, ISI: 8.6, BUI: 42.5, FWI: 17.5, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 211, day: 28, month: 8, year: 2012, Temperature: 34, RH: 56, Ws: 14, Rain: 0.0, FFMC: 86.8, DMC: 31.0, DC: 90.0, ISI: 5.8, BUI: 33.5, FWI: 11.9, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 212, day: 29, month: 8, year: 2012, Temperature: 32, RH: 65, Ws: 15, Rain: 0.1, FFMC: 81.5, DMC: 22.0, DC: 65.0, ISI: 3.2, BUI: 24.5, FWI: 6.2, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 213, day: 30, month: 8, year: 2012, Temperature: 30, RH: 72, Ws: 16, Rain: 0.6, FFMC: 72.0, DMC: 12.0, DC: 35.0, ISI: 1.8, BUI: 13.5, FWI: 2.1, Classes: 'not fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Low' },
  { id: 214, day: 31, month: 8, year: 2012, Temperature: 28, RH: 80, Ws: 17, Rain: 2.0, FFMC: 55.0, DMC: 6.5, DC: 18.0, ISI: 0.8, BUI: 7.2, FWI: 0.6, Classes: 'not fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Low' },
  // September Sidi Bel-abbes
  { id: 215, day: 1, month: 9, year: 2012, Temperature: 29, RH: 75, Ws: 16, Rain: 0.0, FFMC: 80.2, DMC: 8.5, DC: 25.0, ISI: 2.8, BUI: 9.8, FWI: 2.9, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Low' },
  { id: 216, day: 2, month: 9, year: 2012, Temperature: 31, RH: 65, Ws: 15, Rain: 0.0, FFMC: 84.5, DMC: 13.0, DC: 36.0, ISI: 4.8, BUI: 14.5, FWI: 6.5, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 217, day: 3, month: 9, year: 2012, Temperature: 33, RH: 55, Ws: 14, Rain: 0.0, FFMC: 87.8, DMC: 18.0, DC: 48.0, ISI: 6.8, BUI: 19.8, FWI: 10.5, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 218, day: 4, month: 9, year: 2012, Temperature: 35, RH: 48, Ws: 15, Rain: 0.0, FFMC: 89.8, DMC: 24.0, DC: 61.0, ISI: 8.6, BUI: 26.0, FWI: 14.5, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 219, day: 5, month: 9, year: 2012, Temperature: 36, RH: 42, Ws: 16, Rain: 0.0, FFMC: 91.2, DMC: 30.5, DC: 74.0, ISI: 10.4, BUI: 32.5, FWI: 18.5, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 220, day: 6, month: 9, year: 2012, Temperature: 37, RH: 38, Ws: 15, Rain: 0.0, FFMC: 92.0, DMC: 37.0, DC: 87.0, ISI: 11.8, BUI: 39.0, FWI: 21.8, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 221, day: 7, month: 9, year: 2012, Temperature: 38, RH: 34, Ws: 16, Rain: 0.0, FFMC: 93.0, DMC: 44.0, DC: 100.0, ISI: 13.5, BUI: 46.0, FWI: 25.5, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Extreme' },
  { id: 222, day: 8, month: 9, year: 2012, Temperature: 35, RH: 48, Ws: 15, Rain: 0.0, FFMC: 89.5, DMC: 35.0, DC: 92.0, ISI: 8.4, BUI: 37.5, FWI: 16.5, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 223, day: 9, month: 9, year: 2012, Temperature: 32, RH: 60, Ws: 14, Rain: 0.1, FFMC: 83.0, DMC: 24.0, DC: 75.0, ISI: 4.2, BUI: 26.5, FWI: 8.2, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 224, day: 10, month: 9, year: 2012, Temperature: 30, RH: 70, Ws: 16, Rain: 0.5, FFMC: 75.0, DMC: 15.0, DC: 48.0, ISI: 2.2, BUI: 16.8, FWI: 3.2, Classes: 'not fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Low' },
  { id: 225, day: 11, month: 9, year: 2012, Temperature: 28, RH: 78, Ws: 17, Rain: 2.5, FFMC: 52.0, DMC: 7.0, DC: 22.0, ISI: 0.7, BUI: 8.0, FWI: 0.5, Classes: 'not fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Low' },
  { id: 226, day: 12, month: 9, year: 2012, Temperature: 26, RH: 85, Ws: 18, Rain: 5.2, FFMC: 42.0, DMC: 3.0, DC: 11.0, ISI: 0.3, BUI: 3.5, FWI: 0.1, Classes: 'not fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Low' },
  { id: 227, day: 13, month: 9, year: 2012, Temperature: 27, RH: 82, Ws: 15, Rain: 1.0, FFMC: 58.0, DMC: 4.5, DC: 16.0, ISI: 0.9, BUI: 5.2, FWI: 0.8, Classes: 'not fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Low' },
  { id: 228, day: 14, month: 9, year: 2012, Temperature: 29, RH: 74, Ws: 14, Rain: 0.0, FFMC: 78.5, DMC: 7.5, DC: 26.0, ISI: 2.4, BUI: 8.8, FWI: 2.5, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Low' },
  { id: 229, day: 15, month: 9, year: 2012, Temperature: 31, RH: 65, Ws: 15, Rain: 0.0, FFMC: 84.0, DMC: 11.5, DC: 38.0, ISI: 4.6, BUI: 13.2, FWI: 6.2, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 230, day: 16, month: 9, year: 2012, Temperature: 33, RH: 56, Ws: 14, Rain: 0.0, FFMC: 87.5, DMC: 16.0, DC: 50.0, ISI: 6.6, BUI: 18.0, FWI: 10.1, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 231, day: 17, month: 9, year: 2012, Temperature: 34, RH: 50, Ws: 15, Rain: 0.0, FFMC: 89.2, DMC: 21.0, DC: 62.0, ISI: 8.1, BUI: 23.5, FWI: 13.5, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 232, day: 18, month: 9, year: 2012, Temperature: 35, RH: 45, Ws: 16, Rain: 0.0, FFMC: 90.5, DMC: 26.5, DC: 75.0, ISI: 9.8, BUI: 29.5, FWI: 17.2, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 233, day: 19, month: 9, year: 2012, Temperature: 36, RH: 40, Ws: 15, Rain: 0.0, FFMC: 91.5, DMC: 32.5, DC: 88.0, ISI: 11.2, BUI: 35.8, FWI: 20.8, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 234, day: 20, month: 9, year: 2012, Temperature: 37, RH: 36, Ws: 16, Rain: 0.0, FFMC: 92.5, DMC: 39.0, DC: 101.0, ISI: 12.8, BUI: 42.5, FWI: 24.5, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 235, day: 21, month: 9, year: 2012, Temperature: 35, RH: 46, Ws: 15, Rain: 0.0, FFMC: 89.8, DMC: 32.0, DC: 90.0, ISI: 8.8, BUI: 35.0, FWI: 16.8, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'High' },
  { id: 236, day: 22, month: 9, year: 2012, Temperature: 32, RH: 58, Ws: 14, Rain: 0.2, FFMC: 82.0, DMC: 22.0, DC: 72.0, ISI: 4.0, BUI: 24.8, FWI: 7.8, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 237, day: 23, month: 9, year: 2012, Temperature: 30, RH: 68, Ws: 15, Rain: 0.8, FFMC: 73.0, DMC: 13.0, DC: 45.0, ISI: 2.0, BUI: 14.5, FWI: 2.8, Classes: 'not fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Low' },
  { id: 238, day: 24, month: 9, year: 2012, Temperature: 28, RH: 76, Ws: 16, Rain: 1.8, FFMC: 56.0, DMC: 7.5, DC: 25.0, ISI: 0.9, BUI: 8.5, FWI: 0.8, Classes: 'not fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Low' },
  { id: 239, day: 25, month: 9, year: 2012, Temperature: 26, RH: 84, Ws: 17, Rain: 4.8, FFMC: 44.0, DMC: 3.2, DC: 12.0, ISI: 0.4, BUI: 3.8, FWI: 0.2, Classes: 'not fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Low' },
  { id: 240, day: 26, month: 9, year: 2012, Temperature: 28, RH: 75, Ws: 15, Rain: 0.4, FFMC: 72.0, DMC: 5.0, DC: 18.0, ISI: 1.8, BUI: 6.0, FWI: 1.6, Classes: 'not fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Low' },
  { id: 241, day: 27, month: 9, year: 2012, Temperature: 30, RH: 65, Ws: 14, Rain: 0.0, FFMC: 82.5, DMC: 8.5, DC: 28.0, ISI: 3.8, BUI: 9.8, FWI: 4.6, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Low' },
  { id: 242, day: 28, month: 9, year: 2012, Temperature: 32, RH: 55, Ws: 14, Rain: 0.0, FFMC: 87.0, DMC: 13.0, DC: 40.0, ISI: 6.0, BUI: 15.0, FWI: 8.8, Classes: 'fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Moderate' },
  { id: 243, day: 29, month: 9, year: 2012, Temperature: 29, RH: 70, Ws: 16, Rain: 1.2, FFMC: 62.0, DMC: 6.0, DC: 22.0, ISI: 1.2, BUI: 7.0, FWI: 1.0, Classes: 'not fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Low' },
  { id: 244, day: 30, month: 9, year: 2012, Temperature: 27, RH: 78, Ws: 15, Rain: 2.1, FFMC: 50.0, DMC: 3.5, DC: 14.0, ISI: 0.7, BUI: 4.2, FWI: 0.4, Classes: 'not fire', Region: 'Sidi Bel-abbes', Risk_Level: 'Low' },
];

export const FEATURE_NAMES = ['Temperature', 'RH', 'Ws', 'ISI', 'BUI'] as const;
export type FeatureKey = typeof FEATURE_NAMES[number];

export const ALL_FEATURE_NAMES = [
  'Temperature', 'RH', 'Ws', 'Rain', 'FFMC', 'DMC', 'DC', 'ISI', 'BUI', 'FWI'
] as const;

export interface FeatureStats {
  mean: number;
  std: number;
  min: number;
  max: number;
  median: number;
}

export function computeStats(values: number[]): FeatureStats {
  const n = values.length;
  const sorted = [...values].sort((a, b) => a - b);
  const sum = values.reduce((acc, v) => acc + v, 0);
  const mean = sum / n;
  const variance = values.reduce((acc, v) => acc + Math.pow(v - mean, 2), 0) / n;
  const std = Math.sqrt(variance);
  const min = sorted[0];
  const max = sorted[sorted.length - 1];
  const median = n % 2 === 0 ? (sorted[n / 2 - 1] + sorted[n / 2]) / 2 : sorted[Math.floor(n / 2)];
  return { mean, std, min, max, median };
}

export const DATASET_STATS: Record<string, FeatureStats> = {
  Temperature: computeStats(ALGERIAN_FIRES_DATASET.map(d => d.Temperature)),
  RH: computeStats(ALGERIAN_FIRES_DATASET.map(d => d.RH)),
  Ws: computeStats(ALGERIAN_FIRES_DATASET.map(d => d.Ws)),
  Rain: computeStats(ALGERIAN_FIRES_DATASET.map(d => d.Rain)),
  FFMC: computeStats(ALGERIAN_FIRES_DATASET.map(d => d.FFMC)),
  DMC: computeStats(ALGERIAN_FIRES_DATASET.map(d => d.DMC)),
  DC: computeStats(ALGERIAN_FIRES_DATASET.map(d => d.DC)),
  ISI: computeStats(ALGERIAN_FIRES_DATASET.map(d => d.ISI)),
  BUI: computeStats(ALGERIAN_FIRES_DATASET.map(d => d.BUI)),
  FWI: computeStats(ALGERIAN_FIRES_DATASET.map(d => d.FWI)),
};

// Pearson correlation matrix
export function computeCorrelation(x: number[], y: number[]): number {
  const n = x.length;
  const mx = x.reduce((a, b) => a + b, 0) / n;
  const my = y.reduce((a, b) => a + b, 0) / n;
  let num = 0;
  let den1 = 0;
  let den2 = 0;
  for (let i = 0; i < n; i++) {
    const dx = x[i] - mx;
    const dy = y[i] - my;
    num += dx * dy;
    den1 += dx * dx;
    den2 += dy * dy;
  }
  const den = Math.sqrt(den1 * den2);
  return den === 0 ? 0 : Number((num / den).toFixed(3));
}
